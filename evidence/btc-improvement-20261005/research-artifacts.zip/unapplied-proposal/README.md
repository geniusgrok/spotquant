# 可选生产集成：未应用、未执行测试

依赖 `6532476d2ee9cdf470a512ce8bfb3fa02cacd6d1` 的单个完整 semivar 钱包测量完成并通过综合采用评价。完整净益不足时不应用；保留该配置作为提高参与度的研究结果。这里的补丁没有改变 Coin 仓库、HEAD、795 执行进程或任何钱包。

准备目录使用任务内 `private/`；主机绝对 `/private` 不可写。`initial-downside-default.patch` 含两生产文件和必要合成软件检查：

- `coinquant/linear_sizing.py` 增加纯 `initial_target_fraction`，只实现已测 semivar 表达。20 个已完成日收益、50%固定收缩、原储备与直接 `risk*.20/denominator` Decimal 顺序保持。生产没有导入 research。
- `coinquant/campaign.py` 的 `entry_fraction` 只对没有已归属战役的初始尺寸调用新函数。`.fraction` 和原 HOLD／topup 方法不修改；实际 native 资金、stop、手续费、资金费、强平及数量校验沿原路径。checkpoint绑定 `initial_sizing_profile`；缺失或其他风险规则在 restore 中明确拒绝，原 `_guard_strategy` 在恢复和启动清理前执行。已有状态不迁移、重标或重置；旧 forward 只使用原不可变消费者。
- `tests/session_venue.py` 原全正20日 synthetic fixture 改为正负交替，保持原 RMS 与新 semivar 均为 `.02`，保留原精确半成交数量边界。这不改变任何研究行情、钱包或经济证据。
- `tests/test_initial_downside.py` 两项必要检查：真实 session 的请求数量／持久目标／已归属持仓不重算初始尺寸／保护；旧规则与他规则 checkpoint 在任何 adapter recovery 之前以及启动 cleanup之前均拒绝。

若采用，根代理先应用补丁，再执行这两项必要资金与恢复检查；最后全量测试只执行一次。无需另一个完整账户重放。必要时只修正和补测受影响项。

`bridge.py` 在应用后一次读取完整795的原始 `downside-initial-sizing` journal，按每个实际新战役的20日收益、macro/primary风险与原完成时间，比较冻结研究函数、原 journal fraction 和生产纯函数，要求逐值 Decimal 完全一致。冻结源码原件和SHA放在本目录。必须选完整测量的原 journal；原 producer 保持6532476，当前提交不能冒充完整金融测量source。

运行入口示例（路径由根代理按实际完成文件指定）：

```bash
python3.13 private/coin-downside-integration/bridge.py --journal <completed-full-journal.json> --out <fresh-bridge-result.json>
```

该桥接只证明初始尺寸公式相同；不是原账户重新执行、native交易资格或新增alpha证明。原收益、尾损、MDD、年度集中度及下行风险用途失败继续报告。795原账户原件、原初始入场日志和本目录的生产桥接证据分开保留。
