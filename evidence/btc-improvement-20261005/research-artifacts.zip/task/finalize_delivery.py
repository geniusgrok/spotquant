"""Archive existing receipts once; never start an account or test here."""
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT = Path('/workspace')
TASK = ROOT / 'btc-improvement-20261005'
DEST = ROOT / 'spotquant/evidence/btc-improvement-20261005/research-artifacts.zip'


def main():
    if DEST.exists():
        raise ValueError('reuse immutable completed archive instead of rebuilding')
    software = {}
    for repo in ('coinquant', 'spotquant'):
        result = json.loads((TASK / 'software' / f'{repo}-result.json').read_text())
        if not result['passed'] or not result['source_unchanged']:
            raise ValueError('resolve only affected software failure before archive')
        software[repo] = result
    entries = []
    # Prune before traversal: raw synthetic state is private, retained and not
    # an executable historical-venue checkpoint. No large data-vault scan.
    for base, dirs, names in os.walk(TASK, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in {
            'preserved-synthetic-states', '__pycache__', 'private'})
        for name in sorted(names):
            p = Path(base) / name
            if p.is_symlink() or p.suffix not in {'.json', '.py', '.log', '.txt', '.md'}:
                continue
            entries.append((p, 'task/' + str(p.relative_to(TASK))))
    inputs = {
        'days.json': ROOT / 'btc-history-2018-2019-20261005/days.json',
        'features.json': ROOT / 'coinquant/evidence/btc-edge-20261003/task-artifacts/edge-features-v1.json',
        'fx.json': ROOT / 'starquant/data/usdcny_frankfurter.json',
        'schedule.json': ROOT / 'coinquant/research/session_schedule.json',
    }
    entries.extend((p, 'inputs/' + name) for name, p in inputs.items())
    controls = set()
    for p in TASK.glob('*assessment.json'):
        data = json.loads(p.read_text())
        parts = data if isinstance(data, list) else [data]
        for part in parts:
            for receipt in part.get('receipts', []):
                if receipt.get('reused'):
                    controls.add(receipt['path'])
    for original in sorted(controls):
        p = Path(original)
        if not p.is_file():
            raise ValueError('missing original comparison control: ' + original)
        entries.append((p, 'reused-controls/' + str(p.relative_to(ROOT))))
    for repo in ('coinquant', 'spotquant'):
        for name in ('improvement-RESULT.md', 'improvement-GUIDE.md', 'improvement-roadmap.json'):
            p = ROOT / repo / 'research' / name
            entries.append((p, 'delivery/' + repo + '/' + name))
    proposal = TASK / 'private/coin-downside-integration'
    for name in ('initial-downside-default.patch', 'README.md', 'prepared.json'):
        entries.append((proposal / name, 'unapplied-proposal/' + name))
    manifest = {'version': 1, 'files': [], 'raw_synthetic_state_included': False,
                'raw_state_retained': 'task/scratch-storage-receipt.json',
                'large_market_vault_reused_not_copied': True,
                'producer_receipts_are_original_not_delivery_head': True}
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p, member in entries:
            data = p.read_bytes()
            manifest['files'].append({'member': member, 'original_path': str(p),
                                      'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
            z.writestr(member, data)
        z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    # One necessary transfer-integrity check, no duplicated financial review.
    with zipfile.ZipFile(DEST) as z:
        if z.testzip() is not None:
            raise ValueError('archive CRC failure')
        members = len(z.infolist())
    data = DEST.read_bytes()
    inventory = json.loads((TASK / 'finite-wallet-inventory.json').read_text())
    accepted = [x for x in inventory if x['accepted_strategy']]
    full = json.loads((TASK / 'full-budget-result.json').read_text())
    receipt = {
        'repository': 'geniusgrok/spotquant',
        'path': 'evidence/btc-improvement-20261005/research-artifacts.zip',
        'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob_sha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
        'members': members,
        'accepted_finite_wallets': len(accepted),
        'accepted_finite_sessions': sum(x['sessions'] for x in accepted),
        'original_invalid_wallets_preserved': len(inventory) - len(accepted),
        'original_invalid_sessions': sum(x['sessions'] for x in inventory if not x['accepted_strategy']),
        'full_history_attempts': 1, 'full_history': full,
        'stage_participation_return_improvement_observed': True,
        'stage_spot_tail_improvement_observed': True,
        'independent_alpha_proven': False, 'whole_history_improvement_proven': False,
        'default_strategy_changed': False, 'native_qualified': False,
        'original_failures_preserved': True, 'raw_synthetic_states_archived': False,
        'software': software, 'remote_ci_pass_claimed': False,
    }
    for repo in ('coinquant', 'spotquant'):
        target = ROOT / repo / 'evidence/btc-improvement-20261005/archive.json'
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: receipt[k] for k in ('bytes', 'members', 'sha256', 'accepted_finite_wallets', 'accepted_finite_sessions')}))


if __name__ == '__main__':
    main()
