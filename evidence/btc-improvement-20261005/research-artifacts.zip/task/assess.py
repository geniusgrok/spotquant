"""Use accepted financial adapters once; do not run wallets or audit old money."""
import hashlib,json,math,sys
from pathlib import Path
sys.path.insert(0,'/workspace/spotquant')
from research.tradeoff_assessment import wallet_view,wallet_metrics,assess_comparison,DAY
R=Path(__file__).parent
spec=json.loads((R/'spec.json').read_text())
accepted=json.loads(Path('/workspace/btc-tradeoff-20261005/assessment-new-wallets.json').read_text())
prior={row['path']:row['sha256'] for row in accepted['receipts']}
packet=json.loads(Path(spec['daily_packet']).read_text())
benchmark={int(t)+DAY:float(v['close']) for t,v in packet['bars'].items()}
controls={
 'coin':{'2020-04-01':Path('/workspace/btc-search-next-20261005/accounts/2020-04-01-baseline.json'),'2023-10-01':Path('/workspace/btc-search-next-20261005/accounts/2023-10-01-baseline.json')},
 'spot':{'2020-04-01':Path('/workspace/btc-tradeoff-20261005/spot-recovery/2020-04-01-baseline.json'),'2023-10-01':Path('/workspace/btc-tradeoff-20261005/spot-accounts/2023-10-01-baseline.json')}}
simple={'2020-04-01':Path('/workspace/btc-tradeoff-20261005/coin-recovery/2020-04-01-uniform75.json'),'2023-10-01':Path('/workspace/btc-tradeoff-20261005/coin-recovery2/2023-10-01-uniform75.json')}
receipts=[]
def read(path,old=False):
 raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
 if old and prior.get(str(path))!=sha:raise ValueError('accepted source changed '+str(path))
 row=json.loads(raw);receipts.append(dict(path=str(path),sha256=sha,reused=old))
 return row,sha

def view(path,kind,old=False):
 row,sha=read(path,old)
 conditions=dict(market='Binance BTCUSDT '+kind,valuation_currency='USDT',reporting_currency='CNY',
   initial_state=dict(kind='cold_cash',cash_usdt=row['initial_usdt'],btc='0',pending_intents=[]),
   market_data=dict(daily_sha256=spec['daily_sha256'],original_frozen_market=True),
   fx=row['identity']['fx_sha256'],cost_model=dict(fee='.00075' if kind=='coin' else '.001',fx_each_way='.999',funding=kind=='coin'),
   execution_model=dict(read_ms=200,write_ms=1000,matcher='trade_print' if kind=='coin' else 'OHLC'),
   clock=dict(schedule_sha256=row['identity']['schedule_sha256'],window=row['window']))
 result=wallet_view(row,kind=kind,source=dict(path=str(path),sha256=sha,accepted=True),conditions=conditions)
 if kind=='coin':result['price_model']='original frozen minute/envelope and print matcher'
 return result
kind,policy=sys.argv[1:3]
comparisons=[]
for begin,end in spec['windows']:
 path=R/(sys.argv[3] if len(sys.argv)>3 else kind+'-accounts')/(begin+'-'+policy+'.json')
 base=view(controls[kind][begin],kind,True);cand=view(path,kind)
 risk=view(simple[begin],kind,True) if kind=='coin' else None
 comparisons.append(dict(window=[begin,end],**assess_comparison(base,cand,benchmark,purpose=spec['adoption'][kind+'_purpose'],accepted_costs=spec['adoption'],risk_control=risk)))
metrics=[c['metrics'] for c in comparisons]
B=[m['baseline'] for m in metrics];C=[m['candidate'] for m in metrics]
mean=lambda xs:sum(xs)/len(xs)
summary=dict(sum_delta_logwealth=sum(math.log1p(c['return_cny'])-math.log1p(b['return_cny']) for b,c in zip(B,C)),
 mean_mdd_change=mean([c['mdd_path_proxy']-b['mdd_path_proxy'] for b,c in zip(B,C)]),
 mean_es5_change=mean([c['daily_es5_loss_usdt']-b['daily_es5_loss_usdt'] for b,c in zip(B,C)]),
 mean_mdd_ratio=mean([c['mdd_path_proxy'] for c in C])/mean([b['mdd_path_proxy'] for b in B]),
 mean_es5_ratio=mean([c['daily_es5_loss_usdt'] for c in C])/mean([b['daily_es5_loss_usdt'] for b in B]))
if kind=='spot':
 summary['finite_reference_gate']=summary['sum_delta_logwealth']>=.02 and summary['mean_mdd_change']<=.04 and summary['mean_es5_change']<=.005
else:
 summary['finite_reference_gate']=min(summary['mean_mdd_ratio'],summary['mean_es5_ratio'])<=.9 and summary['sum_delta_logwealth']>=-.30
print(json.dumps(dict(kind=kind,policy=policy,summary=summary,metrics=[{k:{f:v[f] for f in ['return_cny','mdd_path_proxy','daily_es5_loss_usdt','beta_up_days','beta_down_days','fill_count']} for k,v in m.items()} for m in metrics]),indent=2))
result=dict(kind=kind,policy=policy,summary=summary,comparisons=comparisons,receipts=receipts,new_OOS=False,independent_wallets=True,full_history_claim=False)
with (R/(kind+'-'+policy+('-'+sys.argv[3] if len(sys.argv)>3 else '')+'-assessment.json')).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
