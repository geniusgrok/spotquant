"""One fixed, eight-wallet maximum development daily-proxy screen."""
from bisect import bisect_left
from decimal import Decimal as D
import hashlib
import json
from pathlib import Path
import time

from research.core_screen import Wallet, stamp
from research.edge_features import FeatureBook
from research.return_core import DAY, Forecast, PARAMETERS, serial

ROOT = Path('/workspace/btc-improvement-20261005')
ERAS = [('2020-01-01', '2022-01-01'), ('2022-01-01', '2024-01-01'), ('2024-01-01', '2026-09-19')]
BEGIN, END = stamp(ERAS[0][0]), stamp(ERAS[-1][1])


def measure(mode, forecast, bars, funding, stress):
    wallet = Wallet(10000, True, stress)
    funds = [r for r in funding if r[2] is not None and r[3] is None]
    times = [r[0] for r in funds]
    by_day = {r[0]: r for r in bars}
    era_rows, boundary = [], None
    consumed = regime = False
    owned_since = signal_day = None
    negative_days = decisions = forecasts = activations = 0
    for t, o, h, l, c in bars:
        if not BEGIN <= t < END:
            continue
        for j, (begin, end) in enumerate(ERAS):
            if t == stamp(begin):
                boundary = dict(equity=wallet.equity(o), fees=wallet.fees, funding=wallet.funding,
                                peak=wallet.equity(o), mdd=D(0), decisions=decisions,
                                forecasts=forecasts, activations=activations, era=j)
        # Funding before the modeled open+60s decision belongs to old inventory.
        for obs, _, rate, _ in funds[bisect_left(times, t):bisect_left(times, t+60000)]:
            payment = wallet.q*o*rate
            wallet.cash -= payment; wallet.funding += payment
        f = forecast.at(t+60000)
        prediction = f['prediction'] if f else None
        forecasts += int(prediction is not None)
        if f and signal_day != f['day_ms']:
            negative_days = negative_days+1 if prediction is not None and prediction <= 0 else 0
            signal_day = f['day_ms']
        if mode == 'cash':
            desired = False
        elif mode == 'momentum20':
            day = f['day_ms'] if f else None
            desired = bool(day is not None and day-20*DAY in by_day and by_day[day][4] > by_day[day-20*DAY][4])
        else:
            desired = prediction is not None and prediction > 0
            if mode == 'low-turnover' and wallet.q and prediction is not None and not desired:
                desired = t+60000 < owned_since+7*DAY or negative_days < 2
        if not desired:
            wallet.resize(D(0), o); consumed = regime = False; owned_since = None
        else:
            if not regime:
                consumed = False
            regime = True
            if not wallet.q and not consumed:
                capital = max(D(0), wallet.equity(o))
                wallet.resize(capital/o, o)
                owned_since = t+60000
                consumed = True; activations += 1
            elif wallet.q and mode != 'low-turnover':
                capital = max(D(0), wallet.equity(o)); desired_qty = capital/o
                if abs(desired_qty-wallet.q)*o >= max(D(5), capital*D('.05')):
                    wallet.resize(desired_qty, o)
        decisions += 1
        for obs, _, rate, _ in funds[bisect_left(times, t+60000):bisect_left(times, t+DAY)]:
            payment = wallet.q*o*rate
            wallet.cash -= payment; wallet.funding += payment
        if wallet.q:
            if l <= wallet.stop:
                wallet.resize(D(0), min(o, wallet.stop)); owned_since = None
            else:
                wallet.extreme = max(wallet.extreme, h)
                wallet.stop = max(wallet.stop, wallet.extreme*D('.75'))
        wallet.mark(t+DAY, c)
        if boundary is not None:
            boundary['peak'] = max(boundary['peak'], wallet.equity(c))
            boundary['mdd'] = max(boundary['mdd'], 1-wallet.equity(c)/boundary['peak'])
        if t+DAY == stamp(ERAS[boundary['era']][1]):
            eq = wallet.equity(c)
            fees = wallet.fees-boundary['fees']; paid = wallet.funding-boundary['funding']
            era_rows.append(dict(era=ERAS[boundary['era']], net_return=eq/boundary['equity']-1,
                realized_cost_added_back_return=(eq+fees+paid)/boundary['equity']-1,
                mdd_daily_proxy=boundary['mdd'], fees=fees, funding_paid=paid,
                decisions=decisions-boundary['decisions'], known_forecasts=forecasts-boundary['forecasts'],
                activations=activations-boundary['activations']))
        if wallet.closed:
            break
    wallet.resize(D(0), bars[next(i-1 for i, r in enumerate(bars) if r[0] >= END)][4])
    return dict(mode=mode, stress=stress, eras=era_rows, terminal_return=wallet.cash/10000-1,
                mdd_daily_proxy=wallet.mdd, fills=wallet.fills, fees=wallet.fees,
                funding_paid=wallet.funding, activations=activations, known_forecasts=forecasts,
                independent_initial_usdt='10000', insolvent=wallet.closed,
                account_entrant=False, native_qualified=False)


def main():
    out = ROOT/'return-screen.json'
    if out.exists():
        raise ValueError('reuse original screen, never overwrite/repeat')
    plan = dict(rule='fixed-cost-net-ridge-screen-v1', registered_before_run=True,
        eras=ERAS, parameters=PARAMETERS, first_expressions=['positive'],
        fallback='low-turnover only if any era gross cost-added-back>0 and net<=0',
        controls=['cash', 'momentum20'], stress='double fee and slippage, same model/features',
        max_wallets=8, mode='one continuous independently cold-funded proxy per mode/stress',
        funding='actual rates; daily spot-open mark proxy; predecision settlement old inventory; remainder before OHLC stop',
        qualification='Historical development, not new OOS/perpetual native/executable funding/margin proof',
        usefulness='Positive cost-net opportunity support and development risk/return vs price/cash control; no automatic adoption')
    (ROOT/'return-screen-spec.json').write_text(json.dumps(plan, indent=2)+'\n')
    spec = json.loads((ROOT/'spec.json').read_text())
    raw = Path(spec['daily_packet']).read_bytes()
    if hashlib.sha256(raw).hexdigest() != spec['daily_sha256']:
        raise ValueError('daily packet binding changed')
    packet = json.loads(raw)
    bars = [(int(t), *(D(row[k]) for k in ('open', 'high', 'low', 'close')))
            for t, row in sorted(packet['bars'].items(), key=lambda r: int(r[0]))]
    features = FeatureBook(Path(spec['features']), spec['features_sha256'])
    start = time.monotonic()
    forecast = Forecast(bars, features.records['funding'])
    results = [measure('positive', forecast, bars, features.records['funding'], stress) for stress in (False, True)]
    cost_failure = any(r['realized_cost_added_back_return'] > 0 and r['net_return'] <= 0 for case in results for r in case['eras'])
    if cost_failure:
        results.extend(measure('low-turnover', forecast, bars, features.records['funding'], stress) for stress in (False, True))
    for mode in ('cash', 'momentum20'):
        results.extend(measure(mode, forecast, bars, features.records['funding'], stress) for stress in (False, True))
    result = dict(plan=plan, results=results, lowturn_triggered=cost_failure,
        model_input_sha256=forecast.input_sha256, daily_sha256=spec['daily_sha256'],
        features_sha256=spec['features_sha256'], label_count=len(forecast.labels),
        first_supported_forecast=next((r for r in forecast.rows if r['prediction'] is not None), None),
        elapsed_seconds=time.monotonic()-start,
        source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (
            Path(__file__), Path('/workspace/coinquant/research/return_core.py'),
            Path('/workspace/coinquant/research/core_screen.py'))},
        historical_development_only=True, prospective_alpha=False, new795=0)
    out.write_text(json.dumps(serial(result), indent=2)+'\n')
    print(json.dumps(serial(dict(label_count=result['label_count'], first_supported_forecast=result['first_supported_forecast'],
        elapsed_seconds=result['elapsed_seconds'], lowturn_triggered=cost_failure,
        results=[{k:r[k] for k in ('mode', 'stress', 'terminal_return', 'mdd_daily_proxy', 'fills', 'activations', 'eras')} for r in results])), indent=2))


if __name__ == '__main__':
    main()
