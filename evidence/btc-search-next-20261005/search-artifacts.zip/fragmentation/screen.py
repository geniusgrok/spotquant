"""Fixed trade-size composition information screen; saved outcomes, no accounts."""
import csv, hashlib, importlib.util, io, json, statistics, time, zipfile
from decimal import Decimal as D
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
DAY = 86400000
PARENT = Path('/workspace/btc-search-20261005/screen-recovery-weekend.json')
RECEIPT = Path('/workspace/btc-decision-loop-20261004/artifacts/market.json.gz.receipt.json')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load_old_functions():
    path = Path('/workspace/btc-search-20261005/screen.py')
    spec = importlib.util.spec_from_file_location('saved_information_screen', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod, dict(path=str(path), sha256=sha(path.read_bytes()))

def main():
    started = time.monotonic()
    spec_raw = (OUT/'spec.json').read_bytes()
    parent_raw = PARENT.read_bytes()
    receipt_raw = RECEIPT.read_bytes()
    old = json.loads(parent_raw)
    receipt = json.loads(receipt_raw)
    bars, sources = {}, []
    compressed = 0
    for src in receipt['inputs']:
        if '/spotquant-market/klines/1d/' not in src['path']:
            continue
        p = Path(src['path']); raw = p.read_bytes()
        if sha(raw) != src['sha256']:
            raise ValueError('bound daily Kline changed '+str(p))
        compressed += len(raw)
        if compressed > 2_000_000:
            raise ValueError('registered small-input budget exceeded')
        sources.append(dict(path=str(p), bytes=len(raw), sha256=src['sha256']))
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = [n for n in z.namelist() if not n.endswith('/')]
            if len(names) != 1:
                raise ValueError('ambiguous daily archive')
            for row in csv.reader(io.StringIO(z.read(names[0]).decode())):
                if not row[0].isdigit():
                    continue
                stamp = int(row[0]); stamp = stamp//1000 if stamp>10**14 else stamp
                o,h,l,c,b,q,taker = map(D, [row[1],row[2],row[3],row[4],row[5],row[7],row[10]])
                count = int(row[8])
                if not (stamp%DAY==0 and 0<l<=min(o,c)<=max(o,c)<=h and b>0 and q>0 and count>0 and 0<=taker<=q):
                    raise ValueError('invalid original Kline composition')
                rec = dict(open=o,high=h,low=l,close=c,base_volume=b,quote_volume=q,trade_count=count,taker_buy_quote=taker,avg_quote_per_trade=q/count)
                if stamp in bars and bars[stamp] != rec:
                    raise ValueError('conflicting original daily row')
                bars[stamp] = rec
    composition = dict(format='bound-btcusdt-daily-composition-v1',sources=sources,parent_receipt_sha256=sha(receipt_raw),bars=bars,compressed_Kline_bytes_read=compressed,field_schema='Binance official public spot Kline CSV: base_volume[5], quote_volume[7], number_of_trades[8], taker_buy_quote[10]; no participant/order identity inferred')
    with (ROOT/'daily-composition.json').open('x') as f:
        json.dump(composition, f, default=str, indent=2); f.write('\n')
    mod, binding = load_old_functions()
    events, results = {}, {}
    for kind, saved in old['events'].items():
        rows = []
        for parent_row in saved:
            row = dict(parent_row)
            day = row['signal_day_ms']
            prior = [bars.get(t) for t in range(day-20*DAY,day,DAY)]
            if day not in bars or not all(prior):
                continue
            if row['available_ms'] > row['at_ms']:
                raise ValueError('future signal')
            bar = bars[day]
            threshold = statistics.median(p['avg_quote_per_trade'] for p in prior)
            row.update(fragmented=int(bar['avg_quote_per_trade']<=threshold and bar['close']>bar['open']),avg_quote_per_trade=bar['avg_quote_per_trade'],prior20_median_avg_quote_per_trade=threshold,trade_count=bar['trade_count'])
            for k in ['gross','net','stress_net','funding_cost']:
                row[k] = D(row[k])
            rows.append(row)
        halves = [rows[:len(rows)//2],rows[len(rows)//2:]]
        summary = mod.stats(rows,'fragmented')
        parts = [mod.stats(part,'fragmented') for part in halves]
        overall = mod.fit(rows,'fragmented')
        fits = [mod.fit(part,'fragmented') for part in halves]
        gates = dict(coverage=len(rows)>=.90*old['nonoverlap_intervals'],affected10=summary['selected']>=10,half3=all(p['selected']>=3 for p in parts),identifiable=overall['identifiable'] and all(f['identifiable'] for f in fits),negative_incremental=overall['effect'] is not None and overall['effect']<=-.005,negative_both_halves=all(f['effect'] is not None and f['effect']<0 for f in fits),avoided_net_and_uniform=all(p['avoided_net']>0 and p['avoided_net']>p['uniform_avoided_net'] for p in parts),stress_avoided=all(p['stress_net_mean'] is not None and p['stress_net_mean']<0 for p in parts),worse_lower_tail=all(p['downside_mean'] is not None and p['unselected_downside_mean'] is not None and p['downside_mean']<p['unselected_downside_mean'] for p in parts))
        supported = gates['coverage'] and gates['affected10'] and gates['half3']
        results[kind] = dict(status='INFORMATION_SCREEN_ENTRANT' if all(gates.values()) else 'REJECT_FIXED_EXPRESSION' if supported else 'SUPPORT_PENDING',gates=gates,summary=summary,halves=fits,half_statistics=parts,overall=overall,actual_accounts=0,adopted=False)
        events[kind] = rows
    result = dict(format='btc-trade-size-composition-screen-v1',results=results,events=events,input_sha256=sha(parent_raw),input_path=str(PARENT),spec_sha256=sha(spec_raw),producer_sha256=sha(Path(__file__).read_bytes()),reused_function=binding,source_manifest=sources,compressed_Kline_bytes_read=compressed,elapsed_seconds=time.monotonic()-started,new_accounts=0,new_sessions=0,full795_replays=0,public_requests=0,limits='Saved same original seven-day cost/funding/OHLC proxies and controls; no native/account/participant identity or prospective alpha proof. Historical development only.')
    with (OUT/'screen.json').open('x') as f:
        json.dump(result,f,default=str,indent=2); f.write('\n')
    print(json.dumps(dict(results=results,compressed_Kline_bytes_read=compressed,elapsed_seconds=result['elapsed_seconds']),indent=2))

if __name__ == '__main__':
    main()
