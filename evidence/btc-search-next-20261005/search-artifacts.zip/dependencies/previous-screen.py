"""Fixed information screens on reused public bars, never an account replay."""
from bisect import bisect_left
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal as D
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time

sys.path.insert(0, '/workspace/coinquant')
from research.continuous_routes import solve
from research.edge_features import FeatureBook

ROOT = Path(__file__).resolve().parent
DAY = 86400000
END = 1789862400000
CACHE = Path('/workspace/btc-decision-loop-20261004/artifacts/market.json.gz')
FEATURES = Path('/workspace/coinquant/evidence/btc-edge-20261003/task-artifacts/edge-features-v1.json')
SCHEDULE = Path('/workspace/coinquant/research/session_schedule.json')


def sha(raw):return hashlib.sha256(raw).hexdigest()


def price(bars, stamp, width):
    key = stamp//width*width
    o,h,l,c,*_ = bars[key]
    section=min(2,(stamp-key)//(width//3))
    weight=D(stamp-key-section*(width//3))/D(width//3)
    points=(o,h,l,c)
    return points[section]+(points[section+1]-points[section])*weight


def fit(rows, flag, extra=None):
    cols=[flag,'momentum','rms','day_return','spot_flow','perp_flow','log_volume','old_flow']
    if extra:cols.append(extra)
    if len(rows)<=len(cols)+1 or len({row[flag] for row in rows})!=2:
        return dict(identifiable=False,count=len(rows),effect=None)
    # Constant nuisance columns add no information and duplicate the intercept.
    # Remove only those columns, preserving the preregistered selected predicate.
    cols=[k for k in cols if k==flag or len({row[k] for row in rows})>1]
    xs=[[1.0,*[float(row[k]) for k in cols]] for row in rows]
    ys=[float(row['net']) for row in rows]
    width=len(xs[0])
    try:
        beta=solve([[sum(x[i]*x[j] for x in xs) for j in range(width)] for i in range(width)],
                   [sum(x[i]*y for x,y in zip(xs,ys)) for i in range(width)])
    except ValueError:return dict(identifiable=False,count=len(rows),effect=None)
    return dict(identifiable=True,count=len(rows),effect=beta[1],columns=['intercept',*cols],coefficients=beta,
                interpretation='descriptive conditional coefficient, not prospective alpha or causal identification')


def stats(rows,flag):
    selected=[r for r in rows if r[flag]]
    return dict(count=len(rows),selected=len(selected),
        gross_mean=float(statistics.mean(r['gross'] for r in selected)) if selected else None,
        net_mean=float(statistics.mean(r['net'] for r in selected)) if selected else None,
        stress_net_mean=float(statistics.mean(r['stress_net'] for r in selected)) if selected else None,
        downside_mean=float(statistics.mean(min(D(0),r['gross']) for r in selected)) if selected else None,
        unselected_downside_mean=float(statistics.mean(min(D(0),r['gross']) for r in rows if not r[flag])) if any(not r[flag] for r in rows) else None,
        avoided_net=float(-sum((r['net'] for r in selected),D(0))),
        uniform_avoided_net=float(-D(len(selected))/len(rows)*sum((r['net'] for r in rows),D(0))) if rows else None)


def evaluate(rows,total,flag):
    extra='absorption' if flag=='weekend' else None
    halves=[rows[:len(rows)//2],rows[len(rows)//2:]]
    fits=[fit(part,flag,extra) for part in halves]
    parts=[stats(part,flag) for part in halves]
    overall=fit(rows,flag,extra);summary=stats(rows,flag)
    checks=dict(coverage=len(rows)>=.90*total,count=summary['selected']>=10,
                halves=all(s['selected']>=3 for s in parts),identifiable=overall['identifiable'] and all(f['identifiable'] for f in fits))
    if flag=='absorption':
        checks.update(incremental=overall['effect'] is not None and overall['effect']>=.005,
                      same_sign_halves=all(f['effect'] is not None and f['effect']>0 for f in fits),
                      stress_net_halves=all(s['stress_net_mean'] is not None and s['stress_net_mean']>0 for s in parts))
    else:
        checks.update(incremental=overall['effect'] is not None and overall['effect']<=-.005,
                      same_sign_halves=all(f['effect'] is not None and f['effect']<0 for f in fits),
                      worse_downside_halves=all(s['downside_mean'] is not None and s['unselected_downside_mean'] is not None and s['downside_mean']<s['unselected_downside_mean'] for s in parts),
                      beneficial_risk_reduction_halves=all(s['avoided_net']>0 and s['avoided_net']>s['uniform_avoided_net'] for s in parts))
    return dict(status='INFORMATION_SCREEN_ENTRANT' if all(checks.values()) else 'REJECT_FIXED_MECHANISM',gates=checks,
                overall=overall,halves=fits,summary=summary,half_statistics=parts,default_adopted=False,actual_account_measured=False)


def main():
    started=time.monotonic();raw=CACHE.read_bytes();receipt=json.loads(Path(str(CACHE)+'.receipt.json').read_text())
    if sha(raw)!=receipt['parsed_sha256']:raise ValueError('cache bytes differ')
    for path,size,mtime,inode in receipt['fingerprints']:
        s=Path(path).stat()
        if (s.st_size,s.st_mtime_ns,s.st_ino)!=(size,mtime,inode):raise ValueError('cache raw fingerprint changed')
    packet=json.loads(gzip.decompress(raw))
    spot={int(k):tuple(map(D,v)) for k,v in packet['spot'].items()}
    coin={int(k):tuple(map(D,v)) for k,v in packet['coin4'].items()}
    funding=FeatureBook(FEATURES,'bf920626cc13653b8bbeafd171650cc1a76888e15aad0c20bbd1061fb41da512')
    funds=[(a,v) for a,b,v,cause in funding.records['funding'] if cause is None]
    times=[t for t,v in funds]
    all_starts=json.loads(SCHEDULE.read_text())['primary']['starts_ms'];starts=[];through=-1
    for t in all_starts:
        entry=t+60000
        if entry+7*DAY>=END:continue
        if entry>=through:starts.append(entry);through=entry+7*DAY
    events={'spot':[],'coin':[]};missing={'spot':Counter(),'coin':Counter()}
    for stamp in starts:
        day=(stamp-60000)//DAY*DAY-DAY
        prior=[spot.get(t) for t in range(day-20*DAY,day+DAY,DAY)]
        paired=[coin.get(t) for t in range(day,day+DAY,DAY//6)]
        if not all(prior) or not all(paired):
            for counts in missing.values():counts['missing_completed_history']+=1
            continue
        if day+DAY+60000>stamp:raise ValueError('future feature')
        row=spot[day];returns=[b[3]/a[3]-1 for a,b in zip(prior,prior[1:])]
        sf=2*row[5]/row[4]-1;pf=2*sum(r[5] for r in paired)/sum(r[4] for r in paired)-1
        median=statistics.median(r[4] for r in prior[:-1]);body=row[3]/row[0]-1
        absorption=sf<=D('-.10') and body>0 and row[4]>=median
        common=dict(at_ms=stamp,signal_day_ms=day,available_ms=day+DAY+60000,
                    absorption=int(absorption),weekend=int(datetime.fromtimestamp(stamp/1000,timezone.utc).weekday()>=5),
                    momentum=prior[-1][3]/prior[0][3]-1,rms=(sum(r*r for r in returns)/20).sqrt(),day_return=body,
                    spot_flow=sf,perp_flow=pf,log_volume=math.log(float(row[4]/median)),old_flow=int(pf>0 and sf<=0))
        for kind,bars,width,fee in [('spot',spot,DAY,D('.003')),('coin',coin,DAY//6,D('.0037'))]:
            try:a=price(bars,stamp,width);b=price(bars,stamp+7*DAY,width)
            except KeyError:missing[kind]['missing_price']+=1;continue
            funding_cost=D(0)
            if kind=='coin':
                window=funds[bisect_left(times,stamp):bisect_left(times,stamp+7*DAY)]
                if len(window)!=21:missing[kind]['missing_funding']+=1;continue
                try:funding_cost=sum((v*coin[t//width*width][0]/a for t,v in window),D(0))
                except KeyError:missing[kind]['missing_funding_mark']+=1;continue
            gross=b/a-1
            events[kind].append(dict(common,entry=a,exit=b,gross=gross,net=gross-fee-funding_cost,stress_net=gross-2*fee-funding_cost,funding_cost=funding_cost))
    results={kind:{flag:evaluate(rows,len(starts),flag) for flag in ['absorption','weekend']} for kind,rows in events.items()}
    result=dict(results=results,events=events,missing=missing,original_schedule_sessions=len(all_starts),nonoverlap_intervals=len(starts),
                identities=dict(cache_sha256=sha(raw),receipt_sha256=sha(Path(str(CACHE)+'.receipt.json').read_bytes()),schedule_sha256=sha(SCHEDULE.read_bytes()),
                    funding_sha256=sha(FEATURES.read_bytes()),spec_sha256=sha((ROOT/'search-spec.json').read_bytes()),program_sha256=sha(Path(__file__).read_bytes())),
                elapsed_seconds=time.monotonic()-started,new_account_runs=0,new_session_runs=0,full795_replays=0,
                limits='OHLC hindsight path and funding-mark proxies; no wallet/margin/fill proof; old development data, no prospective/native alpha')
    def serial(x):
        if isinstance(x,D):return str(x)
        if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
        if isinstance(x,list):return [serial(v) for v in x]
        return x
    with (ROOT/'screen.json').open('x') as stream:json.dump(serial(result),stream,indent=2);stream.write('\n')
    print(json.dumps(dict(results=results,missing=missing,independent_intervals=len(starts),elapsed_seconds=result['elapsed_seconds']),indent=2))


if __name__=='__main__':main()
