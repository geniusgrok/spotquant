"""Describe saved finite-feed timing and source semantics, never profitability."""
import collections,datetime,decimal,hashlib,json,math,pathlib,statistics
ROOT=pathlib.Path(__file__).parent
D=decimal.Decimal
capture=json.loads((ROOT/'stream-receipts.json').read_text())
def event_ns(s):
 base=s.removesuffix('Z');stem,_,fraction=base.partition('.')
 return int(datetime.datetime.fromisoformat(stem).replace(tzinfo=datetime.UTC).timestamp())*1000000000+int((fraction+'000000000')[:9])
def utc(ns):return datetime.datetime.fromtimestamp(ns/1e9,datetime.UTC).isoformat()
def summary(values):
 if not values:return None
 s=sorted(values)
 return {'count':len(s),'min':s[0],'median':statistics.median(s),'p95_nearest_rank':s[math.ceil(.95*len(s))-1],'max':s[-1]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
products={};messages={};acks={};all_rows=[]
for venue in ['coinbase','kraken']:
 rows=[json.loads(s) for s in (ROOT/(venue+'-messages.ndjson')).read_text().splitlines()];counter=collections.Counter();acks[venue]=[]
 for row in rows:
  x=json.loads(row['raw_text']);key=x.get('channel')+':'+x.get('type','') if 'channel'in x else x.get('type') or x.get('method');counter[key]+=1
  if venue=='coinbase' and x.get('type')=='subscriptions':acks[venue].append({'receipt_ns':row['receipt_ns'],'products':[p for c in x['channels'] if c['name']=='matches' for p in c['product_ids']]})
  if venue=='kraken' and x.get('method')=='subscribe':acks[venue].append({'receipt_ns':row['receipt_ns'],'success':x.get('success'),'symbol':x.get('result',{}).get('symbol'),'exchange_time_in':x.get('time_in'),'exchange_time_out':x.get('time_out')})
  events=[]
  if venue=='coinbase' and x.get('type') in ['match','last_match']:events=[x]
  elif venue=='kraken' and x.get('channel')=='trade' and x.get('type')=='update':events=x['data']
  for e in events:
   product=e.get('product_id') or e.get('symbol');time_s=e.get('time') or e.get('timestamp');ns=event_ns(time_s)
   normalized={'venue':venue,'product':product,'event_ns':ns,'event_utc':time_s,'receipt_ns':row['receipt_ns'],'receipt_utc':row['receipt_utc'],'observed_latency_seconds':(row['receipt_ns']-ns)/1e9,'trade_id':e['trade_id'],'source_message_type':x.get('type'),'raw_side':e['side'],'aggressor_side':('buy' if e['side']=='sell' else 'sell') if venue=='coinbase' else e['side'],'price':str(e['price']),'qty':str(e.get('size',e.get('qty'))),'sequence':e.get('sequence'),'raw_message_sha256':row['raw_sha256'],'semantics_binding':'coinbase-ws-channels.raw#Match' if venue=='coinbase' else 'kraken-ws-v2-trade-redirect-target.raw#Snapshot/Update'}
   all_rows.append(normalized);products.setdefault((venue,product),{'updates':[],'last_match':[],'heartbeats':[]})['last_match' if x.get('type')=='last_match' else 'updates'].append(normalized)
  if venue=='coinbase' and x.get('type')=='heartbeat':products.setdefault((venue,x['product_id']),{'updates':[],'last_match':[],'heartbeats':[]})['heartbeats'].append({'last_trade_id':x['last_trade_id'],'sequence':x['sequence'],'event_ns':event_ns(x['time']),'receipt_ns':row['receipt_ns']})
 messages[venue]=dict(counter)
(ROOT/'normalized-trades.ndjson').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in all_rows))
product_out=[]
for (venue,product),d in sorted(products.items()):
 updates=d['updates'];ids=[x['trade_id'] for x in updates];seen=set();duplicate_ids=[];nonincreasing=[];gaps=[]
 for i,n in enumerate(ids):
  if n in seen:duplicate_ids.append(n)
  seen.add(n)
  if i and n<=ids[i-1]:nonincreasing.append([ids[i-1],n])
  if i and n>ids[i-1]+1:gaps.append([ids[i-1]+1,n-1])
 prefix=None
 if d['last_match'] and updates and updates[0]['trade_id']>d['last_match'][-1]['trade_id']+1:prefix=[d['last_match'][-1]['trade_id']+1,updates[0]['trade_id']-1]
 side=collections.Counter(x['aggressor_side'] for x in updates)
 out={'venue':venue,'product':product,'observed_trade_updates':len(updates),'last_match_snapshot_count':len(d['last_match']),'heartbeats':len(d['heartbeats']),'direction_tokens_after_official_mapping':dict(side),'first_event_utc':updates[0]['event_utc'] if updates else None,'last_event_utc':updates[-1]['event_utc'] if updates else None,'first_trade_id':ids[0] if ids else None,'last_trade_id':ids[-1] if ids else None,'last_match_initial_id':d['last_match'][-1]['trade_id'] if d['last_match'] else None,'latency_seconds':summary([x['observed_latency_seconds'] for x in updates]),'duplicate_ids':duplicate_ids,'nonincreasing_adjacent_ids':nonincreasing,'interior_nonconsecutive_id_ranges':gaps,'prefix_nonconsecutive_id_range_from_last_match':prefix,'id_gaps_are_observed_ranges_not_certified_missing_trade_count':True,'last_heartbeat_id':d['heartbeats'][-1]['last_trade_id'] if d['heartbeats'] else None,'boundary_complete_guaranteed':False}
 if d['heartbeats']:
  out['heartbeat_receipt_utc_range']=[utc(d['heartbeats'][0]['receipt_ns']),utc(d['heartbeats'][-1]['receipt_ns'])]
  out['heartbeat_tail_id_above_last_observed_match']=(d['heartbeats'][-1]['last_trade_id']>ids[-1]) if ids else None
 product_out.append(out)
common_start=max(a['receipt_ns'] for rows in acks.values() for a in rows)
window_end=capture['start_ns']+30000000000
qualification={
 'status':'PUBLIC_STREAM_TRANSPORT_AND_WS_AGGRESSOR_SEMANTICS_AVAILABLE_FIXED_COMMON_WINDOW_COMPLETENESS_NOT_PROVEN',
 'spec_sha256':sha(ROOT/'spec.json'),'producer_sha256':sha(pathlib.Path(__file__)),'docs_gets':7,'docs_http_200':4,'original_http_308':3,'saved_redirect_target_gets':3,'previous_snapshot_gets_repeated':0,
 'websocket_connection_attempts':2,'websocket_upgrade_101':capture['successful_websocket_connections'],'reconnects':0,'capture_elapsed_seconds':capture['elapsed_seconds'],'registered_total_window_seconds':30,
 'receive_utc_start':capture['start_utc'],'receive_utc_end':capture['end_utc'],'independent_utc_receipt_days_with_prior_snapshot':1,'new_independent_day_added':False,
 'private_requests':0,'orders':0,'accounts':0,'historical_session_replays':0,'software_tests':0,
 'messages':messages,'subscription_acks':acks,
 'shared_after_all_subscription_acks_receive_interval':{'start_utc':utc(common_start),'registered_end_utc':utc(window_end),'seconds':(window_end-common_start)/1e9,'note':'Receive-time availability boundary, not proof of complete event-time window or predictive feature'},
 'semantics':{
 'coinbase_rest':{'bound':True,'side_role':'maker','mapping':{'buy':'aggressor sell','sell':'aggressor buy'},'source_file':'coinbase-rest-trades-redirect-target.raw','source_sha256':sha(ROOT/'coinbase-rest-trades-redirect-target.raw'),'quote':'The side of a trade indicates the maker order side.'},
 'coinbase_ws_match':{'bound':True,'side_role':'maker','mapping':{'buy':'aggressor sell','sell':'aggressor buy'},'source_file':'coinbase-ws-channels.raw','source_sha256':sha(ROOT/'coinbase-ws-channels.raw'),'quote':'The side field indicates the maker order side.','completeness_quote':'Messages can be dropped from this channel. Use the heartbeat channel to track the last trade ID and fetch trades that you missed from the REST API.','time_field':'time'},
 'kraken_ws_v2':{'bound':True,'side_role':'taker','mapping':{'buy':'aggressor buy','sell':'aggressor sell'},'source_file':'kraken-ws-v2-trade-redirect-target.raw','source_sha256':sha(ROOT/'kraken-ws-v2-trade-redirect-target.raw'),'quote':'The side of the taker order.','trade_id_quote':'Trade identifier is a sequence number, unique per book.','timestamp_quote':'The book order update timestamp.','timestamp_format':'RFC3339','multi_trade_messages_are_not_one_taker_order':True},
 'kraken_rest':{'bound':False,'source_file':'kraken-rest-trades-redirect-target.raw','source_sha256':sha(ROOT/'kraken-rest-trades-redirect-target.raw'),'schema':'[price,volume,time,buy/sell,market/limit,miscellaneous,trade_id]','reason':'Current official REST trade schema calls field buy/sell but does not explicitly identify maker vs taker; old REST snapshot remains quarantined for aggressor flow. Do not transfer WS semantics by assumption.'}},
 'products':product_out,
 'fixed_window_completeness_proven':False,'trade_channel_provides_continuous_bid_ask':False,'USDT_conversion_continuous_fresh_midquote_qualified':False,'mature_forward_outcomes':0,'predictive_alpha_proven':False,'economic_benefit_proven':False,
 'next_missing':['Independent prospective observation dates and matured outcomes','Timestamped continuous quote or book conversion legs with declared staleness limits, since trade prices are not L1 midquotes','Fixed event-window close and gap treatment / quarantine, heartbeat boundary handling, no data backfill before real receipt','Frozen cross-venue feature expression and comparison controls before economic screening; no inference from this one short sample']}
(ROOT/'qualification.json').write_text(json.dumps(qualification,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':qualification['status'],'common_seconds':qualification['shared_after_all_subscription_acks_receive_interval']['seconds'],'products':product_out},ensure_ascii=False))
