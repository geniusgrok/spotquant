"""Only three saved official 308 locations, once each; original receipts retained."""
import concurrent.futures,datetime,hashlib,json,pathlib,time,urllib.parse,urllib.request,urllib.error
ROOT=pathlib.Path(__file__).parent
prior=json.loads((ROOT/'docs-receipts.json').read_text());tasks=[]
for r in prior['receipts']:
 if r['status']==308:
  location=r['headers']['location'];url=urllib.parse.urljoin(r['url'],location)
  if urllib.parse.urlsplit(url).hostname!=urllib.parse.urlsplit(r['url']).hostname:raise ValueError('OFFICIAL_HOST_CHANGED')
  tasks.append((r['name']+'-redirect-target',url))
def utc(ns):return datetime.datetime.fromtimestamp(ns/1e9,datetime.UTC).isoformat()
spec={'registered_ns':time.time_ns(),'registered_utc':utc(time.time_ns()),'purpose':'Recover only three HTTP 308 official documentation locations to bind original required semantics; not a new candidate','prior_receipts_sha256':hashlib.sha256((ROOT/'docs-receipts.json').read_bytes()).hexdigest(),'approved_parent_additional_doc_get_budget':3,'tasks':tasks,'requests_each':1,'retries':0,'follow_additional_redirects':False,'max_body_bytes':2000000,'timeout_seconds':12}
(ROOT/'docs-redirect-recovery-spec.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
def fetch(task):
 name,url=task;start=time.time_ns();begin=time.monotonic();status=None;headers={};raw=b'';error=None
 try:
  op=urllib.request.build_opener(NoRedirect)
  try:r=op.open(urllib.request.Request(url,headers={'User-Agent':'BTCResearchQualification/1.0','Accept':'text/html'}),timeout=12)
  except urllib.error.HTTPError as e:r=e
  with r:
   status=r.status;headers=dict(r.headers);raw=r.read(2000001)
   if len(raw)>2000000:error='DOC_BODY_LIMIT_EXCEEDED'
 except Exception as e:error=f'{type(e).__name__}: {str(e)}'
 end=time.time_ns();(ROOT/(name+'.raw')).write_bytes(raw)
 rec={'name':name,'url':url,'method':'GET','status':status,'request_ns':start,'receipt_ns':end,'request_utc':utc(start),'receipt_utc':utc(end),'elapsed_seconds':time.monotonic()-begin,'headers':headers,'raw_file':name+'.raw','bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'error':error,'redirects_followed_in_this_request':0,'retries':0,'scope':'saved 308 target only'}
 (ROOT/(name+'.receipt.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(fetch,tasks))
out={'spec_sha256':hashlib.sha256((ROOT/'docs-redirect-recovery-spec.json').read_bytes()).hexdigest(),'public_document_gets':len(tasks),'private_requests':0,'retries':0,'receipts':results}
(ROOT/'docs-redirect-recovery-receipts.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['name','status','bytes','error']} for r in results]))
