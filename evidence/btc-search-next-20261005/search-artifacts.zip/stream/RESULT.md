# 跨现货场所公开连续成交：语义与固定窗能力检查

本轮补齐了真实公开流与主动方向语义两个具体缺口。Coinbase Exchange 与 Kraken WS v2 均通过继承 HTTP 代理完成公开 WS 连接，固定 30 秒后正常停止。取得了带真实接收时刻、交易所事件时刻、成交 ID 和已绑定主动方向的原消息，具备继续建设固定共同观察窗的实际接口条件。**这次仍不是完整跨场所预测信号资格或收益证据；新增独立接收日为 0，与先前快照合并仍只有 1 个真实 UTC 日。**

## 登记、数量和失败保留

`spec.json` 在请求前登记了四个官方文档 GET、最多两个公开连接、固定 30 秒窗口、握手超时、消息上限和全部公共 subscribe 内容。网页文本仅作数据，无私有订阅、认证账户或下单。环境 HTTP 政策为 unrestricted/enforced，继承代理与 TLS 验证均保留，没有直连 fallback。

最初四个官方文档 GET 中，一份 Coinbase WS 文档为 HTTP 200，另外三份旧官方路径为 HTTP 308，Location 和原正文已保存。根任务明确允许仅恢复这三个已保存官方目标，各 GET 一次：三个目标均 HTTP 200。**文档实际 GET 合计 7：4 个有效 200 正文，3 个原 308；没有重取已成功正文、继续跟随新重定向或搜索扩张。** 308 不能记为正文取得成功。原快照七 GET 原响应复用，没有重复行情 GET。

连接实际尝试 2 次，HTTP CONNECT 均 200，公开 WS Upgrade 均 101；无失败、重连、轮询替代或后台 daemon。固定总采集开始为 **2026-10-05 01:17:22.079374 UTC**，结束为 **01:17:52.083965 UTC**，实际经过 **30.004603 秒**。细微结束开销在固定窗口关闭后发生，没有延长接收窗口。两条订阅均确认后到登记截止的接收时间重合为 **27.357566 秒**，此数字只描述连接可用的接收边界。

Coinbase 原消息 276 条：182 match、90 heartbeat、3 last_match、1 subscriptions。Kraken 原消息 66 条：35 trade update、1 status update、28 heartbeat、2 subscribe acknowledgements。消息合计 342 条，保留原始文本与本机 receipt UTC/ns，记录 SHA256；原消息文件合计 153,199 字节。0 个私有请求、0 个订单、0 个账户测量、0 次历史会话重放、0 次软件测试，未修改两个仓库。

## 官方方向、时钟和 ID 语义

| 来源 | 本轮绑定的官方语义 | 处理 |
| --- | --- | --- |
| Coinbase REST product trades | “The side of a trade indicates the maker order side.” | buy 表示主动卖；sell 表示主动买。先前 REST token 可以按这份正文解释，但原来二十笔样本窗口不完整问题仍在。 |
| Coinbase WS match | “The side field indicates the maker order side.” | 同样反转；last_match 仅初始快照，不算本次新成交。 |
| Coinbase matches / heartbeat | matches 可能丢消息，官方要求用 heartbeat last_trade_id 追踪并从 REST 恢复缺失成交 | 本轮只检查可见 ID 边界，不补 GET。sequence 含更广泛订单事件，不能把其差值当作漏成交数。 |
| Kraken WS v2 trade | “The side of the taker order.” | buy/sell 直接代表主动买/卖；多笔 batch 不等于单一 taker order。 |
| Kraken WS v2 trade_id / timestamp | “Trade identifier is a sequence number, unique per book.”；RFC3339 的 “The book order update timestamp.” | 成交键限定场所与 book；保留交易所原 event timestamp，不以 HTTP Date 或收到时间替代。 |
| Kraken REST current official schema | 数组仅称 buy/sell，当前所取官方正文未明确 maker/taker 角色 | 旧 REST 方向仍未资格确认；不能将 WS 语义擅自移植到 REST。 |

语义对应原正文与 SHA256 在 `qualification.json`；原 HTTP 响应完整保留。Coinbase 第一份有效正文为 `coinbase-ws-channels.raw`，其余为三个 `*-redirect-target.raw`，原 308 为同名无 redirect-target 的 `.raw`。

## 本次可见的连续性和时刻

| 产品 | 新成交数 | 可见首次 / 末次 ID | 本机 receipt 减交易所 event 的中位 / 最大秒数 |
| --- | --- | --- | --- |
| Coinbase BTC-USD | 175 | 1,102,364,397 / 1,102,364,571 | 0.040909 / 0.105401 |
| Coinbase BTC-USDT | 0 | 初始 last_match 36,988,100；heartbeat 末 ID 同值 | 无新成交，不能生成新成交价格或流 |
| Coinbase USDT-USD | 7 | 148,832,946 / 148,832,952 | 0.038126 / 0.041416 |
| Kraken BTC/USD | 67 | 110,177,300 / 110,177,366 | 0.093790 / 0.117206 |
| Kraken USDT/USD | 3 | 84,151,175 / 84,151,177 | 0.086900 / 0.089502 |

两个 BTC/USD 腿均存在真实新成交，且观察到的内部 trade_id 连续、无重复或倒序。Coinbase 两个有成交产品从初始 last_match 到第一个新 match 也相邻；三个产品分别收到 30 条 heartbeat。BTC-USDT 在这些 heartbeat 期间 last_trade_id 没有增加。

这些是**可见区间事实**：既未观察到 ID 跳跃，也没有证明订阅前、固定窗末端及 Kraken 无 trade-ID heartbeat 的尾部不缺失。没有内在 ID 跳跃不能自动升级为全窗完备。上表时间差还含交易所与本机时钟误差，不是独立的网络延迟性能证明。两场所不同订阅确认时刻、末笔交易不同步，也不能用最后成交时间拼装一个完整共同窗。

`normalized-trades.ndjson` 保留官方映射后的方向、价格、数量、ID、event/receipt 时刻、原消息 SHA256，并标明初始 last_match。其用途是可审计的语义解释与后续固定窗建设，本轮没有计算流量预测表达或收益。

## 仍缺的条件与下一步价值

本轮确认公开流可以实际接通，不再需要把“能否取得主动方向与事件时钟”当作猜测。下一步建设可以采用这两条公开接口，但须在经济筛选前冻结固定事件窗口关闭方式、ID 缺口隔离、收到时间因果边界与陈旧限制。缺口恢复即使随后取得历史交易，也只能自真实收到时起可用，不能回填成更早已知信息。

USDT/USD 成交不是持续 L1 中间价；本次 Coinbase BTC-USDT 没有新成交，Kraken USDT/USD 仅 3 笔，也说明靠最近成交无法保证换算腿持续新鲜。要检验跨现货需求迁移，仍需带事件时间的连续报价或盘口、同步单位换算，以及新的独立观察日和成熟前向结果。此前快照与本次短流采集均在同一 UTC 日，不增加日级样本量；成熟前向结果为 0。

最终状态：`PUBLIC_STREAM_TRANSPORT_AND_WS_AGGRESSOR_SEMANTICS_AVAILABLE_FIXED_COMMON_WINDOW_COMPLETENESS_NOT_PROVEN`。`predictive_alpha_proven=false`、`economic_benefit_proven=false`。无需启动 795 历史账户重放；旧默认保持。
