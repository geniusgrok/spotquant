import concurrent.futures,datetime,hashlib,json,pathlib,time,urllib.request,urllib.error
ROOT=pathlib.Path(__file__).parent
spec=json.loads((ROOT/'spec.json').read_text())
def utc(ns):return datetime.datetime.fromtimestamp(ns/1e9,datetime.UTC).isoformat()
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
def fetch(task):
 name,url=task;start=time.time_ns();begin=time.monotonic();status=None;headers={};raw=b'';error=None
 try:
  op=urllib.request.build_opener(NoRedirect)
  try:r=op.open(urllib.request.Request(url,headers={'User-Agent':'BTCResearchQualification/1.0','Accept':'text/html'}),timeout=12)
  except urllib.error.HTTPError as e:r=e
  with r:
   status=r.status;headers=dict(r.headers);raw=r.read(2000001)
   if len(raw)>2000000:error='DOC_BODY_LIMIT_EXCEEDED'
 except Exception as e:error=f'{type(e).__name__}: {str(e)}'
 end=time.time_ns();(ROOT/(name+'.raw')).write_bytes(raw)
 rec={'name':name,'url':url,'method':'GET','status':status,'request_ns':start,'receipt_ns':end,'request_utc':utc(start),'receipt_utc':utc(end),'elapsed_seconds':time.monotonic()-begin,'headers':headers,'raw_file':name+'.raw','bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'error':error,'redirects_followed':0,'retries':0}
 (ROOT/(name+'.receipt.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(fetch,spec['official_document_gets']))
out={'spec_sha256':hashlib.sha256((ROOT/'spec.json').read_bytes()).hexdigest(),'public_document_gets':4,'private_requests':0,'retries':0,'receipts':results}
(ROOT/'docs-receipts.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['name','status','bytes','error']} for r in results]))
