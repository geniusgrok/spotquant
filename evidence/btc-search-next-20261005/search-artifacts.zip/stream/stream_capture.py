"""Single bounded public-feed capability capture; no reconnect or polling fallback."""
import base64,concurrent.futures,datetime,hashlib,json,os,pathlib,socket,ssl,struct,time,urllib.parse
ROOT=pathlib.Path(__file__).parent
SPEC=json.loads((ROOT/'spec.json').read_text())
def utc(ns):return datetime.datetime.fromtimestamp(ns/1e9,datetime.UTC).isoformat()
def stamp():
 n=time.time_ns();return {'receipt_ns':n,'receipt_utc':utc(n)}
def write_json(name,obj):(ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def remaining(deadline):
 seconds=deadline-time.monotonic()
 if seconds<=0:raise TimeoutError('REGISTERED_DEADLINE_REACHED')
 return seconds
class Reader:
 def __init__(self,sock,deadline):self.sock=sock;self.deadline=deadline;self.buf=b''
 def exact(self,n):
  while len(self.buf)<n:
   self.sock.settimeout(remaining(self.deadline));chunk=self.sock.recv(min(65536,max(4096,n-len(self.buf))))
   if not chunk:raise EOFError('REMOTE_CONNECTION_ENDED')
   self.buf+=chunk
  out,self.buf=self.buf[:n],self.buf[n:];return out
 def header(self):
  while b'\r\n\r\n' not in self.buf:
   if len(self.buf)>65536:raise ValueError('HANDSHAKE_HEADER_TOO_LARGE')
   self.sock.settimeout(remaining(self.deadline));chunk=self.sock.recv(4096)
   if not chunk:raise EOFError('HANDSHAKE_CONNECTION_ENDED')
   self.buf+=chunk
  a,self.buf=self.buf.split(b'\r\n\r\n',1);return a+b'\r\n\r\n'
def frame(sock,opcode,payload):
 mask=os.urandom(4);n=len(payload);header=bytes([0x80|opcode])
 if n<126:header+=bytes([0x80|n])
 elif n<65536:header+=bytes([0x80|126])+struct.pack('!H',n)
 else:header+=bytes([0x80|127])+struct.pack('!Q',n)
 sock.sendall(header+mask+bytes(v^mask[i%4] for i,v in enumerate(payload)))
def capture(task,global_start,global_deadline):
 venue=task['venue'];attempt=time.time_ns();rec={'venue':venue,'url':task['url'],'attempt_ns':attempt,'attempt_utc':utc(attempt),'connection_attempts':1,'reconnects':0,'private_request':False,'status':'ATTEMPTED','messages':0,'raw_messages_file':venue+'-messages.ndjson','subscribe':task['subscribe'],'proxy_used':True,'TLS_verified':False,'failures':[]};sock=None
 raw_path=ROOT/rec['raw_messages_file']
 try:
  u=urllib.parse.urlsplit(task['url']);proxy_raw=os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy') or os.environ.get('HTTP_PROXY') or os.environ.get('http_proxy')
  if not proxy_raw:raise RuntimeError('INHERITED_HTTP_PROXY_MISSING_NO_DIRECT_FALLBACK')
  proxy=urllib.parse.urlsplit(proxy_raw)
  if proxy.scheme!='http':raise RuntimeError('UNSUPPORTED_INHERITED_PROXY_SCHEME_NO_FALLBACK')
  hand_deadline=min(global_deadline,time.monotonic()+SPEC['handshake_timeout_seconds'])
  sock=socket.create_connection((proxy.hostname,proxy.port or 80),timeout=remaining(hand_deadline))
  connect=f'CONNECT {u.hostname}:443 HTTP/1.1\r\nHost: {u.hostname}:443\r\n'
  if proxy.username is not None:
   credential=urllib.parse.unquote(proxy.username)+':'+urllib.parse.unquote(proxy.password or '')
   connect+='Proxy-Authorization: Basic '+base64.b64encode(credential.encode()).decode()+'\r\n'
  sock.sendall((connect+'\r\n').encode());reader=Reader(sock,hand_deadline);proxy_response=reader.header()
  (ROOT/(venue+'-proxy-handshake.raw')).write_bytes(proxy_response)
  rec['proxy_http_status']=int(proxy_response.split(b' ',2)[1])
  if rec['proxy_http_status']!=200:raise RuntimeError('HTTP_PROXY_CONNECT_REFUSED')
  if reader.buf:raise RuntimeError('UNEXPECTED_PROXY_HANDSHAKE_TRAILING_BYTES')
  sock.settimeout(remaining(hand_deadline));sock=ssl.create_default_context().wrap_socket(sock,server_hostname=u.hostname);rec['TLS_verified']=True
  key=base64.b64encode(os.urandom(16)).decode();request=(f'GET {u.path or "/"} HTTP/1.1\r\nHost: {u.hostname}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\nUser-Agent: BTCResearchQualification/1.0\r\n\r\n')
  sock.sendall(request.encode());reader=Reader(sock,hand_deadline);response=reader.header();(ROOT/(venue+'-websocket-handshake.raw')).write_bytes(response)
  rec['websocket_http_status']=int(response.split(b' ',2)[1])
  if rec['websocket_http_status']!=101:raise RuntimeError('PUBLIC_WS_UPGRADE_NOT_ACCEPTED')
  headers={line.split(b':',1)[0].lower():line.split(b':',1)[1].strip() for line in response.split(b'\r\n')[1:] if b':' in line}
  expected=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest())
  if headers.get(b'sec-websocket-accept')!=expected:raise RuntimeError('INVALID_WEBSOCKET_ACCEPT')
  reader.deadline=global_deadline;connected=time.time_ns();rec.update({'status':'CONNECTED','connected_ns':connected,'connected_utc':utc(connected)})
  subscribe=json.dumps(task['subscribe'],separators=(',',':')).encode();frame(sock,1,subscribe);send=time.time_ns();rec['subscribe_sent_ns']=send;rec['subscribe_sent_utc']=utc(send)
  chunks=[];first_opcode=None
  with raw_path.open('w') as out:
   while time.monotonic()<global_deadline and rec['messages']<SPEC['max_messages_per_connection']:
    first=reader.exact(2);fin=bool(first[0]&0x80);opcode=first[0]&15;masked=bool(first[1]&0x80);length=first[1]&127
    if length==126:length=struct.unpack('!H',reader.exact(2))[0]
    elif length==127:length=struct.unpack('!Q',reader.exact(8))[0]
    if length>SPEC['max_message_bytes']:raise ValueError('REGISTERED_MESSAGE_BYTES_LIMIT')
    mask=reader.exact(4) if masked else None;payload=reader.exact(length)
    if mask:payload=bytes(v^mask[i%4] for i,v in enumerate(payload))
    if opcode==9:frame(sock,10,payload);continue
    if opcode==10:continue
    if opcode==8:
     rec['close_frame_payload_b64']=base64.b64encode(payload).decode();rec['status']='REMOTE_CLOSE';break
    if opcode in [1,2]:chunks=[payload];first_opcode=opcode
    elif opcode==0:
     if first_opcode is None:raise ValueError('ORPHAN_CONTINUATION_FRAME')
     chunks.append(payload)
    else:raise ValueError('UNSUPPORTED_FRAME_OPCODE')
    if sum(map(len,chunks))>SPEC['max_message_bytes']:raise ValueError('REGISTERED_MESSAGE_BYTES_LIMIT')
    if fin:
     payload=b''.join(chunks);item=stamp();item['opcode']=first_opcode;item['raw_sha256']=hashlib.sha256(payload).hexdigest()
     if first_opcode==1:item['raw_text']=payload.decode('utf-8')
     else:item['raw_b64']=base64.b64encode(payload).decode()
     out.write(json.dumps(item,ensure_ascii=False,separators=(',',':'))+'\n');out.flush();rec['messages']+=1;chunks=[];first_opcode=None
   if rec['messages']>=SPEC['max_messages_per_connection']:rec['status']='REGISTERED_MESSAGE_LIMIT_STOP'
   elif rec['status']=='CONNECTED':rec['status']='FIXED_WINDOW_STOP'
 except TimeoutError as e:
  if rec['status']=='CONNECTED' and time.monotonic()>=global_deadline:rec['status']='FIXED_WINDOW_STOP'
  else:rec['status']='CAPTURE_FAILED';rec['failures'].append({'time_utc':utc(time.time_ns()),'error':f'{type(e).__name__}: {e}'})
 except Exception as e:
  rec['status']='CAPTURE_FAILED';rec['failures'].append({'time_utc':utc(time.time_ns()),'error':f'{type(e).__name__}: {e}'})
 finally:
  if sock is not None:
   try:
    sock.settimeout(.5)
    if rec.get('websocket_http_status')==101:frame(sock,8,b'\x03\xe8')
   except Exception:pass
   sock.close()
  if not raw_path.exists():raw_path.write_text('')
  ended=time.time_ns();rec['ended_ns']=ended;rec['ended_utc']=utc(ended);rec['elapsed_seconds']=(ended-attempt)/1e9;rec['raw_messages_sha256']=hashlib.sha256(raw_path.read_bytes()).hexdigest();rec['raw_bytes']=raw_path.stat().st_size;write_json(venue+'-connection-receipt.json',rec)
 return rec
if __name__=='__main__':
 started=time.time_ns();mono=time.monotonic();deadline=mono+30
 write_json('capture-start.json',{'start_ns':started,'start_utc':utc(started),'window_seconds':30,'start_written_before_connections':True,'spec_sha256':hashlib.sha256((ROOT/'spec.json').read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:receipts=list(pool.map(lambda x:capture(x,mono,deadline),SPEC['connections']))
 ended=time.time_ns();result={'start_ns':started,'start_utc':utc(started),'end_ns':ended,'end_utc':utc(ended),'elapsed_seconds':time.monotonic()-mono,'connection_attempts':2,'successful_websocket_connections':sum(x.get('websocket_http_status')==101 for x in receipts),'reconnects':0,'private_requests':0,'account_measurements':0,'orders':0,'historical_session_replays':0,'software_tests':0,'independent_utc_receipt_days':len({started//86400000000000,ended//86400000000000}),'receipts':receipts}
 write_json('stream-receipts.json',result);print(json.dumps([{k:r.get(k) for k in ['venue','status','proxy_http_status','websocket_http_status','messages','failures']} for r in receipts],ensure_ascii=False))
