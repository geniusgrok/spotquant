# Coin fixed trade-size-composition: actual entry support

The preregistered information entrant reaches the next stage: its unchanged condition applies to **10 of 50 original independently closed campaigns**, with **6 / 4** in the original chronological halves. All 50 original initial-enter decisions have a complete, causally available feature. This establishes actual treatment support; it does not establish higher alpha, lower beta, candidate return, or default adoption.

The condition remains exactly: the latest fully completed BTCUSDT spot day's quote notional per matching trade is at or below the median of its preceding 20 completed days, and that completed day closes above its open. Each feature is available no earlier than its day end plus 60 seconds. There is no new cutoff, sign reversal, family expression, or threshold fit. Matching trade count does not identify investors, orders, institutions, or retail activity.

| Existing selected campaign attribution | First 25 original campaigns | Last 25 original campaigns | Total |
| --- | ---: | ---: | ---: |
| Selected campaigns | 6 | 4 | 10 |
| Primary / macro | 3 / 3 | 0 / 4 | 3 / 7 |
| Gross realized USDT | 2,872.02 | -2,284.89 | 587.13 |
| Commission USDT | -352.04 | -529.20 | -881.24 |
| Funding USDT | -225.14 | -1,268.40 | -1,493.53 |
| Net USDT | 2,294.84 | -4,082.49 | -1,787.65 |

These numbers reuse the accepted saved original campaign attribution. They are **not** the return from deleting these campaigns, money a veto would save, independently financed trade returns, or a new financial calculation of the whole account. Of the ten campaigns, four were profitable and six lost money. The three selected primary campaigns together earned +2,579.12 USDT; the seven selected macro campaigns together lost -4,366.77 USDT. Those retrospective family splits are descriptive and do not authorize narrowing the original expression to macro entries after seeing outcomes.

| Actual first initial enter (UTC) | Family | Saved net USDT |
| --- | --- | ---: |
| 2020-04-05 20:00:03 | Primary | 59.20 |
| 2020-04-13 21:00:03 | Macro | -75.41 |
| 2020-07-09 06:00:03 | Macro | -56.78 |
| 2021-07-26 11:00:27.8 | Primary | -6,377.65 |
| 2021-10-09 10:00:03 | Primary | 8,897.57 |
| 2022-07-20 14:00:03 | Macro | -152.09 |
| 2023-12-17 21:00:03 | Macro | 4,842.12 |
| 2024-08-30 03:00:03 | Macro | -5,096.80 |
| 2024-09-20 09:00:03 | Macro | 83.25 |
| 2025-03-06 11:00:03 | Macro | -3,911.06 |

The old first-sizing-to-enter bindings all agree with the earliest genuine enter of their original campaign, including initial orders that filled zero before a later same-campaign fill. No later fill date was substituted for the decision clock. For three selected campaigns the condition subsequently clears while the original same campaign is still held: approximately 73 hours after the April 2020 primary entry, 19 hours after the December 2023 macro entry, and 19 hours after the March 2025 macro entry. Those are original held-model observations, not proved flat-counterfactual opportunities. In particular, an unfilled macro can select a different epoch or lose priority to a primary opportunity.

## Minimal candidate hook

Static paths inspected: `coinquant/session.py:27` settles/reconciles exposure before the decision; `coinquant/lifecycle.py:582` branches by the current actual position and model action; `coinquant/campaign.py:126` decides ownership and `:134` consumes opportunities only when a fill is proved. A research-only wrapper of `Lifecycle.decide` is the smallest precise admission point:

1. Keep ordinary recovery, settlement, ownership reconciliation, cashflow audit, strategy checkpoint checks, and session limits. At the decision clock calculate the original action against the reconciled actual quantity.
2. Evaluate this feature only when the original action is `enter` and the real account is confirmed flat. No unresolved durable intents or possible entry remainders may be treated as flat. Preserve the original safety guards for working orders and changing snapshots.
3. For the selected completed day, record an `entry_veto` and return the unchanged snapshot before entry sizing, margin transfers, or new entry intents. Do not change `primary_consumed`, `macro_consumed`, `position_campaign`, market model state, or cold-start/bootstrap behavior. No fill means no new consumption.
4. For `hold`, `exit`, protective amendments, exposure recovery, risk reduction, or final cleanup, delegate the original path without querying or applying this entry feature. A real fill still requires the existing native protection and ownership proof, including fills racing the decision.
5. A later manually started session may reconsider the still-unconsumed opportunity if the same unchanged predicate is false. That timing, macro choice, cash compounding, actual quantity, funding, liquidation and fills must be measured in a real independent simulated wallet.

Do **not** attach the predicate to `may_enter`: that callback is also used inside held `top_up` and would change another strategy/risk behavior. Do not make `Campaign.active` disappear, consume the vetoed opportunity, blanket-block the whole session, or query optional spot data during held protection. Missing/noncausal candidate features should block only genuine new entry and be recorded as unavailable; they must not block recovery or exits. A live public data adapter's actual availability remains unqualified by this historical +60-second assumption.

## Decision and cost

Actual entry support passes all predeclared gates. A continuous independently financed account comparison is worth considering because the unchanged expression has both information support and actual entry treatments. The mixed original cash outcomes do not settle the result: an initial veto can delay or redirect entry instead of deleting an entire campaign. Do not rank or revise the expression using these ten rows. Account construction and fixed cross-era/stress decisions remain the parent task's responsibility; this support analysis starts no account or full-history replay.

The analysis took **0.22 seconds** and used small saved inputs, with **zero** new accounts, sessions, 795 replays, software tests, network requests, or large-market-vault reads. The original cash diagnosis was reused, not rerun. No repository/runtime/default changes were made.

Sources: [`spec.json`](spec.json), [`treatment.json`](treatment.json), [`treatment.py`](treatment.py); original accepted producer `37061a7f588f97cc16852551cab6cd2e51acb920` / Python `ba63895131db566e708a5c96cde4504beace39fa0bdd54881d039dd5b8ef4c50`. All history remains repeatedly used development data, not fresh out-of-sample proof.
