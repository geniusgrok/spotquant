"""Fixed-expression support on saved actual entry clocks; no account simulation."""
import bisect
import datetime
import gzip
import hashlib
import json
import statistics
import time
from decimal import Decimal as D
from pathlib import Path

OUT = Path(__file__).parent
DAY = 86400000
started = time.perf_counter()
spec_path = OUT / 'spec.json'
spec = json.loads(spec_path.read_text())
loaded = {}
bindings = []
for item in spec['inputs']:
    path = Path(item['path'])
    raw = path.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    if sha != item['sha256']:
        raise ValueError('registered small input changed: ' + str(path))
    bindings.append(dict(path=str(path), sha256=sha, bytes=len(raw)))
    loaded[path.name] = json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)
daily = loaded['daily-composition.json']['bars']
times = sorted(map(int, daily))
bars = {int(k): v for k, v in daily.items()}
diagnosis = loaded['diagnostic.json']
old_binding = {e['campaign']: e for e in loaded['price-flow-screen.json']['exhaustion']['all_rows']}
ledger = loaded['coin-baseline-projection.json.gz']['opportunity_ledger']
decisions = [e for e in ledger if e['event'] == 'decision']
if decisions != sorted(decisions, key=lambda e: e['at_ms']):
    raise ValueError('saved original clocks are not ordered')
entry_decisions = [e for e in decisions if e.get('action') == 'enter' and D(e['quantity_before']) == 0]

def feature(at_ms):
    day = ((at_ms - 60000) // DAY - 1) * DAY
    ix = bisect.bisect_left(times, day)
    if ix < 20 or ix >= len(times) or times[ix] != day:
        return None
    prior = times[ix - 20:ix]
    if prior != [day - i * DAY for i in range(20, 0, -1)]:
        return None
    b = bars[day]
    available = day + DAY + 60000
    if available > at_ms:
        raise ValueError('future partial day selected')
    avg = D(b['avg_quote_per_trade'])
    median = statistics.median(D(bars[t]['avg_quote_per_trade']) for t in prior)
    return dict(day_ms=day, available_ms=available, avg_quote_per_trade=avg,
                preceding20_median=median, composition_ratio=avg / median,
                daily_return=D(b['close']) / D(b['open']) - 1,
                selected=avg <= median and D(b['close']) > D(b['open']))

rows = []
for b in diagnosis['baskets']:
    identity = b['campaign']
    old = old_binding[identity]
    initial_candidates = [e for e in entry_decisions
                          if e['opportunity'] == identity and e['at_ms'] <= b['first_sizing']['at_ms']]
    if not initial_candidates:
        raise ValueError('missing initial actual enter')
    first = initial_candidates[0]
    bound = next(e for e in initial_candidates if e['at_ms'] == old['at_ms'])
    if bound['at_ms'] > b['first_sizing']['at_ms'] or b['first_sizing']['at_ms'] > b['at_ms']:
        raise ValueError('entry/sizing/fill ownership chronology differs')
    f = feature(first['at_ms'])
    rec = dict(campaign=identity, family=b['family'], first_enter_ms=first['at_ms'],
               old_bound_enter_ms=old['at_ms'], earliest_enter_matches_old_binding=first['at_ms'] == old['at_ms'],
               first_sizing_ms=b['first_sizing']['at_ms'], first_actual_fill_ms=b['at_ms'],
               closed_ms=b['closed_ms'], feature=f, selected=f['selected'] if f else None,
               saved_actual_gross_realized_usdt=D(b['REALIZED_PNL']),
               saved_actual_commission_usdt=D(b['COMMISSION']),
               saved_actual_funding_usdt=D(b['FUNDING_FEE']), saved_actual_net_usdt=D(b['net']),
               saved_buy_notional_usdt=D(b['buy_notional']), first_fill_fraction=D(b['first_fill_fraction']),
               baseline_later_feature_clear_while_same_campaign_held=None)
    if f and f['selected']:
        for later in decisions:
            if later['at_ms'] <= first['at_ms']:
                continue
            if b['closed_ms'] is not None and later['at_ms'] > b['closed_ms']:
                break
            if later['opportunity'] != identity or later.get('action') != 'hold':
                continue
            lf = feature(later['at_ms'])
            if lf and not lf['selected']:
                rec['baseline_later_feature_clear_while_same_campaign_held'] = dict(
                    at_ms=later['at_ms'], day_ms=lf['day_ms'], available_ms=lf['available_ms'],
                    hours_after_initial=D(later['at_ms'] - first['at_ms']) / 3600000,
                    limitation='Original held-model observation only; a flat counterfactual may choose another macro epoch or opportunity. No proved later fill.')
                break
    rows.append(rec)
rows.sort(key=lambda e: e['first_enter_ms'])
n = len(rows)
halves = [rows[:n // 2], rows[n // 2:]]

def summary(subset):
    selected = [r for r in subset if r['selected'] is True]
    out = dict(eligible_campaigns=len(subset), covered=sum(r['feature'] is not None for r in subset),
               affected_campaigns=len(selected), positive=sum(r['saved_actual_net_usdt'] > 0 for r in selected),
               negative=sum(r['saved_actual_net_usdt'] < 0 for r in selected),
               primary=sum(r['family'] == 'primary' for r in selected), macro=sum(r['family'] == 'macro' for r in selected),
               original_held_clear_observations=sum(r['baseline_later_feature_clear_while_same_campaign_held'] is not None for r in selected))
    for output, key in [('gross_realized_usdt', 'saved_actual_gross_realized_usdt'),
                        ('commission_usdt', 'saved_actual_commission_usdt'),
                        ('funding_usdt', 'saved_actual_funding_usdt'), ('net_usdt', 'saved_actual_net_usdt')]:
        out[output] = sum((r[key] for r in selected), D(0))
    return out

overall = summary(rows)
half_summaries = [summary(h) for h in halves]
gates = dict(coverage90=overall['covered'] >= D('.9') * n,
             affected10=overall['affected_campaigns'] >= 10,
             each_original_half3=all(h['affected_campaigns'] >= 3 for h in half_summaries))
report = dict(format=spec['format'], spec_sha256=hashlib.sha256(spec_path.read_bytes()).hexdigest(),
              producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), source_bindings=bindings,
              source_original_producer=diagnosis['parent_binding'],
              status='SUPPORT_SUFFICIENT_ACCOUNT_COMPARISON_WORTH_CONSIDERING' if all(gates.values()) else 'SUPPORT_PENDING',
              gates=gates, overall=overall, chronological_halves=half_summaries,
              by_family={family: summary([r for r in rows if r['family'] == family]) for family in ('primary', 'macro')},
              first_enter_binding_mismatches=[r['campaign'] for r in rows if not r['earliest_enter_matches_old_binding']],
              rows=rows, elapsed_seconds=time.perf_counter() - started,
              new_accounts=0, new_replayed_sessions=0, network_requests=0, software_tests=0, adopted=False,
              limitations=[
                  'Existing historical campaigns are development evidence, not fresh OOS.',
                  'Cash totals reuse accepted original campaign attribution, not avoided profits or candidate wallet returns.',
                  'A NEW-entry veto must leave opportunities unconsumed; later session entry, changed wallet sizing and macro choice require continuous account simulation.',
                  'Original later held observations do not establish a flat counterfactual opportunity or actual later fill.',
                  'No alpha/beta, CAGR or native qualification established by this support analysis.'])
(OUT / 'treatment.json').write_text(json.dumps(report, default=str, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('rows', 'source_bindings', 'limitations')}, default=str, indent=2))
