"""Apply unchanged registered phase gates once to completed finite wallets."""
import ast
import hashlib
import json
from decimal import Decimal as D
from pathlib import Path

OUT = Path(__file__).parent
spec = json.loads((OUT/'spec.json').read_text())
results = []
sources = []
def hook_ast(path):
    tree=ast.parse(path.read_text())
    return [ast.dump(n,include_attributes=False) for n in tree.body
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in ('feature','veto_permitted','policy_hook')]
recovery_hook_equal=hook_ast(OUT/'produce.py')==hook_ast(OUT/'produce-recovery.py')
for begin,end in spec['windows']:
    case = {}
    for policy in spec['policies']:
        p = OUT / (begin+'-'+policy+'.json')
        if begin=='2023-10-01' and policy=='fragmented-upday-new-entry-veto':
            recovered=OUT/'recovery'/p.name
            if recovered.exists():p=recovered
        raw = p.read_bytes()
        sources.append(dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest()))
        case[policy] = json.loads(raw)
    baseline = case['baseline'];candidate = case['fragmented-upday-new-entry-veto']
    excluded={'wrapper_sha256','task_scratch','recovery_registration_sha256','original_wrapper_sha256'}
    same_identity={k:v for k,v in baseline['identity'].items() if k not in excluded}=={k:v for k,v in candidate['identity'].items() if k not in excluded}
    if baseline['identity']['wrapper_sha256'] != candidate['identity']['wrapper_sha256']:
        same_identity=same_identity and recovery_hook_equal and candidate['identity'].get('original_wrapper_sha256')==baseline['identity']['wrapper_sha256']
    complete = all(x['complete_finite'] and x['audit']['passed'] and x['known_path'] and not x['pending_intents']
                   and x['session_count'] == x['registered_session_count'] for x in (baseline,candidate))
    journal = candidate['decision_journal']
    first_veto = {}
    for e in journal:
        if e['veto'] and e['feature'] and e['feature']['selected']:
            first_veto.setdefault(e['opportunity'],e)
    later = []
    for identity,first in first_veto.items():
        matches = [e for e in journal if e['at_ms'] > first['at_ms'] and e['opportunity'] == identity
                   and e.get('action') == 'enter' and D(e['quantity_before']) == 0 and D(e.get('quantity_after','0')) != 0]
        later.append(dict(opportunity=identity,first_veto_ms=first['at_ms'],
                          later_same_opportunity_fill_decision_ms=matches[0]['at_ms'] if matches else None,
                          limitation='Macro flat epochs can change; unmatched epochs are not proof that economic exposure never returned.'))
    metrics_available=all(x['return_cny'] is not None and x['final_cny'] is not None for x in (baseline,candidate))
    if not metrics_available:
        results.append(dict(window=[begin,end],complete_comparable=False,baseline_return_cny=baseline['return_cny'],candidate_return_cny=candidate['return_cny'],independent_veto_count=len(first_veto),causal_vetoes=False,return_noninferior=False,risk_noninferior=False,material=False,risk_route_wealth=False,risk_route_mdd=False,actual_sessions=baseline['session_count']+candidate['session_count'],failure=candidate['failure']))
        continue
    rb,rc = D(baseline['return_cny']),D(candidate['return_cny'])
    mb,mc = D(baseline['mdd']),D(candidate['mdd'])
    results.append(dict(window=[begin,end],complete_comparable=complete and same_identity,
                        baseline_return_cny=rb,candidate_return_cny=rc,return_change_pp=(rc-rb)*100,
                        baseline_final_cny=D(baseline['final_cny']),candidate_final_cny=D(candidate['final_cny']),
                        baseline_mdd=mb,candidate_mdd=mc,mdd_ratio=mc/mb if mb else None,
                        return_noninferior=rc>=rb,risk_noninferior=mc<=mb,
                        material=rc>=rb+D('.02') or mb>0 and mc<=mb*D('.8'),
                        risk_route_wealth=D(candidate['final_cny'])>=D(baseline['final_cny'])*D('.95'),
                        risk_route_mdd=mc<=mb*D('.8'),
                        independent_veto_count=len(first_veto),veto_poll_count=sum(e['veto'] for e in journal),
                        causal_vetoes=all(e['feature']['available_ms']<=e['at_ms'] and D(e['quantity_before'])==0 for e in first_veto.values()),
                        veto_then_later_entry=later,
                        actual_sessions=baseline['session_count']+candidate['session_count'],
                        bounded_minutes=[baseline['bounded_minutes'],candidate['bounded_minutes']],
                        hindsight_bounded=[baseline['hindsight_bounded'],candidate['hindsight_bounded']],
                        baseline_trade_fills=len(baseline['trades']),candidate_trade_fills=len(candidate['trades'])))
support=all(r['independent_veto_count']>=1 for r in results)
complete=all(r['complete_comparable'] and r['causal_vetoes'] for r in results)
return_route=all(r['return_noninferior'] and r['risk_noninferior'] for r in results) and any(r['material'] for r in results)
risk_route=all(r['risk_route_wealth'] and r['risk_route_mdd'] for r in results)
status='BLOCKED_ACCOUNT_INTEGRITY' if not complete else 'SUPPORT_PENDING' if not support else 'PHASE_GATE_PASS_NEEDS_PARENT_FIXED_CONTROLS_DECISION' if return_route or risk_route else 'REJECT_FIXED_EXPRESSION_FINITE_PHASE'
report=dict(status=status,results=results,complete_comparable=complete,treatment_support=support,
            return_route=return_route,risk_route=risk_route,raw_sources=sources,
            spec_sha256=hashlib.sha256((OUT/'spec.json').read_bytes()).hexdigest(),
            evaluator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            accepted_account_cases=len(spec['windows'])*len(spec['policies']),
            new_account_instances=5 if (OUT/'recovery/summary.json').exists() else 4,
            total_finite_sessions=sum(r['actual_sessions'] for r in results),new795=0,
            cache_only_recovery_economic_hook_equal=recovery_hook_equal,
            adopted=False,prospective_alpha_proven=False,native_qualified=False,
            limits='Selected based on original actual signal timing; reused development history and minute/envelope proxy. No lifetime/default economic adoption, stress/control expansion or out-of-sample proof.')
(OUT/'assessment.json').write_text(json.dumps(report,default=str,indent=2)+'\n')
print(json.dumps(report,default=str,indent=2))
