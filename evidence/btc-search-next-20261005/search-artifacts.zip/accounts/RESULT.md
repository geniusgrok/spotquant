# Coin fixed fragmentation: finite actual-account phase rejected

The fixed expression passed the information screen and the original-campaign support screen, but **fails the preregistered two-window actual-account phase**. Keep the incumbent default. Do not expand this failed phase into stress, risk controls, new windows, or a threshold grid. The positive second quarter does not repair the first quarter's much larger loss of return.

| Independent CNY 10,000 wallet window | Baseline return | Veto return | Return change | Baseline minute/envelope MDD | Veto MDD |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2020-04-01 to 2020-07-01 exclusive | +29.1427% | -13.2920% | -42.4347 pp | 34.5599% | 27.8354% |
| 2023-10-01 to 2024-01-01 exclusive | +181.8225% | +187.2414% | +5.4189 pp | 22.1154% | 22.1154% |

Both baseline and candidate wallets in both windows completed their original registered sessions and passed the project's actual trade/quantity/realized-income/commission/funding/wallet audit. Known paths are true; these four accepted wallets have no bounded or unknown mark minutes. These remain simulated research accounts with historical minute/envelope valuation and the original print execution model, not native execution proof. All four received independent capital and state; neither account curve was scaled or reused as another wallet.

Dates were selected **before account measurement**: the first flagged actual entry in each original chronological half, then its natural quarter. Those are original 2020 Q2 and 2023 Q4, not whichever periods earn most. The four earlier core quarters do not contain these original flagged entries and were not remeasured. The once-registered expression, feature lag, thresholds, session starts, funds, fee, funding, FX, read/write timing and print matcher stayed fixed. Historical evidence is development data, not fresh out-of-sample validation.

The return route required both candidate returns to be no worse, both MDDs no worse, and a material improvement in at least one quarter. The risk route required both final wealth values at least 95% of baseline and both MDDs at most 80% of baseline. **Neither route passes.** In 2020 Q2 the candidate retains only 67.14% of baseline final wealth and its MDD ratio is 80.54%, above the registered 80% ceiling. The 2023 Q4 return improves, but its MDD does not decline. No original gate is relaxed.

## Veto really changes timing, not whole-campaign deletion

The candidate vetoed two independent eligible opportunities in 2020 Q2 and one in 2023 Q4. The **78 + 39 = 117 veto polls represent only three opportunities**. In all three the same opportunity subsequently entered and actually filled:

| Opportunity | First rejected entry (UTC) | Later filled entry decision (UTC) | Delay |
| --- | --- | --- | ---: |
| Primary `1585785600000` | 2020-04-05 20:00:03 | 2020-04-08 21:00:03 | 73 hours |
| Macro `-1586811602800` | 2020-04-13 21:00:03 | 2020-04-20 04:00:03 | 151 hours |
| Macro `-1702846802800` | 2023-12-17 21:00:03 | 2023-12-18 16:00:03 | 19 hours |

This directly shows why summing original selected campaigns' net cash cannot establish candidate savings. A genuine NEW-entry veto leaves opportunities unconsumed, shifts fills and timing, changes subsequent sizing and cash paths, and can later admit the same opportunity. The original selected-campaign attribution was descriptive; the table above comes from the new independently financed, continuous actual account paths.

The candidate's research-only `Lifecycle.decide` wrapper applies after normal settlement/recovery, ownership reconciliation and wallet audit, only to the original genuine `enter` action when actual quantity is zero with no pending intent or possible entry remainder. It does not query or apply the feature to held topups, exit, protection or recovery. `may_enter`, checkpoint strategy guards, source checks and actual-fill consumption remain intact. Six focused precondition cases and two causal boundary cases ran at startup; recovery repeats the same small checks. No broad or full software suite ran.

## One resource failure, only that case recovered

The original 2023 Q4 candidate stopped after seven completed sessions when a conservative task-cache preflight counted retained old-quarter derived packs plus the next day's CSV upper bound against the 500 MB limit. It stopped during unattended advancement **before** the next runtime session. The blocked raw receipt, original producer, original evaluator failure, and scratch state remain saved. Its null final mark means that blocked instance does not establish a completed financial result.

Only that candidate was remeasured. The other three accepted wallets and their completed ledger audits were reused. The complete in-memory `ResearchExchange` venue had no restorable checkpoint after process exit, so this was a new independent wallet for the affected case, not a claimed resumed account. Only task-owned regenerable 2020 derived print packs were evicted (165,815,872 bytes); no account state, persistent shared cache, old evidence, HOME, UID or locks were removed or changed.

The recovered producer uses the existing ZIP-hash-named parsed packs read-only, unpacks at most one day into its task-private directory, and uses the saved array count for the binary resource estimate when a pack exists. This is a CPU/disk cache fix: it does not change prices, prints, virtual time, strategy or the financial contract. Both producer identities are retained; the original and recovered feature, veto-permission and policy-hook ASTs are equal, and all economic source/input identities match. The evaluator's original null-value failure is retained and corrected to bind only the explicit affected-case recovery. No additional financial scenario was launched.

## Work counts and time

- Four accepted wallet cases contain **114** finite sessions: 29 + 29 + 28 + 28. There were **five constructed wallet instances** because the failed candidate's separate instance completed seven sessions before its resource failure. Total actually executed and completed runtime sessions were **121**, plus one failed unattended advancement before a runtime invocation.
- Account case execution summed **148.91 seconds**; the two strictly serial producer batches took **149.12 seconds** combined. From phase registration through the recovered producer's final receipt, including implementation and resource diagnosis, wall time was **507.03 seconds (8 min 27 sec)**. These are separate from software testing.
- UID 12000 stayed strictly serial throughout. There were **zero new 795 replays, network requests, full software tests, new dates, capital sweeps or extra stress/control accounts**.

`assessment.json`'s `total_finite_sessions=114` counts the accepted comparison cases; `execution-metrics.json` separately records all 121 executed sessions including the blocked instance. Source remained clean and frozen at Coin main `abfec606a235ae88bf5e691965435ab6c50d1fd1`, Python digest `509f579454f814ae329e8e3fcd01a0599465cf75cc29a5ca29b25249b0c861c2`. No repository runtime or default was changed.

Evidence: [`spec.json`](spec.json), [`assessment.json`](assessment.json), [`execution-metrics.json`](execution-metrics.json), [`summary.json`](summary.json), [`recovery/registration.json`](recovery/registration.json), [`recovery/summary.json`](recovery/summary.json). The assessment binds the exact four accepted raw files and hashes; the original blocked raw case is retained alongside them.
