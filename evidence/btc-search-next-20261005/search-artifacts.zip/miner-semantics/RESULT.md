# 矿工收入构成语义资格补充

**仍为 SEMANTICS_PENDING_NO_ECONOMIC_SCREEN。** 独立预登记的这次阶段补充了 fee 与 issuance 的通用燃烧口径，但没有解决 UTC daily bucket 的起末，以及 BTC 专用的 subsidy/fee/burn 映射。原阶段的 spec、qualification、raw 和 404 均保留不动。

取得以下官方原文：

- `fees.md:295`："The sum of all fees paid to miners, transaction validators, stakers and/or block producers that interval. In certain cryptonetworks, fees might be burned (destroyed), but they are still accounted for in this metric."
- `fees.md:304`："This metric includes fees that are burned as part of the protocol."
- `fees.md:305`："For chains that use median time, the day is defined using it, otherwise, it’s defined using the block’s timestamps."
- `issuance.md:132`："The sum of all new supply units issued that day."
- `issuance.md:141`："In this metric, compared to the continuous one, all sources of issuance are taken into account."
- `issuance.md:142`："This metric is the gross issuance: if in the same day, 100 units are issued and 10 burned, this metric’s value will be 100, not 90 (which would be the net issuance)."

因此通用 `IssTotNtv` 是 gross new issuance，不能按 net supply change 解读；`FeeTotNtv` 可能含不归生产者的协议燃烧费用，不能对所有链直接等同实际矿工收入。BTC 专用映射与日标签起末不能凭常识或数据行数推定。这些原文也未绑定实际发布延迟或历史 vintage。

第三次 GET 取自前阶段官方 overview 已存在的 API v4 链接，并采用官方说明的 `.md` 形式。结果 HTTP200，但正文为 **Page Not Found**，作为软失败保存；没有追逐其 suggested pages、sitemap、ask 接口或猜其他 URL。

本阶段合计 **3 个官方 docs GET、55724 B**，TLS/proxy 保持。新 [qualification-augmentation.json](qualification-augmentation.json) 绑定原资格 SHA-256 `a6d227ef670213095c21c51b15ecdd5d15dd362c04be59a11a1b9c54aebb24a1`，并保留精确原文、行号、文件 SHA 与 receipts。没有重新取得 API 历史、计算收益、运行账户/795/软件测试或修改仓库。
