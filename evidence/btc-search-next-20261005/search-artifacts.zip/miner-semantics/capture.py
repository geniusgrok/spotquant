"""Bounded public GET receipt capture; no retries, redirects or private requests."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

import requests

ROOT = Path(__file__).parent
url, name, kind = sys.argv[1:]
receipts = json.loads((ROOT / 'receipts.json').read_text())
spec = json.loads((ROOT / 'input-spec.json').read_text())
assert len(receipts) < spec['requests']['max_GET']
assert sum(x['kind'] == kind for x in receipts) < (
    spec['requests']['max_definition_GET'] if kind == 'definition'
    else spec['requests']['max_timeseries_GET']
)
assert url.startswith(tuple('https://' + x + '/' for x in spec['requests']['allowed_hosts']))
assert not any(x['url'] == url for x in receipts)
remaining = spec['requests']['raw_body_total_bytes_cap'] - sum(x['bytes'] for x in receipts)
assert remaining > 0
receipt = {
    'url': url, 'kind': kind, 'request_utc': datetime.datetime.now(datetime.UTC).isoformat(),
    'file': name, 'TLS_verification': True, 'redirects': False, 'private_request': False,
}
body = b''
try:
    with requests.get(url, timeout=(15, 35), allow_redirects=False, stream=True) as response:
        receipt['status_code'] = response.status_code
        receipt['headers'] = {k: v for k, v in response.headers.items() if k.lower() in
                              {'date', 'content-type', 'etag', 'last-modified'}}
        for chunk in response.iter_content(chunk_size=8192):
            if len(body) + len(chunk) > remaining:
                body += chunk[:remaining - len(body)]
                receipt['error'] = 'AGGREGATE_BODY_BUDGET_EXCEEDED_TRUNCATED'
                break
            body += chunk
except requests.RequestException as exc:
    receipt['error'] = type(exc).__name__ + ': ' + str(exc)
receipt['receipt_utc'] = datetime.datetime.now(datetime.UTC).isoformat()
receipt['bytes'] = len(body)
receipt['sha256'] = hashlib.sha256(body).hexdigest()
(ROOT / name).write_bytes(body)
receipts.append(receipt)
(ROOT / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
print(json.dumps(receipt))
