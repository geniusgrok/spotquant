> For the complete documentation index, see [llms.txt](https://gitbook-docs.coinmetrics.io/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://gitbook-docs.coinmetrics.io/network-data/network-data-overview/fees-and-revenue/fees.md).

# Fees

### Contents

* [Mean Tx Fee per Byte (native units) (FeeByteMeanNtv)](#mean-tx-fee-per-byte-native-units)
* [Mean Tx Fee (native units, USD) (FeeMeanNtv, FeeMeanUSD)](#feemean)
* [Median Tx Fee (native units, USD) (FeeMedNtv, FeeMedUSD)](#feemed)
* [Mean Miner Tip (native units, USD) (FeePrioMeanNtv, FeePrioMeanUSD)](#feepriomean)
* [Median Miner Tip (native units, USD) (FeePrioMedNtv, FeePrioMedUSD)](#e)
* [Total Miner Tips (native units, USD) (FeePrioTotNtv, FeePrioTotUSD)](#feepriotot)
* [Miner Revenue from Fees (%) (FeeRevPct)](#feerevpct)
* [Total Fees (native units, USD) (FeeTotNtv, FeeTotUSD)](#feetot)
* [Mean Tx Fee per Block Weight (native units) (FeeWghtMeanNtv)](#feewghtmean)
* [Mean Base Fee (Wei) (GasBaseBlkMean)](#gasbaseblkmean)
* [Mean Effective Execution Gas Price (Gwei) (GasPriceMean)](#gaspricmean)
* [Mean Transaction Effective Execution Gas Price (Gwei) (GasPriceTxMean)](#gaspricetxmean)
* [Block Gas Limit (GasLmtBlk)](#gaslmtblk)
* [Mean Block Gas Limit (GasLmtBlkMean)](#gasbaseblkmean)
* [Tx Gas Limit (GasLmtTx)](#gaslmttx)
* [Mean Gas Limit per Tx (GasLmtTxMean)](#gaslmttxmean)
* [Tx Gas Used (GasUsedTx)](#gasusedtx)
* [Mean Gas Used per Tx (GasUsedTxMean)](#gaslmttxmean-1)
* [Network State Storage Fees](#network-state-storage-fees)

## Mean Tx Fee per Byte (native units)

### Definition

The mean transaction fee per byte of all blocks that interval in native units.

| Name                                | MetricID       | Unit         | Interval |
| ----------------------------------- | -------------- | ------------ | -------- |
| Mean Tx Fee per Byte (native units) | FeeByteMeanNtv | Native units | 1 day    |

### Details

* 0-fee transactions are included
* Computed as FeeTotNtv / BlkSizeByte
* If there were no transactions that interval, this metric isn’t computed
* For SOL, this metric does not include vote transactions. Includes successful and unsuccessful transactions.

### Chart

<figure><img src="https://2398817338-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-MO23j33wWGzm0NrZseN%2Fuploads%2Fgit-blob-fa336c9b10258065e3b8c882621c908bca7f57dc%2Fimage.png?alt=media" alt=""><figcaption></figcaption></figure>

### Asset Specific Details

Any blockchain where users are paying for block space rather than computation.

### Examples

During the BTC mining ban in China in 2021, we saw an influx of miners turn off their operations so the block interval time increased significantly due to less hash power on the network. In effect, because less miners were online, we saw a spike in the mean transaction fee per byte since less miners were available to include transactions in the blocks, therefore transactions costs higher before the next difficulty adjustment.

### Release History

* Release Version: NDP-EOD 4.8 (Nov, 2020)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeeByteMeanNtv>" %}

## Mean Tx Fee <a href="#feemean" id="feemean"></a>

### Definition

The mean fee per transaction in native units in that interval.

| Name                       | MetricID   | Unit         | Interval      |
| -------------------------- | ---------- | ------------ | ------------- |
| Mean Tx Fee (native units) | FeeMeanNtv | Native units | 1 day, 1 hour |
| Mean Tx Fee (USD)          | FeeMeanUSD | USD          | 1 day, 1 hour |

### Details

* 0-fee transactions are included
* If there were no transactions that interval, this metric isn’t computed
* FeeMeanUSD is Computed as FeeMeanNtv \* PriceUSD
* The price used is the daily close price

### Asset Specific Details

* Any blockchain where users are paying for block space rather than computation.
* For SOL, this metric does not include vote transactions. Includes successful and unsuccessful transactions.

### Release History

* Release Version: NDP-EOD 4.8 (Nov, 2020)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeeByteMeanNtv>" %}

## Median Tx Fee <a href="#feemed" id="feemed"></a>

### Definition

The median fee per transaction in native units that interval.

| Name                         | MetricID  | Unit         | Interval      |
| ---------------------------- | --------- | ------------ | ------------- |
| Median Tx Fee (native units) | FeeMedNtv | Native units | 1 day, 1 hour |
| Median Tx Fee (USD)          | FeeMedUSD | USD          | 1 day, 1 hour |

### Details

* 0-fee transactions are included
* If there were no transactions that interval, this metric isn’t computed
* If there’s an even number of fees, the median is computed by averaging the middle values of the sorted fees
* FeeMedUSD is computed as FeeMedNtv \* PriceUSD
* Price used is the daily close price
* 0-fee transactions are included

### Asset Specific Details

* For SOL, this metric does not include vote transactions. Includes successful and unsuccessful transactions.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeeMedNtv>" %}

## Mean Miner Tip <a href="#feepriomean" id="feepriomean"></a>

### Definition

The average (mean) Miner Tip, a.k.a. *priority fee,* paid for transactions during a time interval (e.g. 1 day).

The concept of a Miner Tip was introduced as part of [EIP-1559](https://notes.ethereum.org/@vbuterin/eip-1559-faq) and it represents the portion of the total transaction fees that rewards miners. This serves as an added incentive so that miners prioritize transactions that have opted-in and paid a tip. The other portion is called the Base Fee, and it is burnt (destroyed) after the transaction is included in a block.

Ethereum post-1559 requires users to pay for a Base Fee as a prerequisite to include transactions in a block. The Base Fee can go up or down on the basis of the size (in gas units) of the previous block. In times of congestion, where blocks are sequentially increasing in size, paying a Base Fee does not guarantee that a transaction will be included in a block. In such events, users can optionally pay an additional miner tip to nudge miners to include their transactions in their block.

| Name                          | MetricID       | Unit         | Interval      |
| ----------------------------- | -------------- | ------------ | ------------- |
| Mean Miner Tip (native units) | FeePrioMeanNtv | Native units | 1 day, 1 hour |
| Mean Miner Tip (USD)          | FeePrioMeanUSD | USD          | 1 day, 1 hour |

### Details

* EIP1559 was a highly anticipated proposal that changes how transaction fees are priced in Ethereum, as well as the dynamics of block sizes.
* The proposal activated on the Ethereum Network in August of 2021 and marks one of the biggest changes in monetary policy in the history of cryptoassets.
* Instead of the legacy *gas price*, 1559 splits transaction fees into two distinct fields: a Base Fee and an optional Tip (also known as a *Priority Fee*).
* This metric calculates the average Tip in transactions that have occurred in the network over the measuring period (e.g. 1 day).
* For a thorough review of EIP1559 and the design of its pricing mechanism, please refer to [this paper](https://arxiv.org/pdf/2012.00854.pdf).

### Chart

<figure><img src="https://2398817338-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-MO23j33wWGzm0NrZseN%2Fuploads%2Fgit-blob-593d0854e92188556af8820aacf08f92f542ad31%2Fimage.png?alt=media" alt=""><figcaption></figcaption></figure>

### Interpretation

* Miner tips are optional and showcase demand for block space (i.e. transaction settlement) in the short-term.
* Changes in average miner tip over time can depict changes in demand for block space. When miner tips have to be used due to Base Fees not being enough, the fee market reverts back to first-price auction (like other Crypto assets).
* In such scenarios, this metric should see an increase as users bid up fees as they did prior to the activation of EIP1559.

### Asset-Specific Details

* Only available for ETH, this metric was introduced following the EIP-1559 upgrade

### Examples

We saw a major drop in gas used in Spring 2022 due to the built in difficulty bomb. In the early days of Ethereum, core developers implemented this difficulty bomb mechanism to hold everyone accountable to the PoS timeline. The idea was that the bomb would go off making mining extremely difficult/unprofitable. So each time the bomb started to go off, less blocks were being found so less gas used. Therefore, less priority fees were needed since network activity was low.

### Release History

* Released in the 5.0 release of NDP (August, 2021)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeePrioMeanNtv>" %}

## Median Miner Tip <a href="#e" id="e"></a>

### Definition

The median Miner Tip, a.k.a. *priority fee,* paid for transactions during a time interval (e.g. 1 day), shown in native units (e.g. units of ETH).

The concept of a Miner Tip was introduced as part of [EIP-1559](https://notes.ethereum.org/@vbuterin/eip-1559-faq) and it represents the portion of the total transaction fees that rewards miners. This serves as an added incentive so that miners prioritize transactions that have opted-in and paid a tip. The other portion is called the Base Fee, and it is burnt (destroyed) after the transaction is included in a block.

Ethereum post-1559 requires users to pay for a Base Fee as a prerequisite to include transactions in a block. The Base Fee can go up or down on the basis of the size (in gas units) of the previous block. In times of congestion, where blocks are sequentially increasing in size, paying a Base Fee does not guarantee that a transaction will be included in a block. In such events, users can optionally pay an additional miner tip to nudge miners to include their transactions in their block.

| Name                            | MetricID      | Unit         | Interval      |
| ------------------------------- | ------------- | ------------ | ------------- |
| Median Miner Tip (native units) | FeePrioMedNtv | Native units | 1 day, 1 hour |
| Median Miner Tip (USD)          | FeePrioMedUSD | USD          | 1 day, 1 hour |

### Details

* EIP1559 was a highly anticipated proposal that changes how transaction fees are priced in Ethereum, as well as the dynamics of block sizes.
* The proposal activated on the Ethereum Network in August of 2021 and marks one of the biggest changes in monetary policy in the history of cryptoassets.
* Instead of the legacy *gas price*, 1559 splits transaction fees into two distinct fields: a Base Fee and an optional Tip (also known as a *Priority Fee*).
* This metric calculates the median Tip in transactions that have occurred in the network over the measuring period (e.g. 1 day).
* For a thorough review of EIP1559 and the design of its pricing mechanism, please refer to [this paper](https://arxiv.org/pdf/2012.00854.pdf).

### Asset-Specific Details

* Only available for ETH, this metric was introduced following the EIP-1559 upgrade
* For Solana transactions, priority fees are fees paid on top of the 5000 lamport base fee per signature. This includes both setting a higher price per compute unit and setting a higher total compute budget

### Examples

* We saw a major drop in gas used in Spring 2022 due to the built in difficulty bomb. In the early days of Ethereum, core developers implemented this difficulty bomb mechanism to hold everyone accountable to the PoS timeline. The idea was that the bomb would go off making mining extremely difficult/unprofitable. So each time the bomb started to go off, less blocks were being found so less gas used. Therefore, less priority fees were needed since network activity was low.

### Interpretation

* Miner tips are optional and showcase demand for block space (i.e. transaction settlement) in the short-term.
* Changes in median miner tip over time can depict changes in demand for block space. When miner tips have to be used due to Base Fees not being enough, the fee market reverts back to first-price auction (like other cryptoassets).
* In such scenarios, this metric should see an increase as users bid up fees as they did prior to the activation of EIP1559.

### Release History

* Released in the 5.0 release of NDP (August, 2021)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeePrioMedNtv>" %}

## Total Miner Tips <a href="#feepriotot" id="feepriotot"></a>

### Definition

The total value of Miner Tips, a.k.a. *priority fees,* paid for all transactions during a time interval (e.g. 1 day), shown in native units (e.g. units of ETH).

The concept of a Miner Tip was introduced as part of [EIP-1559](https://notes.ethereum.org/@vbuterin/eip-1559-faq) and it represents the portion of the total transaction fees that rewards miners. This serves as an added incentive so that miners prioritize transactions that have opted-in and paid a tip. The other portion is called the Base Fee, and it is burnt (destroyed) after the transaction is included in a block.

Ethereum post-1559 requires users to pay for a Base Fee as a prerequisite to include transactions in a block. The Base Fee can go up or down on the basis of the size (in gas units) of the previous block. In times of congestion, where blocks are sequentially increasing in size, paying a Base Fee does not guarantee that a transaction will be included in a block. In such events, users can optionally pay an additional miner tip to nudge miners to include their transactions in their block.

| Name                            | MetricID      | Unit         | Interval      |
| ------------------------------- | ------------- | ------------ | ------------- |
| Total Miner Tips (native units) | FeePrioTotNtv | Native units | 1 day, 1 hour |
| Total Miner Tips (USD)          | FeePrioTotUSD | USD          | 1 day, 1 hour |

### Details

* EIP1559 was a highly anticipated proposal that changes how transaction fees are priced in Ethereum, as well as the dynamics of block sizes.
* The proposal activated on the Ethereum Network in August of 2021 and marks one of the biggest changes in monetary policy in the history of cryptoassets.
* Instead of the legacy *gas price*, 1559 splits transaction fees into two distinct fields: a Base Fee and an optional Tip (also known as a *Priority Fee*).
* This metric calculates the total value paid for Tips in transactions that have occurred in the network over the measuring period (e.g. 1 day).
* For a thorough review of EIP1559 and the design of its pricing mechanism, please refer to [this paper](https://arxiv.org/pdf/2012.00854.pdf).

### Asset Specific Details

* For Solana transactions, priority fees are fees paid on top of the 5000 lamport base fee per signature. This includes both setting a higher price per compute unit and setting a higher total compute budget

### Interpretation

* Miner tips are optional and showcase demand for block space (i.e. transaction settlement) in the short-term.
* Changes in total miner tip over time can depict changes in demand for block space. When miner tips have to be used due to Base Fees not being enough, the fee market reverts back to first-price auction (like other cryptoassets).
* In such scenarios, this metric should see an increase as users bid up fees as they did prior to the activation of EIP1559.

### Release History

* Released in the 5.0 release of NDP (August, 2021)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeePrioTotNtv>" %}

## Revenue from Fees (%) <a href="#feerevpct" id="feerevpct"></a>

### Definition

The percentage of revenue derived from fees that interval. This is equal to the fees divided by the revenue.

| Name                  | MetricID  | Unit          | Interval |
| --------------------- | --------- | ------------- | -------- |
| Revenue from Fees (%) | FeeRevPct | Dimensionless | 1 day    |

### Details

* For most assets: computed as `100 × FeeTotNtv / RevNtv`
* For Ethereum post-London hardfork (EIP-1559): computed as `100 × FeePrioTotNtv / RevNtv`, using priority fees only, since base fees are burned and do not accrue to validators.
* For Solana: computed as `100 × (RevNtv − IssContNtv − FeeStorTotNtv) / RevNtv`

### Release History

* Released in the 1.0 release of NDP

### Interpretation

For blockchains aiming to retain a limited supply by weaning themselves off an issuance-based validator subsidy, fees are expected to be a critical part of the long-term security model. This metric gives you an indication of how prepared a blockchain is to transition from an issuance-based compensation model for validators to a fee-based model.

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeeRevPct>" %}

## Total Fees <a href="#feetot" id="feetot"></a>

### Definition

The sum of all fees paid to miners, transaction validators, stakers and/or block producers that interval. In certain cryptonetworks, fees might be burned (destroyed), but they are still accounted for in this metric.

| Name                      | MetricID  | Unit         | Interval      |
| ------------------------- | --------- | ------------ | ------------- |
| Total Fees (native units) | FeeTotNtv | Native units | 1 day, 1 hour |
| Total Fees (USD)          | FeeTotUSD | USD          | 1 day, 1 hour |

### Details

* This metric includes fees that are burned as part of the protocol.
* For chains that use median time, the day is defined using it, otherwise, it’s defined using the block’s timestamps.

### Asset Specific Details

* For Solana transactions, priority fees are fees paid on top of the 5000 lamport base fee per signature. This includes both setting a higher price per compute unit and setting a higher total compute budget.
* For Ethereum this fee includes fees for transaction execution as well as blob fees. It is made up of base fees, priority fees and blob fees. Fees paid for the execution of transactions only can be calculated by subtracting [total blob fees](#total-blob-fees) from total fees.

### Release History

* Released in the 1.0 release of NDP

### Interpretation

Fees in USD terms (see Fees, Transaction, Median, USD; Fees, Transaction, Mean, USD, and Fees, Total, USD) are often biased by volatility in unit price, making it difficult to determine trends in fee pressure. Evaluating fees in native unit terms removes the noise from exchange rate volatility and enables more consistent time series comparisons.

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeeTotNtv>" %}

## Mean Tx Fee per Block Weight (native units) <a href="#feewghtmean" id="feewghtmean"></a>

### Definition

The mean transaction fee per weight unit in that interval in native units. Weight is a dimensionless measure of a block’s “size”. It is only applicable for chains that use SegWit (segregated witness).

| Name                                        | MetricID       | Unit         | Interval |
| ------------------------------------------- | -------------- | ------------ | -------- |
| Mean Tx Fee per Block Weight (native units) | FeeWghtMeanNtv | Native units | 1 day    |

### Details

* For more details on SegWit, check the [Bitcoin Wiki Entry](https://en.bitcoin.it/wiki/Segregated_Witness)

### Asset-Specific Details

* Only relevant to cryptoassets that have implemented Segregated Witness (SegWit)

### Examples

* During the BTC mining ban in China in 2021, we saw an influx of miners turn off their operations so the block interval time increased significantly due to less hash power on the network. In effect, because less miners were online, we saw a spike in the mean transaction fee per byte since less miners were available to include transactions in the blocks, therefore transactions costs were more competitive.

### Release History

* Release Version: NDP-EOD 4.8 (Nov, 2020)

### Interpretation

* The Segwit upgrade replaced the concept of block size with block weight . While Bitcoins block weight is 4 MB, the mean block time is still slower than other chains such as Litecoin resulting

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeeWghtMeanNtv>" %}

## Mean Base Fee (Wei) <a href="#gasbaseblkmean" id="gasbaseblkmean"></a>

### Definition

The average (mean) Base Fee paid for transactions during a time interval (e.g. 1 day), shown in the smallest denomination of Ether, [Wei units](https://ethdocs.org/en/latest/ether.html#denominations).

The concept of a Base Fee was introduced as part of [EIP-1559](https://notes.ethereum.org/@vbuterin/eip-1559-faq) and it represents the portion of the total transaction fees that is destroyed and taken out of circulation (i.e. *burnt)*. Ethereum post-1559 requires users to pay for a Base Fee as a prerequisite to include transactions in a block. The Base Fee can go up or down on the basis of the size (in gas units) of the previous block. In times of congestion, where blocks are sequentially increasing in size, paying a Base Fee does not guarantee that a transaction will be included in a block. In such events, users can optionally pay an additional Miner Tip to nudge miners to include their transactions in their block.

| Name                | MetricID       | Unit | Interval |
| ------------------- | -------------- | ---- | -------- |
| Mean Base Fee (Wei) | GasBaseBlkMean | Wei  | 1 day    |

### Details

* EIP1559 was a highly anticipated proposal that changes how transaction fees are priced in Ethereum, as well as the dynamics of block sizes.
* The proposal activated on the Ethereum Network in August of 2021 and marks one of the biggest changes in monetary policy in the history of cryptoassets.
* Instead of the legacy *gas price*, 1559 splits transaction fees into two distinct fields: a Base Fee and an optional Tip (also known as a *Priority Fee*).
* This metric calculates the average Base Fee in transactions that have occurred in the network over the measuring period (e.g. 1 day).
* For a thorough review of EIP1559 and the design of its pricing mechanism, please refer to [this paper](https://arxiv.org/pdf/2012.00854.pdf).

### Interpretation

* Base Fees fluctuate on the basis of network utilization. If there is high demand for transaction settlement, Base Fees go up, and as demand fades, Base Fees go down.
* The pricing of Base Fees is inextricably connected to size of blocks in the blockchain. Upon the the activation fo EIP-1559, the maximum size of blocks in Ethereum (measured in units of gas) was more than doubled to 30M.
* Although blocks are larger, this pricing mechanism attempts to target an average of 15M gas units per block, and an exponential function is used to increase or decrease Base Fees so that this target is hit.
* If, for example, the previous block was above 15M units of gas, the base fee is increased. If there are several sequential blocks above the 15M target, Base Fees increase exponentially which disincentivizes users from transacting.
* Changes in Base Fees over time can depict changes in demand for block space. When miner tips have to be used due to Base Fees not being enough, this is a sign of network congestion.

### Release History

* Released in the 5.0 release of NDP (August, 2021)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasBaseBlkMean>" %}

## Mean Effective Execution Gas Price (Gwei) <a href="#gaspricmean" id="gaspricmean"></a>

### Definition

The gas-weighted mean effective execution gas price for eligible transactions during the interval, shown in [Gwei](https://ethdocs.org/en/latest/ether.html#denominations). It is calculated as total execution fees divided by total charged execution gas used, so high-gas transactions influence the average proportionally; transactions with zero or negligible execution fees are included via their gas usage.

| Name                               | MetricID     | Unit | Interval       |
| ---------------------------------- | ------------ | ---- | -------------- |
| Mean Effective Execution Gas Price | GasPriceMean | Gwei | 1 block, 1 day |

### Details

* Uses execution fees only (excludes blob fees and OP Stack L1 data and operator fees).
* Excludes recognized fee-free OP Stack deposits and BSC system transactions.
* For the per-transaction arithmetic mean, see [GasPriceTxMean](#gaspricetxmean).
* If there are no eligible transactions in the interval, this metric isn’t computed.

### Asset-Specific Details

* Available for EVM-compatible assets.

### Interpretation

* Reflects the average price users paid per unit of execution gas during the interval, weighted by how much gas each transaction consumed.
* Useful for measuring fee pressure on execution-layer block space. When network demand is high, effective execution gas prices tend to rise.
* Captures the full effective execution price users paid (base fee plus priority fee), not just the base fee alone. For the base fee component only, see [GasBaseBlkMean](#gasbaseblkmean).

### Release History

* Released in ND-8430 (September, 2026)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasPriceMean>" %}

## Mean Transaction Effective Execution Gas Price (Gwei) <a href="#gaspricetxmean" id="gaspricetxmean"></a>

### Definition

The arithmetic mean of the effective execution gas price for eligible transactions during the interval, shown in [Gwei](https://ethdocs.org/en/latest/ether.html#denominations). Each transaction counts equally, including those with zero or negligible execution fees, unlike [GasPriceMean](#gaspricmean) which is gas-weighted.

| Name                                           | MetricID       | Unit | Interval       |
| ---------------------------------------------- | -------------- | ---- | -------------- |
| Mean Transaction Effective Execution Gas Price | GasPriceTxMean | Gwei | 1 block, 1 day |

### Details

* Uses execution fees only (excludes blob fees and OP Stack L1 data and operator fees).
* Excludes recognized fee-free OP Stack deposits and BSC system transactions.
* For the gas-weighted mean effective execution gas price, see [GasPriceMean](#gaspricmean).
* If there are no eligible transactions in the interval, this metric isn’t computed.

### Asset-Specific Details

* Available for EVM-compatible assets.

### Interpretation

* Reflects the typical effective execution gas price paid by an individual transaction during the interval.
* When transaction gas usage is heterogeneous, [GasPriceTxMean](#gaspricetxmean) can differ materially from [GasPriceMean](#gaspricmean). For example, a block with one low-gas transaction at 5 Gwei and one high-gas transaction at 20 Gwei yields a gas-weighted mean of \~19 Gwei and an arithmetic mean of 12.5 Gwei.
* Useful when each transaction should contribute equally to the average, such as when analyzing typical user-facing fee levels independent of transaction size.

### Release History

* Released in ND-8430 (September, 2026)

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasPriceTxMean>" %}

## Block Gas Limit <a href="#gaslmtblk" id="gaslmtblk"></a>

### Definition

The sum gas limit of all blocks that day.

| Name            | MetricID  | Unit | Interval       |
| --------------- | --------- | ---- | -------------- |
| Block Gas Limit | GasLmtBlk | Gas  | 1 block, 1 day |

### Details

* Gas is a dimensionless unit measuring the computational cost of operations for ETH-based assets. Each transaction spends gas when being processed.
* Each block has a limit of how much gas can be expanded when processing its operations. It is the scaling limit for ETH-based assets, just as block size is for BTC-based ones.

### Chart

<figure><img src="https://2398817338-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-MO23j33wWGzm0NrZseN%2Fuploads%2Fgit-blob-ca88fcde05ac46047d2fa4744318273cd5e451bd%2Fimage.png?alt=media" alt=""><figcaption></figcaption></figure>

### Asset-Specific Details

* Only relevant for ETH and ETC.

### Interpretation

* Ethereum blocks are mined roughly every 15 seconds. Each Ethereum block has a maximum size, which limits the amount of data that can be included. The current maximum block size is set at about 15M gas per block on April 22 (seen in green on the chart above). Prior to that, the gas limit was 12.5M per block, which set in July 2020. Since the maximum block size is denominated in gas and different transactions have different gas usages based on complexity, there isn’t a consistent maximum number of transactions that can be included in a block. But on average, about 160-200 transactions are included per block.
* The greater the gas limit, the more space is available per block, which can help push down the average gas price.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasLmtBlk>" %}

## Mean Block Gas Limit <a href="#gaslmtblkmean" id="gaslmtblkmean"></a>

### Definition

The mean gas limit per block that day.

| Name                 | MetricID      | Unit | Interval |
| -------------------- | ------------- | ---- | -------- |
| Mean Block Gas Limit | GasLmtBlkMean | Gas  | 1 day    |

### Details

* Computed as GasLmtBlk / BlkCnt
* Gas is a dimensionless unit measuring the computational cost of operations for ETH-based assets. Each transaction spends gas when being processed.

### Asset-Specific details

* Only relevant for ETH and ETC.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasLmtBlkMean>" %}

## Tx Gas Limit <a href="#gaslmttx" id="gaslmttx"></a>

### Definition

The sum gas limit of all transactions that day.

| Name         | MetricID | Unit | Interval       |
| ------------ | -------- | ---- | -------------- |
| Tx Gas Limit | GasLmtTx | Gas  | 1 block, 1 day |

### Details

* Gas is a dimensionless unit measuring the computational cost of operations for ETH-based assets. Each transaction uses gas when being processed. As it’s impossible to know how much gas every transaction will use before executing it, each transaction specifies a gas limit it’s willing to use.

### Asset-Specific Details

* Only relevant for ETH and ETC.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasLmtTx>" %}

## Mean Block Gas Limit <a href="#gaslmtblkmean" id="gaslmtblkmean"></a>

### Definition

The mean gas limit per block that day.

| Name                 | MetricID      | Unit | Interval |
| -------------------- | ------------- | ---- | -------- |
| Mean Block Gas Limit | GasLmtBlkMean | Gas  | 1 day    |

### Details

* Computed as GasLmtBlk / BlkCnt
* Gas is a dimensionless unit measuring the computational cost of operations for ETH-based assets. Each transaction spends gas when being processed.

### Asset-Specific details

* Only relevant for ETH and ETC.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasLmtBlkMean>" %}

## Mean Gas Limit per Tx <a href="#gaslmttxmean" id="gaslmttxmean"></a>

### Definition

The mean gas limit per transaction that day.

| Name                  | MetricID     | Unit | Interval       |
| --------------------- | ------------ | ---- | -------------- |
| Mean Gas Limit per Tx | GasLmtTxMean | Gas  | 1 block, 1 day |

### Details

* Computed as GasLmtTx / TxCnt
* Gas is a dimensionless unit measuring the computational cost of operations for ETH-based assets. Each transaction uses gas when being processed. As it’s impossible to know how much gas every transaction will use before executing it, each transaction specifies a gas limit it’s willing to use.

### Asset-Specific Details

* Only relevant for ETH and ETC.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasLmtTxMean>" %}

## Tx Gas Used <a href="#gasusedtx" id="gasusedtx"></a>

### Definition

The sum gas used (i.e., paid) across all transactions that day.

| Name        | MetricID  | Unit | Interval       |
| ----------- | --------- | ---- | -------------- |
| Tx Gas Used | GasUsedTx | Gas  | 1 block, 1 day |

### Details

* Gas is a dimensionless unit measuring the computational cost of operations for ETH-based assets. Each transaction uses gas when being processed.

### Asset-Specific details

* Only relevant for ETH and ETC.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasUsedTx>" %}

## Mean Gas Used per Tx <a href="#gaslmttxmean" id="gaslmttxmean"></a>

### Definition

The mean gas used (i.e., paid) per transaction that day.

| Name                 | MetricID      | Unit | Interval       |
| -------------------- | ------------- | ---- | -------------- |
| Mean Gas Used per Tx | GasUsedTxMean | Gas  | 1 block, 1 day |

### Details

* Computed as GasUsedTx / TxCnt
* Gas is a dimensionless unit measuring the computational cost of operations for ETH-based assets. Each transaction uses gas when being processed.

### Asset-Specific Details

* Only relevant for ETH and ETC.

### Release History

* Released in the 1.0 release of NDP

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/GasUsedTxMean>" %}

## Network State Storage Fees

### Definition

Total fees paid for storing state on the network within an interval in native units.

<table><thead><tr><th>Name</th><th width="216">MetricID</th><th>Unit</th><th>Interval</th></tr></thead><tbody><tr><td>Network state storage fees (native units)</td><td>FeeStorTotNtv</td><td>Native units</td><td>1 day</td></tr><tr><td>Network state storage fees (USD)</td><td>FeeStorTotUSD</td><td>USD</td><td>1 day</td></tr></tbody></table>

#### Details

* Solana removed network state storage fees in November of 2023 as of which time they are 0

### Availability for Assets

{% embed url="<https://coverage.coinmetrics.io/asset-metrics/FeeStorTotNtv>" %}

### API Endpoints

Fee metrics can be accessed using these endpoints:

* `timeseries/asset-metrics`

and by passing in the metric ID's `Fee*` and `Gas*` in the `metrics` parameter.

<mark style="color:blue;">`GET`</mark> `undefined/timeseries/asset-metrics`

{% tabs %}
{% tab title="Shell" %}

```shell
curl --compressed "https://api.coinmetrics.io/v4/timeseries/asset-metrics?metrics=FeeByteMeanNtv&assets=btc&pretty=true&api_key=<your_key>"
```

{% endtab %}

{% tab title="Python" %}

```python
import requests
response = requests.get('https://api.coinmetrics.io/v4/timeseries/asset-metrics?metrics=FeeByteMeanNtv&assets=btc&pretty=true&api_key=<your_key>').json()
print(response)
```

{% endtab %}

{% tab title="Python Client" %}

```python
from coinmetrics.api_client import CoinMetricsClient

api_key = "<API_KEY>"
client = CoinMetricsClient(api_key)

print(
    client.get_asset_metrics(
        metrics="FeeByteMeanNtv", 
        assets="btc",
    ).to_dataframe()
)
```

{% endtab %}
{% endtabs %}


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://gitbook-docs.coinmetrics.io/network-data/network-data-overview/fees-and-revenue/fees.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
