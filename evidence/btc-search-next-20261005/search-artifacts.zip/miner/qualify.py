"""One-shot schema/coverage qualification, without economic or account screening."""
from collections import Counter
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parent
spec = json.loads((ROOT / 'input-spec.json').read_text())
raw = (ROOT / 'asset-metrics.json').read_bytes()
source = json.loads(raw)
rows = source['data']
start = date.fromisoformat(spec['start_inclusive'][:10])
end = date.fromisoformat(spec['end_exclusive'][:10])
expected = {start + timedelta(days=i) for i in range((end - start).days)}
unique = {}
exact_duplicates = []
inconsistent_duplicates = []
outside = []
invalid = []
for index, row in enumerate(rows):
    try:
        if row['asset'] != 'btc':
            raise ValueError('wrong asset')
        timestamp = datetime.fromisoformat(row['time'].replace('Z', '+00:00'))
        if (timestamp.utcoffset() != timedelta(0) or
                (timestamp.hour, timestamp.minute, timestamp.second, timestamp.microsecond) != (0, 0, 0, 0)):
            raise ValueError('not UTC midnight')
        day = timestamp.date()
        fee, issuance = Decimal(row['FeeTotNtv']), Decimal(row['IssTotNtv'])
        if not fee.is_finite() or not issuance.is_finite() or fee < 0 or issuance <= 0 or fee + issuance <= 0:
            raise ValueError('nonfinite or nonpositive issuance/denominator')
        if day not in expected:
            outside.append({'index': index, 'time': row['time'], 'reason': 'outside fixed start-inclusive/end-exclusive window'})
            continue
        value = (str(fee), str(issuance))
        if day in unique:
            target = exact_duplicates if unique[day] == value else inconsistent_duplicates
            target.append({'index': index, 'time': row['time']})
        else:
            unique[day] = value
    except (KeyError, ValueError, InvalidOperation) as exc:
        invalid.append({'index': index, 'reason': str(exc)})
missing = sorted(expected - set(unique))
year_expected = Counter(day.year for day in expected)
year_observed = Counter(day.year for day in unique)
coverage = {str(year): {'expected': n, 'observed': year_observed[year], 'fraction': year_observed[year] / n}
            for year, n in sorted(year_expected.items())}
overall_coverage = len(unique) / len(expected)
coverage_pass = (overall_coverage >= spec['input_gate']['overall_coverage_min'] and
                 all(x['fraction'] >= spec['input_gate']['each_calendar_year_coverage_min'] for x in coverage.values()))
reference = json.loads((ROOT / 'reference-asset-metrics.json').read_text())
definitions = {x['metric']: x for x in reference['data']}
receipts = json.loads((ROOT / 'receipts.json').read_text())
result = {
    'format': 'btc-miner-income-input-qualification-result-v1',
    'status': 'SEMANTICS_PENDING_NO_ECONOMIC_SCREEN',
    'registered_spec_sha256': hashlib.sha256((ROOT / 'input-spec.json').read_bytes()).hexdigest(),
    'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'source_sha256': hashlib.sha256(raw).hexdigest(),
    'source_url': next(x['url'] for x in receipts if x['kind'] == 'timeseries'),
    'raw_rows': len(rows), 'fixed_window_rows': len(unique), 'expected_days': len(expected),
    'overall_coverage': overall_coverage, 'calendar_year_coverage': coverage,
    'excluded_outside_fixed_window': outside,
    'missing_days': [str(x) for x in missing], 'invalid_rows': invalid,
    'exact_duplicate_rows': exact_duplicates, 'inconsistent_duplicate_rows': inconsistent_duplicates,
    'pagination_metadata': {k: source.get(k) for k in ('next_page_token', 'next_page_url')},
    'coverage_gate_pass': coverage_pass,
    'schema_and_positive_denominator_gate_pass': not invalid and not inconsistent_duplicates,
    'no_fill_applied': True,
    'official_metric_reference': definitions,
    'semantics': {
        'native_unit_reference': 'Both official metric definitions use Native units and asset btc.',
        'fees_exclude_new_issuance': definitions['FeeTotNtv']['description'],
        'issuance_definition': definitions['IssTotNtv']['description'],
        'BTC_subsidy_fee_burn_breakdown_explicitly_bound': False,
        'UTC_daily_bucket_start_vs_end_explicitly_bound': False,
        'reason_pending': 'Captured official reference gives native fee/new-unit definitions, but captured overview does not explicitly bind BTC subsidy/fee/burn accounting or whether midnight labels begin or end the daily bucket. No assumed release time is imposed.',
    },
    'economic_expression_proposal_only': {
        'income_fee_share': 'FeeTotNtv / (FeeTotNtv + IssTotNtv)',
        'interpretation': 'Canonical fee/new-unit composition proxy; does not establish miner exchange sales or miner willingness to sell.',
        'screened': False,
    },
    'historical_use': 'Development only: fetched canonical chain statistics on receipt date; not point-in-time historical receipts or new OOS.',
    'GET_count': len(receipts), 'raw_body_bytes': sum(x['bytes'] for x in receipts),
    'preserved_failures': [x for x in receipts if x.get('status_code', 0) != 200 or x.get('error')],
    'account_runs': 0, 'historical_795_replays': 0, 'software_tests': 0, 'private_requests': 0,
}
(ROOT / 'qualification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'raw_rows', 'fixed_window_rows', 'expected_days', 'overall_coverage', 'coverage_gate_pass', 'schema_and_positive_denominator_gate_pass', 'GET_count', 'raw_body_bytes')}, ensure_ascii=False))
