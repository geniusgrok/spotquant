> For the complete documentation index, see [llms.txt](https://gitbook-docs.coinmetrics.io/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://gitbook-docs.coinmetrics.io/network-data/network-data-overview.md).

# Network Data Pro Overview

Network Data Pro (NDP) provides insightful, aggregate network data metrics for a wide-variety of cryptoasset networks. We run blockchain nodes to collect and harmonize information from dozens of blockchains.

Our Network Data Pro metrics are aggregated at the asset level.

## Network Data Asset Coverage

Coin Metrics calculates Network Data Pro metrics for over 200 assets. A high-level view of our asset coverage can be found in the [CM Coverage Tool](https://coverage.coinmetrics.io/asset-metrics-v2/PriceUSD).

{% embed url="<https://coverage.coinmetrics.io/asset-metrics-v2/PriceUSD>" %}

\
The specific asset availability for each metric can be found by:

* querying our [`/catalog-v2/asset-metrics`](https://api.coinmetrics.io/v4/catalog-v2/asset-metrics) API endpoint **or**
* selecting a metric from our [Asset Metrics Coverage Page ](https://coverage.coinmetrics.io/asset-metrics-v2?)(Products = Network Data)

Similarly you can also view the metrics available for a particular asset by viewing our [Asset Coverage Page](https://coverage.coinmetrics.io/assets-v2) (select the asset of interest).

## Data Available at Asset Level

Network Data Pro metrics are available at the asset level through the [`/timeseries/asset-metrics`](https://docs.coinmetrics.io/api/v4#operation/getTimeseriesAssetMetrics) API endpoint.

Details on the specific metrics are described in the pages linked in this section.

## Change Log

{% updates format="full" %}
{% update date="2026-09-23" %}

## Added Effective Execution Gas Price Metrics

Added two new gas price metrics covering EVM networks - **`GasPriceMean`**, the gas-weighted mean effective execution gas price over the interval, and **`GasPriceTxMean`**, the arithmetic per-transaction mean. Both use execution fees only, excluding blob fees and OP Stack L1 data and operator fees. Available at 1d frequency for ETH, ETC, BNB\_BSC, ETH\_BASE, ETH\_OP, and FLOW\_EVM, and additionally at 1h frequency for ETH. For full coverage details refer to the coverage pages for [GasPriceMean](https://coverage.coinmetrics.io/asset-metrics-v2/GasPriceMean) and [GasPriceTxMean](https://coverage.coinmetrics.io/asset-metrics-v2/GasPriceTxMean).
{% endupdate %}

{% update date="2026-09-21" %}

## Extended Economically Active Addresses to Solana Tokens

Extended the `AdrActUSD1Cnt` metric to 46 SPL tokens on Solana, capturing addresses that transacted at least 1 USD in a single transfer. This metric was previously available for Bitcoin, Ethereum, and Solana. For full details refer to the [documentation](https://docs.coinmetrics.io/network-data/network-data-overview/addresses/active-addresses#economically-active-addresses). For full coverage details refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/AdrActUSD1Cnt).

<details>

<summary>Assets Added</summary>

* AAPLX\_SOL - Apple xStock on Solana
* AMZNX\_SOL - Amazon xStock on Solana
* BNSOL\_SOL - Binance Staked Solana SOL
* BODEN\_SOL - Jeo Boden SOL
* BOME\_SOL - Book Of Meme SOL
* BONK\_SOL - Bonk SOL
* CBBTC\_SOL - Coinbase Wrapped BTC SOL
* COINX\_SOL - Coinbase xStock on Solana
* CRCLX\_SOL - Circle xStock on Solana
* EURC\_SOL - Euro Coin SOL
* GOOGLX\_SOL - Alphabet xStock on Solana
* HNT\_SOL - Helium SOL
* HOODX\_SOL - Robinhood xStock on Solana
* JITOSOL\_SOL - Jito Staked Solana SOL
* JTO\_SOL - Jito SOL
* JUP\_SOL - Jupiter SOL
* MAX\_MASTERCARDXSTOCK\_SOL - Mastercard xStock on Solana
* ME\_SOL - Magic Eden SOL
* MELANIA\_SOL - Melania Meme SOL
* MNDE\_SOL - Marinade SOL
* MPLX\_SOL - Metaplex SOL
* MSOL\_SOL - Marinade Staked Solana SOL
* MSTRX\_SOL - Microstrategy xStock on Solana
* NVDAX\_SOL - NVIDIA xStock on Solana
* ORCA\_SOL - Orca SOL
* PYTH\_SOL - Pyth SOL
* PYUSD\_SOL - PayPal USD SOL
* QQQX\_SOL - Nasdaq xStock on Solana
* RAY\_SOL - Raydium SOL
* RENDER\_SOL - Render SOL
* SAMO\_SOL - Samoyedcoin SOL
* SBR\_SOL - Saber SOL
* SLERF\_SOL - Slerf SOL
* SPYX\_SOL - SP500 xStock on Solana
* TREMP\_SOL - Doland Tremp SOL
* TRUMP\_SOL - Official Trump SOL
* TSLAX\_SOL - Tesla xStock on Solana
* USDC\_SOL - USDCoin SOL
* USDE.E\_SOL - Ethena USDe SOL Bridged from Ethereum
* USDS.E\_SOL - USDS SOL Bridged from Ethereum
* USDT\_SOL - Tether SOL
* USDY\_SOL - Ondo US Dollar Yield SOL
* W\_SOL - Wormhole SOL
* WEN\_SOL - Wen SOL
* WIF\_SOL - Dogwifhat SOL
* WSOL\_SOL - Wrapped Solana SOL

</details>
{% endupdate %}

{% update date="2026-09-09" %}

## Added 103 new xStocks on Solana

Added Network Data metrics for 103 new xStock tokenized equities and ETFs on Solana. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>xStock tokens on Solana added</summary>

* ABTX\_SOL - Abbott xStock on Solana
* ADBEX\_SOL - Adobe xStock on Solana
* AMATX\_SOL - Applied Materials, Inc. xStock on Solana
* AMDX\_SOL - AMD xStock on Solana
* APLDX\_SOL - Applied Digital Corporation xStock on Solana
* APPX\_SOL - AppLovin xStock on Solana
* ASTSX\_SOL - AST SpaceMobile xStock on Solana
* AZNX\_SOL - AstraZeneca xStock on Solana
* BITXX\_SOL - Volatility Shares 2x Bitcoin Strategy xStock on Solana
* BMNRX\_SOL - Bitmine xStock on Solana
* BRK.BX\_SOL - Berkshire Hathaway xStock on Solana
* BSPX\_SOL - Bending Spoons xStock on Solana
* BTBTX\_SOL - Bit Digital xStock on Solana
* CEGX\_SOL - Constellation Energy Corporation xStock on Solana
* CLSKX\_SOL - CleanSpark xStock on Solana
* CMCSAX\_SOL - Comcast xStock on Solana
* CRMX\_SOL - Salesforce xStock on Solana
* CVXX\_SOL - Chevron xStock on Solana
* DAXX\_SOL - Global X DAX Germany xStock on Solana
* DELLX\_SOL - Dell Technologies Inc. xStock on Solana
* DFDVX\_SOL - DFDV xStock on Solana
* ETNX\_SOL - Eaton Corporation plc xStock on Solana
* EWQX\_SOL - iShares MSCI France xStock on Solana
* EWUX\_SOL - iShares MSCI United Kingdom xStock on Solana
* EWYX\_SOL - iShares MSCI South Korea xStock on Solana
* FAAAX\_SOL - Fidelity AAA CLO xStock on Solana
* FEZX\_SOL - SPDR EURO STOXX 50 xStock on Solana
* FLBLX\_SOL - Franklin Senior Loan xStock on Solana
* FLQMX\_SOL - Franklin U.S. Mid Cap Multi-Factor xStock on Solana
* FWONKX\_SOL - Liberty Media xStock on Solana
* GDXX\_SOL - VanEck Gold Miners xStock on Solana
* GEVX\_SOL - GE Vernova Inc. xStock on Solana
* HDX\_SOL - Home Depot xStock on Solana
* HIMSX\_SOL - Hims & Hers xStock on Solana
* HONX\_SOL - Honeywell xStock on Solana
* IEMGX\_SOL - Core MSCI Emerging Markets xStock on Solana
* IJRX\_SOL - S\&P Small Cap xStock on Solana
* IQMX\_SOL - Franklin Intelligent Machines xStock on Solana
* ITAX\_SOL - iShares U.S. Aerospace & Defense ETF xStock on Solana
* IWMX\_SOL - Russell 2000 xStock on Solana
* JAAAX\_SOL - Janus Henderson AAA CLO xStock on Solana
* KLACX\_SOL - KLA Corporation xStock on Solana
* KRAQX\_SOL - KRAQ xStock on Solana
* LINX\_SOL - Linde xStock on Solana
* LITEX\_SOL - Lumentum Holdings Inc. xStock on Solana
* LNGX\_SOL - Cheniere Energy xStock on Solana
* MARAX\_SOL - MARA xStock on Solana
* MCOX\_SOL - Moody's xStock on Solana
* MDLNX\_SOL - Medline xStock on Solana
* MLMX\_SOL - Martin Marietta Materials xStock on Solana
* MRKX\_SOL - Merck xStock on Solana
* MRVLX\_SOL - Marvell xStock on Solana
* MUX\_SOL - Micron Technology xStock on Solana
* NETX\_SOL - Cloudflare xStock on Solana
* NLRX\_SOL - VanEck Uranium and Nuclear xStock on Solana
* ONDSX\_SOL - Ondas xStock on Solana
* OPENX\_SOL - OPEN xStock on Solana
* ORCLX\_SOL - Oracle xStock on Solana
* PALLX\_SOL - abrdn Physical Palladium Shares xStock on Solana
* PANWX\_SOL - Palo Alto Networks xStock on Solana
* PGX\_SOL - Procter & Gamble xStock on Solana
* PLTRX\_SOL - Palantir xStock on Solana
* PLX\_PLANETLABSXSTOCK\_SOL - Planet Labs xStock on Solana
* PMX\_SOL - Philip Morris xStock on Solana
* PNWX\_SOL - Pinnacle West Capital xStock on Solana
* PPLTX\_SOL - abrdn Physical Platinum Shares xStock on Solana
* PWRX\_SOL - Quanta Services, Inc. xStock on Solana
* PYPLX\_SOL - PayPal xStock on Solana
* RBLXX\_SOL - Roblox xStock on Solana
* RMDX\_SOL - ResMed xStock on Solana
* SBETX\_SOL - SharpLink Gaming xStock on Solana
* SCHFX\_SOL - Schwab International Equity xStock on Solana
* SGOVX\_SOL - iShares 0-3 Month Treasury Bond ETF xStock on Solana
* SLVX\_SOL - iShares Silver Trust xStock on Solana
* SMCIX\_SOL - Super Micro Computer, Inc. xStock on Solana
* SMHX\_SOL - VanEck Semiconductor ETF xStock on Solana
* SMRX\_SOL - NuScale Power Corporation xStock on Solana
* SNDKX\_SOL - Sandisk Corporation xStock on Solana
* SOXLX\_SOL - Direxion Semiconductor Bull 3X xStock on Solana
* SOXXX\_SOL - iShares Semiconductor xStock on Solana
* SPCEX\_SOL - Virgin Galactic xStock on Solana
* SPCXX\_SOL - SpaceX xStock on Solana
* SPGX\_SOL - Simon Property xStock on Solana
* TBLLX\_SOL - TBLL xStock on Solana
* TERX\_SOL - Teradyne, Inc. xStock on Solana
* TMOX\_SOL - Thermo Fisher xStock on Solana
* TMUSX\_SOL - T-Mobile xStock on Solana
* TSMX\_SOL - TSMC xStock on Solana
* UNHX\_SOL - UnitedHealth xStock on Solana
* URAX\_SOL - Global X Uranium ETF xStock on Solana
* USPXX\_SOL - Franklin U.S. Equity Index xStock on Solana
* VCXX\_SOL - Fundrise Innovation Fund, LLC xStock on Solana
* VIDAX\_SOL - Vida Global xStock on Solana
* VOOX\_SOL - Vanguard S\&P 500 xStock on Solana
* VRTX\_VERTIVHOLDINGSCOXSTOCK\_SOL - Vertiv Holdings Co xStock on Solana
* VTIX\_SOL - Vanguard xStock on Solana
* VUGX\_SOL - Vanguard Growth ETF xStock on Solana
* VXUSX\_SOL - Vanguard Total International Stock ETF xStock on Solana
* WBDX\_SOL - Warner Bros. Discovery xStock on Solana
* WENX\_SOL - Wendy's xStock on Solana
* WULFX\_SOL - TeraWulf xStock on Solana
* XLEX\_SOL - Energy Select Sector SPDR Fund xStock on Solana
* XOPX\_SOL - SPDR S\&P Oil & Gas Exploration & Production ETF xStock on Solana

</details>
{% endupdate %}

{% update date="2026-09-09" %}

## Enabled IssContNtv for Ethereum

`IssContNtv` (continuous issuance, native units) is now available for Ethereum at the 1-hour and 1-day frequencies. For details refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/IssContNtv).
{% endupdate %}

{% update date="2026-09-08" %}

## Added New Taxonomy Assets

Added Network Data coverage for 6 new taxonomy assets. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>Assets Added</summary>

* CAP - Cap
* DATA\_DATANETWORK - Data Network
* KAT\_KATANA - Katana
* U\_UNITEDSTABLES - United Stables
* VERONA - Verona
* WARD - Warden

</details>
{% endupdate %}

{% update date="2026-08-27" %}

## Added Tokenized RWA Assets on Arbitrum, Base, and Avalanche

Expanded coverage of existing tokenized real-world-asset products to new networks. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>Assets Added</summary>

* BENJI\_ARB.ETH - Franklin OnChain U.S. Government Money Fund On Arbitrum
* BENJI\_BASE.ETH - Franklin OnChain U.S. Government Money Fund On Base
* BUIDL\_AVAXC - BlackRock USD Institutional Digital Liquidity Fund AVAXC
* FIDD\_ETH - Fidelity Digital Dollar On Ethereum
* VBILL\_AVAXC - VanEck Treasury Fund On AVAXC

</details>
{% endupdate %}

{% update date="2026-08-26" %}

## Added Network Data Metrics for New Solana Stablecoins

Added Network Data metrics for 6 new Solana stablecoins. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>Assets Added</summary>

* CASH\_SOL - CASH on Solana
* JUPUSD\_SOL - Jupiter USD on Solana
* USD1\_SOL - USD1 on Solana
* USDG\_SOL - Global Dollar on Solana
* USDG0\_SOL - USDG0 on Solana
* USX\_SOL - USX on Solana

</details>
{% endupdate %}

{% update date="2026-08-21" %}

## Added Protocol Metrics to Network Data Pro

Protocol Metrics, covering Aave V3 and Morpho Vaults on Ethereum, are now included in the standard Network Data Pro EOD and real-time packages. Metrics cover supply and borrow rates (APY/APR) across tracked lending markets. For details, refer to the [Rates and Yield](/network-data/protocol-metrics/rates-and-yield.md) page.
{% endupdate %}

{% update date="2026-08-20" %}

## Added Point-in-Time Exchange and ETF Flow Metrics for Bitcoin

Released point-in-time (`Pit`) variants of existing exchange and ETF flow metrics for Bitcoin, attributing deposit, withdrawal, net-flow, and supply activity using only the addresses known to belong to an entity at the time, avoiding look-ahead bias from later address discoveries. For details on the exchange flow methodology please refer to the [Point-in-Time Flows](/network-data/network-data-overview/exchange/point-in-time-flows.md) page.
{% endupdate %}

{% update date="2026-08-18" %}

## Expanded CapMrktEstUSD to New Assets

Added estimated market cap to the following new assets:

<details>

<summary>Estimated Market Cap added to the following assets:</summary>

1. ai\_gensyn
2. bnkr
3. chip
4. data
5. edge\_edgex
6. elsa
7. fun\_sportfun
8. genius
9. gwei
10. inx\_infinex
11. irys
12. lit\_lighter
13. nes
14. o
15. opn
16. pros\_pharos
17. rave
18. skr

</details>
{% endupdate %}

{% update date="2026-08-03" %}

## Added Network Data Metrics for New Solana Tokens

Added Network Data metrics for 11 new Solana tokens. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>Assets Added</summary>

* ARX\_SOL - Arcium SPL Token on Solana
* BP\_BACKPACK\_SOL - Backpack on Solana
* ECOR\_ECORPAY\_SOL - Ecorpay Token on Solana
* HOME\_SOL - Home on Solana
* HUMA\_SOL - Huma Finance on Solana
* LAYER\_SOLAYER\_SOL - Solayer on Solana
* MET\_METEORA\_SOL - Meteora on Solana
* PST\_PAYFI\_SOL - PayFi Strategy Token on Solana
* PUMP\_SOL - Pump on Solana
* WET\_HUMIDIFI\_SOL - HumidiFi on Solana
* WLFI\_SOL - World Liberty Financial on Solana

</details>
{% endupdate %}

{% update date="2026-08-03" %}

## Expanded CapMrktEstUSD to New Assets

Added estimated market cap to the following new assets:

<details>

<summary>Estimated Market Cap added to the following assets:</summary>

1. aztec
2. based
3. bill
4. birb
5. blend
6. bob\_buildonbitcoin
7. brev
8. ctr
9. esp
10. fight
11. fogo
12. imu
13. ir
14. mega
15. mezo
16. opg
17. rls
18. rnbw
19. robo
20. scor
21. thq
22. tria
23. u
24. us
25. usat
26. vooi
27. zama

</details>
{% endupdate %}

{% update date="2026-07-30" %}

## Added Pairwise Flow Metrics for USDC

Released directional pairwise flow metrics capturing value moving between tagged entities (e.g. Coinbase, Binance, Bitfinex, Kraken, OKX, KuCoin), including value that passes through untagged intermediary wallets before reaching its destination. Available at the 1d and 1h frequency for USDC on Ethereum. For details on the supported metrics please refer to the [Pairwise Flows](/network-data/network-data-overview/exchange/pairwise-flows.md) page. For details on asset coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowFromCBSToBNBNtv).
{% endupdate %}

{% update date="2026-07-06" %}

## Expanded Estimated Market Cap Dominance to ETH

Added the `CapMrktEstDomPct` metric for Ethereum, previously only available for Bitcoin. For full coverage details please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/CapMrktEstDomPct).
{% endupdate %}

{% update date="2026-06-22" %}

## Expanded Exchange Flows to New Stablecoins

Released exchange flow metrics at the 1d and 1h frequency for four stablecoin assets on Ethereum. For details on the supported metrics please refer to the [Exchange](/network-data/network-data-overview/exchange.md) page. For details on Exchange Flow metric coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv).

<details>

<summary>Assets Added:</summary>

* DAI - Dai
* USDE\_ETH - Ethena USDe ETH
* USDG\_ETH - Global Dollar on Ethereum
* USDS\_ETH - USDS on Ethereum

</details>
{% endupdate %}

{% update date="2026-06-09" %}

## Added Age-Band Realized Capitalization Metrics for Bitcoin

Added 13 new metrics that decompose Bitcoin's realized capitalization by UTXO age. Each band captures the realized cap attributable to UTXOs within that age range, and the sum of all bands equals `CapRealUSD`. For full details on the methodology please refer to the [metric documentation page](/network-data/network-data-overview/market/market-capitalization.md#cap-real-age-bands). For full coverage details refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/CapRealUSD1d).

<details>

<summary>Metrics Added:</summary>

* `CapRealUSD1d` - UTXOs aged 0-1 days
* `CapRealUSD1w` - UTXOs aged 1-7 days
* `CapRealUSD1m` - UTXOs aged 7-30 days
* `CapRealUSD3m` - UTXOs aged 30-90 days
* `CapRealUSD6m` - UTXOs aged 90-180 days
* `CapRealUSD1y` - UTXOs aged 180-365 days
* `CapRealUSD2y` - UTXOs aged 1-2 years
* `CapRealUSD3y` - UTXOs aged 2-3 years
* `CapRealUSD4y` - UTXOs aged 3-4 years
* `CapRealUSD5y` - UTXOs aged 4-5 years
* `CapRealUSD7y` - UTXOs aged 5-7 years
* `CapRealUSD10y` - UTXOs aged 7-10 years
* `CapRealUSD10yPlus` - UTXOs aged 10+ years

</details>
{% endupdate %}

{% update date="2026-05-26" %}

## Expanded CapMrktEstUSD to New Assets

Added estimated market cap to the following new assets:

<details>

<summary>Estimated Market Cap added to the following assets:</summary>

1. anime
2. aurora
3. b2
4. cpool
5. ctx
6. cyber
7. enso
8. holo
9. honey
10. huma
11. meme
12. mira
13. mplx
14. neon
15. newt
16. order
17. paal
18. plume
19. prompt
20. sats
21. sundog
22. xai

</details>
{% endupdate %}

{% update date="2026-05-01" %}

## Added Network Data Metrics for Stellar Tokens

Added Network Data metrics at the 1d frequency for 10 Stellar-based tokens, including stablecoins and tokenized real-world assets. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

Additionally, added support for aggregated tickers benji & wtgxx. benji aggregates benji\_eth + benji\_xlm. wtgxx aggregates wtgxx\_eth & wtgxx\_xlm.

<details>

<summary>Assets Added:</summary>

* BENJI\_XLM - Franklin OnChain U.S. Government Money Fund On Stellar
* CETES\_XLM - CETES Etherfuse on Stellar
* CRDYX\_XLM - WisdomTree Private Credit and Alternative Income Digital Fund on Stellar
* EURC\_XLM - EURO Coin on Stellar
* PYUSD\_XLM - Paypal USD on Stellar
* SPXUX\_XLM - WisdomTree 500 Digital Fund on Stellar
* TESOURO\_XLM - TESOURO Etherfuse on Stellar
* USDC\_XLM - USDC on Stellar
* USTRY\_XLM - USTRY Etherfuse on Stellar
* WTGXX\_XLM - WisdomTree Treasury Money Market Digital Fund on Stellar

</details>
{% endupdate %}

{% update date="2026-05-01" %}

## Expanded Exchange Flows to 1h for USDC on Base and USD1

Expanded exchange flow metrics for **usdc\_base.eth** and **usd1\_eth** to the 1h frequency. For details on Exchange Flow metric coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv).
{% endupdate %}

{% update date="2026-04-23" %}

## Expanded Exchange Flows to new Stablecoins

Released exchange flows for **usdc\_base.eth** and **usd1\_eth** at the 1d frequency. For details on the supported metrics please refer to the [Exchange](/network-data/network-data-overview/exchange.md)page. For details on Exchange Flow metric coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv).
{% endupdate %}

{% update date="2026-04-22" %}

## Added Tokenized RWA Assets on Ethereum to ND Metrics

Added Network Data metrics for tokenized Real World Asset (RWA) tokens on Ethereum, including tokenized US Treasury funds and money market funds. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>RWA tokens added:</summary>

1. BENJI\_ETH - Franklin OnChain U.S. Government Money Fund on Ethereum
2. FDIT\_ETH - Fidelity Digital Interest Token on Ethereum
3. JAAA\_ETH - Janus Henderson Anemoy AAA CLO Fund Token on Ethereum
4. JTRSY\_ETH - Janus Henderson Anemoy Treasury Fund on Ethereum
5. OUSG\_ETH - Ondo Short-Term U.S. Government Bond Fund on Ethereum
6. TBILL\_ETH - OpenEden T-Bills on Ethereum
7. USDY\_ETH - Ondo U.S. Dollar Yield on Ethereum
8. USTB\_ETH - Superstate Short Duration U.S. Government Securities Fund on Ethereum
9. VBILL\_ETH - VanEck Treasury Fund on Ethereum

</details>
{% endupdate %}

{% update date="2026-04-16" %}

## Added BUIDL\_SOL to Network Data Metrics

Added metrics support for BlackRock's BUIDL tokenized money market fund on Solana (`buidl_sol`). For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2/buidl_sol).
{% endupdate %}

{% update date="2026-04-07" %}

## Added Network Data Metrics for BNB Smart Chain (Experimental)

Added Network Data metrics for the BNB Smart Chain (`bnb_bsc`) at the 1d frequency for a set of MVP metrics. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2/bnb_bsc).
{% endupdate %}

{% update date="2026-04-02" %}

## Added Huobi Exchange Flows for ETH

Released exchange flow metrics for ETH on the Huobi (HTX) exchange. For details on the supported metrics please refer to the [Exchange](/network-data/network-data-overview/exchange.md) page. For details on Exchange Flow metric coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv).
{% endupdate %}

{% update date="2026-04-02" %}

## Expand CapMrktEstUSD to New Assets

Added estimated market cap to the following new assets:

<details>

<summary>Estimated Market Cap added to the following assets:</summary>

1. apr
2. dmc
3. obol
4. pro
5. ssv
6. tut
7. zerebro

</details>
{% endupdate %}

{% update date="2026-04-01" %}

## Added xStocks on Ethereum to ND Metrics

Added Network Data metrics for xStock tokenized equities on Ethereum for 79 new assets. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>xStock tokens on Ethereum added:</summary>

1. AAPLX\_ETH - Apple xStock on Ethereum
2. ABBVX\_ETH - AbbVie xStock on Ethereum
3. ABTX\_ETH - Abbott xStock on Ethereum
4. ACNX\_ETH - Accenture xStock on Ethereum
5. AMBRX\_ETH - Ambarella xStock on Ethereum
6. AMDX\_ETH - AMD xStock on Ethereum
7. AMZNX\_ETH - Amazon xStock on Ethereum
8. APPX\_ETH - Appian xStock on Ethereum
9. AVGOX\_ETH - Avago xStock on Ethereum
10. AZNX\_ETH - AstraZeneca xStock on Ethereum
11. BACX\_ETH - Bank of America xStock on Ethereum
12. BMNRX\_ETH - Bowman xStock on Ethereum
13. BRK.BX\_ETH - Berkshire Hathaway xStock on Ethereum
14. BTBTX\_ETH - Bit Digital xStock on Ethereum
15. BTGOX\_ETH - Bitgold xStock on Ethereum
16. CMCSAX\_ETH - Comcast xStock on Ethereum
17. COINX\_ETH - Coinbase xStock on Ethereum
18. COPXX\_ETH - ConocoPhillips xStock on Ethereum
19. CRCLX\_ETH - Circle xStock on Ethereum
20. CRMX\_ETH - Salesforce xStock on Ethereum
21. CRWDX\_ETH - CrowdStrike xStock on Ethereum
22. CSCOX\_ETH - Cisco xStock on Ethereum
23. CVXX\_ETH - CVS xStock on Ethereum
24. DFDVX\_ETH - DeFi Dev xStock on Ethereum
25. DHRX\_ETH - Danaher xStock on Ethereum
26. GLDX\_ETH - Gold ETF xStock on Ethereum
27. GMEX\_ETH - GM xStock on Ethereum
28. GOOGLX\_ETH - Alphabet xStock on Ethereum
29. GSX\_ETH - Goldman Sachs xStock on Ethereum
30. HDX\_ETH - Home Depot xStock on Ethereum
31. HONX\_ETH - Honeywell xStock on Ethereum
32. HOODX\_ETH - Robinhood xStock on Ethereum
33. IBMX\_ETH - IBM xStock on Ethereum
34. IEMGX\_ETH - iShares Emerging Markets ETF xStock on Ethereum
35. IJRX\_ETH - iShares Small Cap ETF xStock on Ethereum
36. INTCX\_ETH - Intel xStock on Ethereum
37. IWMX\_ETH - iShares Russell 2000 ETF xStock on Ethereum
38. JNJX\_ETH - Johnson & Johnson xStock on Ethereum
39. JPMX\_ETH - JPMorgan xStock on Ethereum
40. KOX\_ETH - Coca-Cola xStock on Ethereum
41. KRAQX\_ETH - Kraken xStock on Ethereum
42. LINX\_ETH - Linkedin xStock on Ethereum
43. LLYX\_ETH - Lilly xStock on Ethereum
44. MAX\_MASTERCARDXSTOCK\_ETH - Mastercard xStock on Ethereum
45. MCDX\_ETH - McDonald's xStock on Ethereum
46. MDTX\_ETH - Medtronic xStock on Ethereum
47. MRKX\_ETH - Merck xStock on Ethereum
48. MRVLX\_ETH - Marvell xStock on Ethereum
49. MSFTX\_ETH - Microsoft xStock on Ethereum
50. MSTRX\_ETH - MicroStrategy xStock on Ethereum
51. NFLXX\_ETH - Netflix xStock on Ethereum
52. NVDAX\_ETH - NVIDIA xStock on Ethereum
53. NVOX\_ETH - Novo Nordisk xStock on Ethereum
54. OPENX\_ETH - OpenAI xStock on Ethereum
55. ORCLX\_ETH - Oracle xStock on Ethereum
56. PALLX\_ETH - Palladium ETF xStock on Ethereum
57. PEPX\_ETH - PepsiCo xStock on Ethereum
58. PFEX\_ETH - Pfizer xStock on Ethereum
59. PGX\_ETH - Procter & Gamble xStock on Ethereum
60. PLTRX\_ETH - Palantir xStock on Ethereum
61. PMX\_ETH - Philip Morris xStock on Ethereum
62. PPLTX\_ETH - PPL xStock on Ethereum
63. QQQX\_ETH - Nasdaq 100 ETF xStock on Ethereum
64. SCHFX\_ETH - Schwab International ETF xStock on Ethereum
65. SLVX\_ETH - Silver ETF xStock on Ethereum
66. SPYX\_ETH - S\&P 500 ETF xStock on Ethereum
67. STRCX\_ETH - Strategy xStock on Ethereum
68. TBLLX\_ETH - T-Bill xStock on Ethereum
69. TMOX\_ETH - Thermo Fisher xStock on Ethereum
70. TONXX\_ETH - TON xStock on Ethereum
71. TQQQX\_ETH - 3x Nasdaq ETF xStock on Ethereum
72. TSLAX\_ETH - Tesla xStock on Ethereum
73. UNHX\_ETH - UnitedHealth xStock on Ethereum
74. VTIX\_ETH - Viti xStock on Ethereum
75. VTX\_ETH - Vertex xStock on Ethereum
76. VX\_ETH - Vega xStock on Ethereum
77. WMTX\_WALMARTXSTOCK\_ETH - Walmart xStock on Ethereum
78. WTGXX\_ETH - WisdomTree Government Money Market Digital Fund on Ethereum
79. XOMX\_ETH - ExxonMobil xStock on Ethereum

</details>
{% endupdate %}

{% update date="2026-03-31" %}

## Expanded CapMrktEstUSD to 150+ New Assets

Added estimated market cap to over 150 new assets.

<details>

<summary>Estimated Market Cap added to the following assets:</summary>

a2z\
a8\
ace\_fusionist\
acs\
act\
acx\
aero\
aevo\
aixbt\
allo\
arty\
awe\
b3\
ban\
bananas31\
babydoge\
beamx\
bigtime\
blast\
bluai\
blue\
bmt\
camp\
carv\
cat\
cati\
cetus\
cgpt\
chillguy\
clanker\
cloud\
cookie\
coq\
cow\
cspr\
cta\
cxt\
degen\
dogs\
dolo\
dood\
duck\
dym\
ela\
elizaos\
ept\
era\
es\
f\
fhe\
fitfi\
flock\
fort\
g\
giga\
goat\
gps\
griffain\
gtai\
gun\
haedal\
high\
hippo\
hmstr\
home\
house\
hpos10i\
htx\
hyper\
init\
io\
j\
kas\
kernel\
lat\
linea\
lista\
lmwr\
lrds\
manta\
mavia\
melania\
memefi\
mew\
michi\
mmt\
mubarak\
naka\
navx\
neirocto\
nil\
nom\_nomina\
ntrn\
obt\
one\_harmony\
open\_openledger\
parti\
planck\
polyx\
ponke\
prcl\
puffer\
rdnt\
resolv\
rez\
rss3\
saga\
sapien\
saros\
sca\
sfund\
shell\
sign\
solv\
somi\
sonic\
soph\
spa\
sqd\
sto\
swarms\
sweat\
swell\
sxt\
syn\
synd\
taiko\
time\
token\
towns\
trump\
trust\
turbo\
usual\
uxlink\
vanry\
velo\_velodromefinance\
vic\
vine\
vinu\
vvv\
wct\
well\
win\_wink\
wmtx\
xan\
xch\
xion\
xter\
yb\
zbt\
zeus\
zig\
zkc\
zora\
zrx

</details>
{% endupdate %}

{% update date="2026-03-16" %}

## Added XRP Token Metrics

Added Network Data metrics support for tokens on the XRP Ledger. For full asset coverage details refer to the [coverage page](https://coverage.coinmetrics.io/assets-v2).

<details>

<summary>XRP tokens added:</summary>

* EURCV\_XRP - EUR CoinVertible on XRP
* OUSG\_XRP - Ondo Short-Term U.S. Government Bond Fund on XRP
* RLUSD\_XRP - Ripple USD on XRP
* TBILL\_XRP - OpenEden T-Bill on XRP
* USDC\_XRP - USD Coin on XRP
* XSGD\_XRP - XSGD on XRP

</details>
{% endupdate %}

{% update date="2026-03-10" %}

## Extended Economically Active Addresses to BTC

Extended the `AdrActUSD1Cnt` metric to Bitcoin, capturing addresses that transacted at least 1 USD in a single transfer. This metric was previously available for Ethereum and Solana. For full details refer to the [documentation](https://docs.coinmetrics.io/network-data/network-data-overview/addresses/active-addresses#economically-active-addresses). For full coverage details refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/AdrActUSD1Cnt).
{% endupdate %}

{% update date="2026-02-24" %}

## Added Economically Relevant Addresses

Added a new metric for Ethereum and Solana that captures the count of economically relevant addresses, defined as any address that transacted at least 1 USD in a single transfer - **`AdrActUSD1Cnt`**. For full details and examples refer to the [documentation](https://docs.coinmetrics.io/network-data/network-data-overview/addresses/active-addresses#economically-active-addresses). For full coverage details refer to the coverage page [here](https://coverage.coinmetrics.io/asset-metrics-v2/AdrActUSD1Cnt).
{% endupdate %}

{% update date="2026-02-17" %}

## Release Hourly Exchange and ETF Flow Metrics

Expanded our exchange flow and BTC ETF coverage with hourly flows metrics for all existing assets and exchanges/ETFs. For the full list of exchange please refer to our [Exchange coverage](/network-data/network-data-overview/exchange.md#on-chain-exchange-coverage) and for a full coverage of our ETF coverage please refer to our [ETF Coverage](/network-data/network-data-overview/exchange-traded-fund.md#on-chain-etf-coverage). For details on asset coverage for Exchange Flows and ETF Flows metric please refer to our coverage page ([Exchanges](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv), [ETFs](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInEtfNtv))
{% endupdate %}

{% update date="2026-01-19" %}

## Released Exchange Flows for USDT\_ETH

Released exchange flows for the usdt\_eth asset at the 1d frequency. For details on the supported metrics please refer to the [Exchange](/network-data/network-data-overview/exchange.md)page. For details on Exchange Flow metric coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv).
{% endupdate %}

{% update date="2026-01-12" %}

## $FLOW asset categorized as experimental

All `flow` assets and metrics have been categorized as experimental due to ongoing issues with reliably of the nodes. This imacts the `flow`, `flow_evm` and `flow_native` tickers.
{% endupdate %}

{% update date="2026-01-08" %}

## Added Real Time Exchange Flows for ERC20s

Added block by block support for Exchange flow metrics for USDC\_ETH & PYUSD\_ETH. For details on Exchange Flow metric coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv). For details on exchange metrics please refer to the [Exchange](/network-data/network-data-overview/exchange.md)documentation page.
{% endupdate %}

{% update date="2026-01-05" %}

## Expand CapMrktEstUSD to new Assets

Added estimated market cap to new assets

<details>

<summary>Estimated Market Cap added to the following assets:</summary>

1. a
2. adi
3. beat
4. cusd
5. dog
6. fbtc
7. frxusd
8. icnt
9. lit
10. me
11. moodeng
12. pieverse
13. prime
14. rlp
15. sdai
16. soon
17. stable
18. wsol
19. xpr

</details>
{% endupdate %}

{% update date="2025-12-08" %}

## Added CapMrktEstUSD for 85 New Asset

Added Estimated Market Cap for 85 new assets to fill out top 500 by market cap.

<details>

<summary>Estimated market cap added to the following assets:</summary>

0g\
2z\
ab\
alch\
aleo\
apepe\
aster\
ath\
ausd\
avnt\
b\
bard\
bera\
bfusd\
bianrensheng\
bio\
bmx\
bnsol\
cheems\
dbr\
deep\
drift\
eigen\
fartcoin\
ff\
fluid\
folks\
frxeth\
giggle\
gomining\
grass\
h\
hsk\
hype\
ip\
kaia\
kaito\
kite\
kmno\
kta\
lbtc\
lseth\
merl\
met\_meteora\
meta\_metadao\
meth\
moca\
mon\_monad\
morpho\
move\
myx\
npc\
nxpc\
pengu\
pippin\
pnut\
prove\
pump\
qubic\
recall\
red\
river\
s\
sahara\
sky\_sky\
snek\
solvbtc\
soso\
spx\
strx\
syrup\
toshi\
ub\
uds\
usdr\
useless\
vana\
virtual\
vsn\
wal\
wbeth\
wlfi\
xpl\
zano\
zbcn

</details>
{% endupdate %}

{% update date="2025-12-03" %}

## Added xStocks on Solana to ND Metrics

Added xStocks on Solana to Network Data Metrics.

<details>

<summary>xStocks on Solana added:</summary>

* AAPLX\_SOL - Apple xStock on Solana
* AMZNX\_SOL - Amazon xStock on Solana
* COINX\_SOL - Coinbase xStock on Solana
* CRCLX\_SOL - Circle xStock on Solana
* GOOGLX\_SOL - Alphabet xStock on Solana
* HOODX\_SOL - Robinhood xStock on Solana
* MAX\_MASTERCARDXSTOCK\_SOL - Mastercard xStock on Solana
* MSFTX\_SOL - Microsoft xStock on Solana
* MSTRX\_SOL - MicroStrategy xStock on Solana
* NVDAX\_SOL - NVIDIA xStock on Solana
* QQQX\_SOL - Nasdaq xStock on Solana
* SPYX\_SOL - SP500 xStock on Solana
* TSLAX\_SOL - Tesla xStock on Solana

</details>
{% endupdate %}

{% update date="2025-11-19" %}

## Release Exchange Flows for USDC & PYUSD on Ethereum

Added Exchange flow metrics for USDC\_ETH and PYUSD\_ETH at the daily frequency. For details on Exchange Flow metric coverage please refer to the [coverage page](https://coverage.coinmetrics.io/asset-metrics-v2/FlowInExNtv). For details on exchange metrics please refer to the [Exchange](/network-data/network-data-overview/exchange.md)documentation page.
{% endupdate %}

{% update date="2025-11-10" %}

## Added New Assets to ND Metrics

<details>

<summary>New Assets Added</summary>

arb\_arb.eth\
audio\_eth\
axs\_eth\
band\_eth\
chz\_eth\
eurs\_eth\
ftm\_eth\
gbpt\_eth\
gho\_eth\
grt\_eth\
gyen\_eth\
idrt\_eth\
musd\_metamask\_eth\
rad\_eth\
rlusd\
rlusd\_eth\
sdai\_eth\
slp\_eth\
susde\_eth\
susdf\_eth\
toke\_eth\
usd0\
usd0\_eth\
usd1\
usd1\_eth\
usdcv\_eth\
usdf\_eth\
usdg\
usdg\_eth\
usds\
usds.e\_arb.eth\
usdx\_eth\
xidr\_eth\
xsgd\_eth

</details>
{% endupdate %}
{% endupdates %}


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://gitbook-docs.coinmetrics.io/network-data/network-data-overview.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
