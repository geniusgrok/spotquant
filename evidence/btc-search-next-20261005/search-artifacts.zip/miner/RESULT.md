# BTC 矿工收入构成输入资格（2026-10-05 UTC）

**状态：SEMANTICS_PENDING_NO_ECONOMIC_SCREEN。** 新的信息家族取得了连续的公开历史数据，但未满足预登记的全部字段与时间语义条件；当前不能进入收益筛选或账户比较。

预登记输入为 CoinMetrics `btc` 的 daily `FeeTotNtv` 与 `IssTotNtv`，窗口固定为 **2019-12-01 inclusive 至 2026-09-20 exclusive**。官方字段 reference 明确前者是 native units 的总交易费用且不含新发行，后者是 native units 的新发行总量。它们不同于 dormant-coin 供应，也不等于已知矿工卖币行为。

资格解析保留原始 2486 行，严格按已登记 exclusive end 排除 API 返回的 2026-09-20 一行后，固定窗口 **2485 / 2485 日、总体及每 calendar 年覆盖率均为 100%**。未填补缺日，没有重复/不一致/无效行，手续费非负、新发行与候选 fee-share 分母为正。该排除依照登记窗口，不是事后删负结果；本任务没有计算收益。

未通过的条件是 **官方 BTC subsidy / fee / burn 口径的完整绑定，以及 UTC midnight time 是 daily bucket 起点还是终点的明确绑定**。已取得的 reference 只给出通用 new-units 定义；已取得的 Network Data overview 未说明 daily label 的起止语义。不能依据字段名、行值或常识推定实际可交易时点。

共执行 **4 个 GET、290182 B 原始 body**，其中 `/v4/reference-data/metrics` 返回 404，原失败已保存且未重试；正确 `/v4/reference-data/asset-metrics`、历史 timeseries 和官方 overview 都返回 200。达到已登记的 3 个 definition GET 上限后不再扩请求或改字段、窗口救活。保持继承的 proxy 与 TLS verification，不使用私有凭据。

后续只有在合格的既有官方语义证据或单独登记的新输入资格阶段明确解决上述缺口后，才可登记一个固定的 `FeeTotNtv / (FeeTotNtv + IssTotNtv)` 信息表达。低 fee-share 可能反映收入对补贴的依赖，也可能只是链上需求变化；方向、阈值、七日收益与退出改善均 **尚未筛选**。实际矿工 selling-pressure 推断还需独立的可知持币/流向证据，不能直接用收入构成代替。

数据为当前取得的 canonical chain history，仅属于历史开发代理，不能称为当年已 receipt、vintage 合格或新的 OOS。未修改任何仓库/default；软件测试、账户运行、795 历史会话重放、私有请求均为 **0**。

证据：

- `input-spec.json`：采集前登记的字段、窗口、资格及请求上限。
- `receipts.json`：每个 URL、request / receipt UTC、HTTP 状态、body 大小与 SHA-256。
- `asset-metrics.json`：官方原始 daily 结果，SHA-256 `596d920d0c89fa481b94e0b6a3ecfe65054adc9fdc4603c94ef47853bd1185ac`。
- `reference-metrics.json`：保留 404 原始 body。
- `reference-asset-metrics.json` 与 `network-data-overview.md`：官方定义及 overview 原文。
- `qualification.json`：coverage/schema/重复与语义缺口结果。
- `capture.py` 与 `qualify.py`：本次输入资格研究 producer；未运行经济表达。
