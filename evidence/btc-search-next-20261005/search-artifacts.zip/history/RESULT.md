# Coinbase 历史每日输入资格

本子任务取得了真实公开历史响应。每日价格与汇率字段具备后续统一筛选的输入条件；**本页官方文档没有显式证明 volume 的 base asset 单位，因此成交量份额表达仍不能进入筛选**。这里没有登记经济表达、计算任何收益或修改策略。

## 实际采集

- 固定范围：2022-01-01 00:00 UTC inclusive 至 2026-09-20 00:00 UTC exclusive，共 1,723 个完整每日桶。实际保留的最后一天是 2026-09-19。
- 场所：Coinbase Exchange 公开 REST；产品仅 BTC-USD 与 USDT-USD，未扩大产品、时段或数据提供者。
- 先对两个产品各请求固定 2022 年第一季度。两个 probe 均覆盖 90/90 日；随后各分 6 窗请求剩余固定时段，最长相邻端点差 299 日，以容纳包含 end 边界的最多 300 桶响应。
- 14 个 candles GET 加 1 个官方说明 GET，全为 HTTP 200，原始响应共 208,544 字节；采集墙钟约 3.80 秒。没有失败重试、后台持续采集或私人接口。
- 所有原响应及请求 URL、实际发送/接收毫秒时间、HTTP Date、SHA256 均在 `.raw` 与 `receipts.json`；首次请求前的规格/生产程序 SHA 与真实登记时间在 `registration.json`。

| 输入 | 每日覆盖 | 每年覆盖 | 缺日 | OHLC/时间错误 | 重复不一致 |
|---|---:|---:|---:|---:|---:|
| BTC-USD | 1,723 / 1,723 | 各年 100% | 0 | 0 | 0 |
| USDT-USD | 1,723 / 1,723 | 各年 100% | 0 | 0 | 0 |
| 同步每日桶交集 | 1,723 / 1,723 | 各年 100% | 0 | — | 0 |

固定的整体、每年及同步交集 >=99% 覆盖门槛没有放宽。每个响应额外包含一个 end 边界桶，原始边界全部记录；相邻请求共有 12 个同产品重复边界，内容一致。只输出指定 `[start,end)`，未使用最后的 2026-09-20 桶；没有补零、前填或依据行情挑日。

## 官方语义及使用限制

官方说明 `official-candles-doc.raw` 原文明确：

> Historical rate data may be incomplete. No data is published for intervals where there are no ticks.

> The maximum number of data points for a single request is `300` candles.

close 是桶内最后一笔成交，open 是第一笔成交，time 是桶起点。两产品相同 UTC 日桶与完整覆盖，**不等于两条最后成交同时发生**。换算时只能使用真实的同桶 USDT-USD 价格，不能默认 USDT/USD=1；转换后的日收盘 premium 仍不是同步盘口可套利价。交易费、汇兑费、深度、人工启动延迟与成交路径未在这里证明。

本页只将 volume 定义为 “volume of trading activity during the bucket interval”。解析文件第六字段暂以惯例名 `base_volume` 保存，但没有在捕获的官方页中取得显式 base asset 单位说明，故**名称不构成单位资格**。`qualification.json` 当前准确状态为 `PRICE_FIELDS_QUALIFIED_VOLUME_UNIT_BINDING_PENDING`，`full_semantic_gate_passed=false`；机器初稿只检查 schema/coverage 的宽泛合格状态保留于 `qualification-first.json`，没有删除。根任务可以使用已合格价格字段，成交量份额或 volume 交互必须另行解决单位来源后才使用；这里没有降低语义门槛。

这些是当前实际接收的历史开发数据，不是 2022 至 2026 年当日接收凭证，不能证明当年真实公开版本、是否事后修订或新样本外结果。每日 OHLCV 不包含 aggressor/maker 方向，不推断主动买卖流或参与者身份。

## 可复用文件

- `daily.json`：两产品已按 time 升序去重的固定范围日线；字段为 `[time, low, high, open, close, base_volume]`，第六字段单位限制如上。SHA256 见 `qualification.json`。
- `qualification.json`：当前准确输入状态、逐年覆盖、所有响应范围、重复冲突检查与限制。
- `qualification-spec.json` / `registration.json` / `collect.py`：预先保存的固定资格、真实登记时间及生产程序。
- `receipts.json` / `*.raw` / `documentation.json` / `probe.json`：真实接收原文与首轮 probe 结果。
- Binance 侧只引用既有 `/workspace/btc-decision-loop-20261004/artifacts/market.json.gz` 及原 receipt，parsed SHA256 为 `aa198d0a4a113659c5c00825e0fd69860f647d36678aeccd0d72ce6f5f5e5869`。本子任务没有加载大包、扫描大 vault、再次请求 Binance 或自行计算跨场所信号；根任务统一对齐时复用一次即可。

账户测量、历史会话重放、全量测试、策略改动、私人请求均为 **0**。下一步等待根任务统一的单一家族经济定义；输入可得本身不代表 alpha、beta 或收益改善。
