"""One predeclared Coinbase USD close-premium screen; no volume inference."""
import hashlib, importlib.util, json, statistics, time
from collections import Counter
from decimal import Decimal as D
from pathlib import Path
import sys
sys.path.insert(0, '/workspace/coinquant')
from research.continuous_routes import solve

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
PARENT = Path('/workspace/btc-search-20261005/screen-recovery-weekend.json')
DAY = 86400000
START = 1640995200000
END = 1789862400000

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def fit(rows):
    cols = ['premium_positive','momentum','rms','day_return','spot_flow','perp_flow','log_volume','old_flow','fx_level','fx_return','coinbase_day_return']
    cols = [k for k in cols if k=='premium_positive' or len({r[k] for r in rows})>1]
    if len(rows)<=len(cols)+1 or len({r['premium_positive'] for r in rows})!=2:
        return dict(identifiable=False, count=len(rows), effect=None)
    xs = [[1.,*[float(r[k]) for k in cols]] for r in rows]
    ys = [float(r['net']) for r in rows]
    n = len(xs[0])
    try:
        beta = solve([[sum(x[i]*x[j] for x in xs) for j in range(n)] for i in range(n)], [sum(x[i]*y for x,y in zip(xs,ys)) for i in range(n)])
    except ValueError:
        return dict(identifiable=False,count=len(rows),effect=None)
    return dict(identifiable=True,count=len(rows),effect=beta[1],columns=['intercept',*cols],coefficients=beta,interpretation='Descriptive conditional coefficient, repeatedly used development history; not causal identification/prospective alpha.')

def stats(rows):
    selected = [r for r in rows if r['premium_positive']]
    other = [r for r in rows if not r['premium_positive']]
    mean = lambda group,key: float(statistics.mean(r[key] for r in group)) if group else None
    return dict(count=len(rows),selected=len(selected),gross_mean=mean(selected,'gross'),net_mean=mean(selected,'net'),stress_net_mean=mean(selected,'stress_net'),unselected_gross_mean=mean(other,'gross'))

def main():
    started = time.monotonic()
    spec_raw = (OUT/'screen-spec.json').read_bytes()
    q = json.loads((OUT/'qualification.json').read_text())
    if not(q['probe_qualified'] and q['documentation_qualified'] and all(v['ratio']>=.99 and all(y['ratio']>=.99 for y in v['yearly'].values()) for v in q['coverage'].values())):
        raise ValueError('fixed price-field input qualification missing')
    raw = (OUT/'daily.json').read_bytes()
    if sha(raw)!=q['daily_sha256']:
        raise ValueError('qualified daily input changed')
    packet = json.loads(raw)
    # Only t/open/close fields; volume is explicitly excluded while units are pending.
    cb = {int(r[0])*1000:(D(str(r[3])),D(str(r[4]))) for r in packet['products']['BTC-USD']}
    fx = {int(r[0])*1000:(D(str(r[3])),D(str(r[4]))) for r in packet['products']['USDT-USD']}
    composition_raw = (ROOT/'daily-composition.json').read_bytes()
    bars = {int(k):v for k,v in json.loads(composition_raw)['bars'].items()}
    parent_raw = PARENT.read_bytes();parent=json.loads(parent_raw)
    eligible = {k:[r for r in rows if START<=r['at_ms'] and r['at_ms']+7*DAY<END] for k,rows in parent['events'].items()}
    events,results,missing = {},{},{k:Counter() for k in eligible}
    for kind,saved in eligible.items():
        rows = []
        for original in saved:
            row = dict(original);day=row['signal_day_ms']
            if day not in cb or day not in fx or day not in bars:
                missing[kind]['missing_completed_price_day']+=1;continue
            if row['available_ms']>row['at_ms']:
                raise ValueError('future completed feature')
            co,cc = cb[day];fo,fc=fx[day];bc=D(bars[day]['close'])
            premium = cc/(bc*fc)-1
            row.update(premium_positive=int(premium>0),close_premium=premium,coinbase_close_usd=cc,binance_close_usdt=bc,fx_close_usd_per_usdt=fc,fx_level=fc-1,fx_return=fc/fo-1,coinbase_day_return=cc/co-1)
            for field in ['gross','net','stress_net','funding_cost']:
                row[field]=D(row[field])
            rows.append(row)
        halves=[rows[:len(rows)//2],rows[len(rows)//2:]]
        overall=fit(rows);fits=[fit(part) for part in halves]
        summary=stats(rows);parts=[stats(part) for part in halves]
        gates=dict(coverage=len(rows)>=.90*len(saved),affected10=summary['selected']>=10,half3=all(s['selected']>=3 for s in parts),identifiable=overall['identifiable'] and all(f['identifiable'] for f in fits),incremental_positive=overall['effect'] is not None and overall['effect']>=.005,positive_halves=all(f['effect'] is not None and f['effect']>0 for f in fits),stress_positive_halves=all(s['stress_net_mean'] is not None and s['stress_net_mean']>0 for s in parts),gross_incremental_halves=all(s['gross_mean'] is not None and s['unselected_gross_mean'] is not None and s['gross_mean']>s['unselected_gross_mean'] for s in parts))
        supported=gates['coverage'] and gates['affected10'] and gates['half3']
        results[kind]=dict(status='INFORMATION_SCREEN_ENTRANT' if all(gates.values()) else 'REJECT_FIXED_EXPRESSION' if supported else 'SUPPORT_PENDING',gates=gates,overall=overall,halves=fits,summary=summary,half_statistics=parts,original_eligible_intervals=len(saved),actual_accounts=0,adopted=False)
        events[kind]=rows
    result=dict(format='btc-cross-spot-close-premium-screen-v1',results=results,events=events,missing=missing,input_bindings=dict(daily_sha256=sha(raw),qualification_sha256=sha((OUT/'qualification.json').read_bytes()),composition_sha256=sha(composition_raw),parent_outcome_sha256=sha(parent_raw),spec_sha256=sha(spec_raw),producer_sha256=sha(Path(__file__).read_bytes())),elapsed_seconds=time.monotonic()-started,new_accounts=0,new_sessions=0,full795_replays=0,public_requests=0,volume_used=False,limits='Asynchronous daily last-trade close and existing OHLC/funding seven-day proxies; modeled end+60s historical availability, not original actual receipt-time proof. No executable quote, wallet, native, prospective alpha or true participant flow inference.')
    with (OUT/'screen.json').open('x') as f:
        json.dump(result,f,default=str,indent=2);f.write('\n')
    print(json.dumps(dict(results=results,missing=missing,elapsed_seconds=result['elapsed_seconds']),indent=2))

if __name__=='__main__':
    main()
