#!/usr/bin/env python3
"""Bounded public historical input collection; no strategy/return calculation."""
import datetime as dt
import hashlib
import json
import math
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = json.loads((HERE / 'qualification-spec.json').read_text())
DAY = 86400
def iso(t):
    return dt.datetime.fromtimestamp(t,dt.timezone.utc).isoformat().replace('+00:00','Z')
def stamp(s):
    return int(dt.datetime.fromisoformat(s.replace('Z','+00:00')).timestamp())
def write(name,value):
    (HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        return None
opener=urllib.request.build_opener(NoRedirect)
began=time.monotonic()
receipts=[]
total_bytes=0
start=stamp(SPEC['start_inclusive']); end=stamp(SPEC['end_exclusive'])
probe_end=stamp(SPEC['probe_end_exclusive'])
write('registration.json',{'actual_registered_ms':time.time_ns()//1_000_000,
      'spec_sha256':hashlib.sha256((HERE/'qualification-spec.json').read_bytes()).hexdigest(),
      'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
def get(name,url,limit=500_000):
    global total_bytes
    remaining=SPEC['network_capture_wall_seconds']-(time.monotonic()-began)
    if len(receipts)>=SPEC['get_budget'] or remaining<=0 or total_bytes>=SPEC['raw_bytes_budget']:
        raise RuntimeError('Fixed GET, time or byte budget exhausted')
    sent=time.time_ns(); mono=time.monotonic(); raw=b''; error=None; status=None; headers={}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'BTC-input-research/1.0','Accept':'application/json, text/plain, */*','Accept-Encoding':'identity'})
        try:
            response=opener.open(req,timeout=min(SPEC['single_request_timeout_seconds'],remaining))
        except urllib.error.HTTPError as exc:
            response=exc
        with response:
            status=response.status
            headers={k.lower():v for k,v in response.headers.items() if k.lower()!='set-cookie'}
            maxread=min(limit,SPEC['raw_bytes_budget']-total_bytes)
            raw=response.read(maxread+1)
            if len(raw)>maxread:
                error='RESPONSE_EXCEEDS_FIXED_BYTE_BOUND'
    except Exception as exc:
        error=f'{type(exc).__name__}: {exc}'
    received=time.time_ns(); total_bytes+=len(raw)
    (HERE/(name+'.raw')).write_bytes(raw)
    record={'name':name,'method':'GET','url':url,'status':status,'error':error,
            'sent_ms':sent//1_000_000,'received_ms':received//1_000_000,
            'duration_seconds':time.monotonic()-mono,'headers':headers,
            'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'raw_file':name+'.raw'}
    receipts.append(record); write('receipts.json',receipts)
    return record,raw

def candles(product,a,b,label):
    query=urllib.parse.urlencode({'granularity':DAY,'start':iso(a),'end':iso(b)})
    rec,raw=get(label,'https://api.exchange.coinbase.com/products/'+product+'/candles?'+query)
    valid=[]; reasons=[]
    if rec['status']!=200 or rec['error']:
        reasons.append('HTTP_OR_CAPTURE_FAILURE')
    else:
        try:
            rows=json.loads(raw)
            if not isinstance(rows,list): raise ValueError('not a list')
            for i,row in enumerate(rows):
                if not isinstance(row,list) or len(row)!=6: raise ValueError(f'row {i} field count')
                t,low,high,op,close,volume=row
                if not isinstance(t,int) or t%DAY: raise ValueError(f'row {i} timestamp')
                prices=[low,high,op,close]
                if not all(isinstance(x,(int,float)) and math.isfinite(x) and x>0 for x in prices): raise ValueError(f'row {i} prices')
                if low>min(op,close) or high<max(op,close) or low>high: raise ValueError(f'row {i} OHLC order')
                if not isinstance(volume,(int,float)) or not math.isfinite(volume) or volume<0: raise ValueError(f'row {i} volume')
                if t+DAY>int(time.time()): raise ValueError(f'row {i} unfinished interval')
                valid.append(row)
        except Exception as exc:
            reasons.append('SCHEMA_FAILURE:'+str(exc))
    expected=set(range(a,b,DAY)); times={row[0] for row in valid}
    duplicate_conflicts=[]; seen={}
    for row in valid:
        if row[0] in seen and row!=seen[row[0]]: duplicate_conflicts.append(row[0])
        seen[row[0]]=row
    summary={'product':product,'start_inclusive':iso(a),'end_exclusive':iso(b),
             'requested_difference_days':(b-a)//DAY,'expected_days':len(expected),
             'covered_requested_days':len(expected&times),'missing_times':sorted(expected-times),
             'response_min_time':iso(min(times)) if times else None,'response_max_time':iso(max(times)) if times else None,
             'outside_requested_times':sorted(times-expected),'duplicate_conflicts':duplicate_conflicts,
             'row_count':len(valid),'qualification_failures':reasons,'receipt':rec['name']}
    return summary,valid

products=['BTC-USD','USDT-USD']; observations={p:[] for p in products}; windows=[]
# Validate authoritative documentation once and retain the exact original response.
doc_receipt,doc_raw=get('official-candles-doc',SPEC['documentation_url'],SPEC['documentation_max_bytes'])
doc_text=doc_raw.decode('utf-8',errors='replace')
doc_qualified=doc_receipt['status']==200 and not doc_receipt['error'] and 'No data is published for intervals where there are no ticks' in doc_text and '300' in doc_text
write('documentation.json',{'source':SPEC['documentation_url'],'status':doc_receipt['status'],
      'qualified_no_ticks_and_300_limit':doc_qualified,'historical_revision_warning': 'Historical downloads do not prove original vintage.'})
probe_ok=True
for product in products:
    summary,rows=candles(product,start,probe_end,product.lower()+'-probe')
    windows.append(summary); observations[product].extend(rows)
    probe_ok=probe_ok and not summary['qualification_failures'] and not summary['duplicate_conflicts'] and summary['covered_requested_days']==summary['expected_days']
write('probe.json',{'qualified':probe_ok,'documentation_qualified':doc_qualified,'windows':windows})
if probe_ok:
    a=probe_end; n=0
    while a<end:
        b=min(a+299*DAY,end); n+=1
        for product in products:
            summary,rows=candles(product,a,b,product.lower()+'-'+str(n))
            windows.append(summary); observations[product].extend(rows)
        a=b
deduplicated={}; conflicts=[]
for product in products:
    mapped={}
    for row in observations[product]:
        if row[0] in mapped and mapped[row[0]]!=row: conflicts.append({'product':product,'time':row[0],'first':mapped[row[0]],'second':row})
        mapped.setdefault(row[0],row)
    deduplicated[product]={t:row for t,row in mapped.items() if start<=t<end}
expected=set(range(start,end,DAY)); common=expected.intersection(*(set(deduplicated[p]) for p in products))
coverage={}
for label,times in [(p,set(deduplicated[p])) for p in products]+[('synchronized',common)]:
    yearly={}
    for year in range(2022,2027):
        subset={t for t in expected if dt.datetime.fromtimestamp(t,dt.timezone.utc).year==year}
        yearly[str(year)]={'expected':len(subset),'covered':len(subset&times),'ratio':len(subset&times)/len(subset)}
    coverage[label]={'expected':len(expected),'covered':len(expected&times),'ratio':len(expected&times)/len(expected),
                     'yearly':yearly,'missing_times':sorted(expected-times)}
eligible=probe_ok and doc_qualified and not conflicts and all(not w['qualification_failures'] for w in windows) and all(c['ratio']>=.99 and all(y['ratio']>=.99 for y in c['yearly'].values()) for c in coverage.values())
write('daily.json',{'format':'coinbase-exchange-daily-input-v1','fields':SPEC['fields_expected'],
      'start_inclusive':SPEC['start_inclusive'],'end_exclusive':SPEC['end_exclusive'],
      'products':{p:[deduplicated[p][t] for t in sorted(deduplicated[p])] for p in products}})
write('qualification.json',{'format':'cross-venue-history-input-qualification-result-v1',
      'status':'HISTORICAL_DEVELOPMENT_INPUT_QUALIFIED' if eligible else 'INPUT_NOT_QUALIFIED',
      'probe_qualified':probe_ok,'documentation_qualified':doc_qualified,'coverage':coverage,
      'windows':windows,'cross_request_duplicate_conflicts':conflicts,'get_count':len(receipts),
      'raw_bytes':total_bytes,'capture_wall_seconds':time.monotonic()-began,
      'response_duration_sum_seconds':sum(r['duration_seconds'] for r in receipts),
      'completed_ms':time.time_ns()//1_000_000,'daily_sha256':hashlib.sha256((HERE/'daily.json').read_bytes()).hexdigest(),
      'new_out_of_sample':False,'economic_expression_registered':False,'economic_screen':False,
      'account_days':0,'replays':0,'private_requests':0,
      'limits':['Historical development input, not original-vintage proof.','Separate daily last trades are not guaranteed simultaneous.','Daily base-volume does not provide aggressor direction.','No fill or net profit inference.']})
print(json.dumps({'qualified':eligible,'get_count':len(receipts),'raw_bytes':total_bytes,'capture_wall_seconds':time.monotonic()-began,
                  'coverage':{p:{'covered':c['covered'],'expected':c['expected'],'ratio':c['ratio']} for p,c in coverage.items()}},ensure_ascii=False))
