"""Four preregistered real finite-session wallets; one unchanged NEW-entry veto."""
import array
import bisect
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal as D
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time
import types
import zipfile

ROOT = Path('/workspace/coinquant')
sys.path.insert(0, str(ROOT))
from research import core_accounts as core
from research import rebuild
from research.comparison_report import audit
from research.complete_perp import ResearchExchange
from research.unified_perp import PriorFX
from coinquant.config import Config
from coinquant import session
from coinquant.lifecycle import Lifecycle
from coinquant.state import State

OUT = Path(__file__).parent
SPEC = OUT / 'spec.json'
SCRATCH = Path('/tmp/btc-search-next-20261005-coin-macro-only')
SHARED_PACK_ROOTS = (Path('/workspace/btc-core-rebuild-20261004/parsed-prints-cache'), Path('/tmp/btc-search-next-20261005-coin-accounts/private-parsed-prints-cache'), Path('/tmp/btc-search-next-20261005-coin-accounts-recovery/private-parsed-prints-cache'))
PRINTS = Path('/workspace/scratch/alpha-beta-next/public-print-vault')
DAY = 86400000
BOUND = 500 * 1024 * 1024
spec = json.loads(SPEC.read_text())
SOURCE = rebuild.source_identity()
if SOURCE['dirty'] or SOURCE['git_head'] != spec['producer_head']:
    raise ValueError('registered producer source changed')
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip():
    raise ValueError('source must remain fully clean')
inputs = {}
for f in spec['inputs']:
    p = Path(f['path'])
    raw = p.read_bytes()
    if hashlib.sha256(raw).hexdigest() != f['sha256']:
        raise ValueError('registered dependency changed: ' + str(p))
    inputs[p.name] = json.loads(raw)
bars = {int(k):v for k,v in inputs['daily-composition.json']['bars'].items()}
dates = sorted(bars)
starts = inputs['session_schedule.json']['primary']['starts_ms']

def feature(at_ms):
    day = ((at_ms - 60000) // DAY - 1) * DAY
    i = bisect.bisect_left(dates, day)
    if i < 20 or i == len(dates) or dates[i] != day:
        return None
    if dates[i-20:i] != [day - j * DAY for j in range(20, 0, -1)]:
        return None
    b = bars[day]
    median = statistics.median(D(bars[t]['avg_quote_per_trade']) for t in dates[i-20:i])
    available = day + DAY + 60000
    if available > at_ms:
        raise ValueError('candidate feature is not causally available')
    return dict(day_ms=day, available_ms=available,
                selected=D(b['avg_quote_per_trade']) <= median and D(b['close']) > D(b['open']),
                avg_quote_per_trade=b['avg_quote_per_trade'], preceding20_median=str(median))

def veto_permitted(action, snapshot, pending):
    return action == 'enter' and D(snapshot['quantity_btc']) == 0 and not pending and not snapshot['possible_entry_remainders']

def macro_only_eligible(action, snapshot, pending, model):
    if not veto_permitted(action, snapshot, pending):
        return False
    active, macro = model.active, model.macro_opportunity
    return active is not None and macro is not None and active.identity == macro.identity

# Only2 new actor-scope checks; prior flat/pending/held and causal checks reused.
flat = dict(quantity_btc='0', possible_entry_remainders=False)
assert not macro_only_eligible('enter', flat, [], types.SimpleNamespace(active=types.SimpleNamespace(identity=1), macro_opportunity=types.SimpleNamespace(identity=-1)))
assert macro_only_eligible('enter', flat, [], types.SimpleNamespace(active=types.SimpleNamespace(identity=-1), macro_opportunity=types.SimpleNamespace(identity=-1)))

@contextmanager
def policy_hook(policy, journal):
    original = Lifecycle.decide
    def decide(engine, model, snapshot):
        action = model.action(D(snapshot['quantity_btc']))
        at = int(engine.reader.clock() * 1000)
        active = model.active
        record = dict(at_ms=at, original_action=action, opportunity=active.identity if active else None,
                      quantity_before=snapshot['quantity_btc'], feature=None, veto=False)
        if policy == 'macro-fragmented-upday-new-entry-veto' and macro_only_eligible(action, snapshot, engine.state.pending(), model):
            record['feature'] = feature(at)
            if record['feature'] is None or record['feature']['selected']:
                record.update(veto=True, action='entry_veto', quantity_after=snapshot['quantity_btc'],
                              reason='candidate_feature_unavailable' if record['feature'] is None else 'fragmented_upday')
                journal.append(record)
                return 'entry_veto', snapshot
        journal.append(record)
        result, after = original(engine, model, snapshot)
        record.update(action=result, quantity_after=after['quantity_btc'])
        return result, after
    Lifecycle.decide = decide
    try:
        with core.baseline() as runtime:
            yield runtime
    finally:
        Lifecycle.decide = original

def scratch_bytes():
    return sum(p.stat().st_size for root in (SCRATCH, SHARED_PACK_ROOTS[1].parent, SHARED_PACK_ROOTS[2].parent) for p in root.rglob('*') if p.is_file() and not p.is_symlink())

SCRATCH.mkdir(exist_ok=True)
market, tape = core.optimize_market(Path('/tmp/coinquant-market'), PRINTS, SCRATCH)
# Existing components keep actual matching and virtual time. This change only
# controls derived on-disk cache lifetime, never execution or market semantics.
private_packs = SCRATCH / 'private-parsed-prints-cache'
private_packs.mkdir(exist_ok=True)
selected_cache = SCRATCH / 'selected-prints-cache'
selected_cache.unlink()
selected_cache.symlink_to(private_packs)
tape.cache_dir = private_packs
for root in SHARED_PACK_ROOTS:
    for p in root.glob('*.bin.gz'):
        local = private_packs / p.name
        if not local.exists():
            local.symlink_to(p)
original_load = tape._load

def trim_bins():
    for p in private_packs.glob('*.bin'):
        packed = Path(str(p) + '.gz')
        if not packed.exists():
            free = shutil.disk_usage(SCRATCH).free
            if scratch_bytes() + p.stat().st_size < BOUND and free > p.stat().st_size + 20 * 1024 * 1024:
                with p.open('rb') as source, gzip.open(packed, 'wb', compresslevel=1) as target:
                    shutil.copyfileobj(source, target)
        p.unlink()

def one_day_load(self, day):
    if day != self._day_ms:
        trim_bins()
        self.days.clear()
        name = 'BTCUSDT-aggTrades-' + datetime.fromtimestamp(day/1000,timezone.utc).strftime('%Y-%m-%d') + '.zip'
        path = PRINTS / name
        if path.exists():
            with zipfile.ZipFile(path) as z:
                members = [m for m in z.infolist() if not m.is_dir()]
                if len(members) != 1:
                    raise ValueError('ambiguous fixed print archive')
                conservative_binary_max = min(members[0].file_size, BOUND)
            digest = Path(str(path) + '.CHECKSUM').read_text().split()[0]
            packed = private_packs / (name + '.' + digest + '.bin.gz')
            if packed.exists():
                import struct
                with gzip.open(packed, 'rb') as saved:
                    count = struct.unpack('q', saved.read(8))[0]
                if count < 0:
                    raise ValueError('invalid bound parsed pack count')
                conservative_binary_max = 8 + count * 32
            # Only this new task's regenerable packs may be evicted.
            for cached in sorted(private_packs.glob('*.bin.gz'), key=lambda p:p.stat().st_mtime_ns):
                if scratch_bytes() + conservative_binary_max < BOUND:
                    break
                if not cached.is_symlink():
                    cached.unlink()
            if scratch_bytes() + conservative_binary_max >= BOUND or shutil.disk_usage(SCRATCH).free <= conservative_binary_max + 30 * 1024 * 1024:
                raise OSError('task-private derived-cache resource bound exceeded; no account reset or persistent deletion')
    return original_load(day)
tape._load = types.MethodType(one_day_load, tape)
fx_path = Path('/workspace/starquant/data/usdcny_frankfurter.json')
fx = PriorFX(fx_path)
identity = dict(source=SOURCE, wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                specification_sha256=hashlib.sha256(SPEC.read_bytes()).hexdigest(),
                expression_number=2, policy='macro-fragmented-upday-new-entry-veto',
                baseline_references=spec['baseline_reuse'],
                predicate_sha256=next(f['sha256'] for f in spec['inputs'] if f['path'].endswith('/fragmentation/spec.json')),
                daily_composition_sha256=next(f['sha256'] for f in spec['inputs'] if f['path'].endswith('/daily-composition.json')),
                schedule_sha256=next(f['sha256'] for f in spec['inputs'] if f['path'].endswith('/session_schedule.json')),
                fx_sha256=fx.sha256, base_market_identity=market.identity,
                matcher='trade_print', read_latency_ms=200, write_latency_ms=1000, mark_gap='bound', uid=12000,
                original_fee='0.00075', shared_parsed_cache_read_only=True, task_scratch=str(SCRATCH))
(OUT / 'identity.json').write_text(json.dumps(core.serial(identity), indent=2)+'\n')
(OUT / 'hook-check.json').write_text(json.dumps(dict(passed=True, cases=2, reused_previous_precondition_cases=6, reused_previous_causal_boundary_cases=2,
    meaning='New checks: primary explicitly eligible for original enter; genuine macro can be candidate-vetoed. Prior flat/held/pending/causal checks reused. Original strategy/source guards remain active',
    wrapper_sha256=identity['wrapper_sha256']),indent=2)+'\n')
batch_started = time.monotonic()
summary = []
for begin, end in spec['windows']:
    b,e = core.stamp(begin),core.stamp(end)
    schedule = [s for s in starts if b <= s < e]
    for policy in spec['policies']:
        key = begin + '-' + policy
        output = OUT / (key+'.json')
        if output.exists():
            saved = json.loads(output.read_text())
            if saved['identity']['wrapper_sha256'] != identity['wrapper_sha256'] or not saved['complete_finite']:
                raise ValueError('preserve prior receipt; affected failed case requires explicit recovery output')
            summary.append({k:saved[k] for k in ('case','return_cny','mdd','complete_finite','session_count','elapsed_seconds')})
            continue
        if subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() != SOURCE['git_head']:
            raise ValueError('producer HEAD changed before account; stop without rerunning completed cases')
        directory = SCRATCH / key
        directory.mkdir(exist_ok=False)
        initial = D(10000) / fx(b) * D('.999')
        venue = ResearchExchange(market,b,initial,fx=fx,initial_cny=D(10000),matcher='trade_print',prints=tape,uid=12000,terminal_ms=e)
        venue.read_latency_ms,venue.latency_ms,venue.mark_gap = 200,1000,'bound'
        config = Config('12000',str(directory),300,5)
        reports = []; journal = []; failure = None; case_started = time.monotonic()
        tape.loaded = {}
        with policy_hook(policy,journal) as runtime:
            for i,s in enumerate(schedule):
                try:
                    venue.advance_unattended(s)
                    r = runtime.run(config,venue,execute=True,monotonic=venue.monotonic,wait=venue.wait)
                    reports.append({k:r.get(k) for k in ('status','cleanup','cycles','errors','pending_intents','execution_unresolved','state_backup','session_archive','model_preview')})
                    reports[-1]['start_ms'] = s
                    if r.get('pending_intents') or r.get('execution_unresolved'):
                        failure = dict(phase='session',start_ms=s,reason='unresolved finite execution',report=r)
                        break
                except Exception as exc:
                    failure = dict(phase='session',start_ms=s,error_type=type(exc).__name__,reason=str(exc))
                    break
                print(json.dumps(dict(progress=key,completed_sessions=i+1,registered=len(schedule),elapsed_seconds=time.monotonic()-case_started)),flush=True)
            if failure is None:
                try:venue.advance_unattended(e)
                except Exception as exc:failure=dict(phase='terminal',error_type=type(exc).__name__,reason=str(exc))
        with State(str(directory),config.scope) as state:
            pending=state.pending();ownership=state.get('entry_fill')
        try:mark=rebuild._final_mark(venue) if venue.q else D(0)
        except Exception:mark=None
        final=venue.wallet+venue.q*(mark-venue.entry) if mark is not None else None
        row=dict(trades=venue.trades,funding_ledger=venue.income,position=venue.q,fees=venue.fees,wallet_usdt=venue.wallet,
                 entry=venue.entry,funding=venue.funding_paid,final_mark=mark,final_usdt=final,daily=[v for _,v in sorted(venue.daily.items())],
                 mdd=venue.mdd_envelope,mdd_close=venue.mdd_close,known_path=venue.known_path,unknown_from=venue.unknown_from,
                 hindsight_bounded=venue.hindsight_bounded,bounded_minutes=venue.bounded_minutes,funnel=venue.funnel,
                 price_model='official minute mark; original actual print matcher; bounded/unknown retained',
                 identity=identity,loaded_minute_files=dict(market.loaded),loaded_print_files=dict(tape.loaded),
                 case=key,policy=policy,window=[begin,end],initial_cny='10000',initial_usdt=initial,
                 final_cny=final*fx(e)*D('.999') if final is not None else None,
                 sessions=reports,session_count=len(reports),registered_session_count=len(schedule),failure=failure,
                 pending_intents=pending,ownership=ownership,decision_journal=journal,elapsed_seconds=time.monotonic()-case_started,
                 qualification='NOT_QUALIFIED',native_verified=False)
        row['audit']=audit(core.serial(row),initial,mark) if final is not None else dict(passed=False)
        row['return_cny']=row['final_cny']/10000-1 if final is not None else None
        row['complete_finite']=failure is None and not pending and len(reports)==len(schedule) and row['audit']['passed']
        row['independent_vetoed_opportunities']=sorted(set(x['opportunity'] for x in journal if x['veto'] and x['feature'] and x['feature']['selected']))
        output.write_text(json.dumps(core.serial(row),indent=2)+'\n')
        brief={k:row[k] for k in ('case','return_cny','mdd','complete_finite','session_count','elapsed_seconds','failure','independent_vetoed_opportunities')}
        summary.append(brief); print(json.dumps(core.serial(brief)),flush=True)
        trim_bins()
source_after = rebuild.source_identity()
if source_after != SOURCE:
    raise ValueError('source changed during production; preserve completed raw cases as blocked identity')
(OUT/'summary.json').write_text(json.dumps(core.serial(dict(identity=identity,results=summary,
    elapsed_seconds=time.monotonic()-batch_started,source_after=source_after,
    cumulative_case_elapsed_seconds=sum(D(str(x['elapsed_seconds'])) for x in summary))),indent=2)+'\n')
