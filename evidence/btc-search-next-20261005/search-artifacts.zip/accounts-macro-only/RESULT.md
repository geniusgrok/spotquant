# Fragmentation macro-only: second and final expression rejected

The second, final registered trade-size-composition expression **fails the same two-window account phase**. Applying the unchanged condition only to genuinely new macro entries avoids the first expression's primary-entry veto, but still loses too much 2020 Q2 wealth and does not reduce 2023 Q4 drawdown. The family now has two completed economic expressions and closes without default adoption, a third expression, a threshold adjustment, new dates, or extra stress/control accounts.

| Original quarter | Reused baseline return / MDD | New macro-only return / MDD | Change |
| --- | ---: | ---: | --- |
| 2020 Q2 | +29.1427% / 34.5599% | +12.7201% / 26.1846% | Return -16.4226 pp; MDD -24.23% relative |
| 2023 Q4 | +181.8225% / 22.1154% | +187.2414% / 22.1154% | Return +5.4189 pp; MDD unchanged |

Both new independent CNY 10,000 candidate wallets completed their original 29 / 28 finite sessions, have known paths with no bounded/unknown mark minutes, and passed the project's quantity, realized cash, fees, funding and valued-wallet audit. The two original baseline wallets were reused by exact bytes and SHA-256; neither was remeasured. Source, data, schedule, capital, fees, funding, print matcher, read/write latency and FX remain comparable.

The return route fails because the candidate return is lower in 2020 Q2. The risk route fails because that quarter's final wealth is only approximately **87.28%** of baseline, below the registered 95% minimum, and the second quarter's MDD remains 100% of baseline, above the registered 80% maximum. Positive return in the second window does not allow the original joint requirement to change. The first all-new expression's negative outcome and resource-failure receipts remain untouched.

The narrowing is explicitly based on the earlier actual account's primary-entry delay, so these are **development observations with known selection contamination**, not an independent validation set or prospective alpha. Seven original macro campaigns match this predicate across original chronological halves 3 / 4; the first expression's count of ten is not relabelled as ten macro treatments. This separately registered bounded account phase establishes actual action support in its two windows, not sufficient lifetime/native/default evidence.

## Actual scope and later entry

The actor filter requires the original action `enter`, actual zero position, no pending intent or possible entry remainder, an existing macro opportunity, and current `model.active.identity == model.macro_opportunity.identity`. Primary entries take the original path. The actual journals have **zero primary vetoes**; primary initial fills occur in both windows. `may_enter`, held topups, exits, recovery, protection, checkpoint checks and fill-only opportunity consumption retain their original implementation. Only two new primary-versus-macro eligibility assertions ran; the earlier six safety and two causal checks were reused without repeating them.

There is one genuine vetoed macro opportunity per quarter, **39 polls each, two opportunities total**. Both later actually enter with the same identity: the April 13 macro enters April 20 after 151 hours, and the December 17 macro enters December 18 after 19 hours. These remain delay decisions rather than deletion of whole original campaign cash. The first all-new expression's April primary delay is absent; nevertheless, 2020 Q2 still loses return relative to baseline.

## Efficient bounded execution

Two new candidate wallets executed **57 new finite sessions**. The comparison table includes 57 already-completed baseline sessions, making 114 compared sessions without 114 new invocations. The new strictly serial producer batch took **66.00 seconds**; account case execution summed **65.85 seconds**. Registration through the final producer receipt took **171.43 seconds (2 min 51 sec)**, including implementation. No resource failure recurred.

Derived print packs from the accepted earlier task caches were read-only source material; at most one derived day binary was unpacked into this new task's scratch directory. The aggregate relevant task-cache/state budget remained guarded at 500 MB, with eviction limited to this new task's regenerable packs. No prior wallet state, formal raw receipt, producer, original official ZIP, shared persistent cache, UID, HOME or lock was deleted or changed.

Across the whole family, there are **six completed new wallet cases and one retained blocked instance**: seven constructed wallet instances, 171 completed accepted sessions plus seven completed sessions from the blocked instance, **178 actually executed runtime sessions total**. There are zero new 795 replays, broad/full software suites, network requests, capital sweeps or extra economic controls. The original two baselines are counted once in those totals.

Coin source stayed clean and frozen at `abfec606a235ae88bf5e691965435ab6c50d1fd1`, Python digest `509f579454f814ae329e8e3fcd01a0599465cf75cc29a5ca29b25249b0c861c2`. No repository runtime/default changes were made. Finite simulated MDD and cash results do not establish production qualification or higher prospective alpha/beta.

Evidence: [`spec.json`](spec.json), [`assessment.json`](assessment.json), [`execution-metrics.json`](execution-metrics.json), [`summary.json`](summary.json), [`hook-check.json`](hook-check.json). Raw candidate policies and producer hashes explicitly identify macro-only; baseline parent paths and bytes retain their own original producer identity.
