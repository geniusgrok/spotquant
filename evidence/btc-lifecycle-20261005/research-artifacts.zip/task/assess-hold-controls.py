"""Descriptive reference metrics; no shared-session/adoption gate or replay."""
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0, '/workspace/spotquant')
from research.tradeoff_assessment import wallet_metrics
ROOT=Path(__file__).parent
out=ROOT/'hold-controls-assessment.json'
if out.exists():raise ValueError('retain accepted reference result')
spec=json.loads((ROOT/'accounts-spec.json').read_text())
raw=Path(spec['daily_packet']).read_bytes()
if hashlib.sha256(raw).hexdigest()!=spec['daily_sha256']:raise ValueError('registered prices changed')
prices={int(t):float(row['open']) for t,row in json.loads(raw)['bars'].items()}
rows=[]
for begin,end in spec['windows']:
 for policy in ('hold25','cash0'):
  path=ROOT/'hold-controls'/(begin+'-'+policy+'.json')
  original=path.read_bytes();r=json.loads(original)
  if not r['complete_finite'] or not r['audit']['passed'] or r['production_candidate']:
   raise ValueError('invalid reference wallet')
  daily={v['timestamp_ms']:{c:float(v['equity_'+c.lower()]) for c in ('USDT','CNY')} for v in r['daily']}
  view=dict(daily=daily,initial_cny=r['initial_cny'],initial_usdt=r['initial_usdt'],
   return_cny=float(r['return_cny']),final_cny=float(r['final_cny']),mdd_path_proxy=float(r['mdd']),
   fees_usdt=float(r['audit']['fees_usdt']),funding_paid_usdt=0,fill_count=len(r['fills']))
  rows.append(dict(window=[begin,end],policy=policy,source={'path':str(path),'sha256':hashlib.sha256(original).hexdigest()},
   metrics=wallet_metrics(view,prices),clock=r['decision_clock'],account_independent=True,
   limitation='Unprotected direct single-snapshot offline reference, NOT strict same-session causal alpha proof. Terminal uses last covered close; incumbent finite venue uses boundary quote. No scaling or candidate promotion.'))
result=dict(format='btc-independent-hold-references-v1',results=rows,new_wallets=4,new_sessions=0,new795=0,
 adopted=False,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 interpretation='These references fill the missing true BTC/cash comparison; they do not improve strategies or certify alpha/beta.')
with out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
for row in rows:
 print(json.dumps({k:row[k] for k in ('window','policy','metrics')}))
