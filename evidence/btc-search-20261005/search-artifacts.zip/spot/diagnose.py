"""Read-only attribution of an accepted full-history Spot fill projection.

This creates no wallet, strategy, trade, counterfactual equity or account proof.
All classifications are post-run descriptions of the recorded producer.
"""
from collections import defaultdict, deque
from decimal import Decimal as D
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
INPUT = Path('/workspace/spotquant/evidence/btc-flow-risk-20261004/spot-baseline-projection.json.gz')
started = time.monotonic()
raw = INPUT.read_bytes()
account = json.loads(gzip.decompress(raw))
owners = {str(json.loads(r[3])['orderId']): json.loads(r[1])
          for r in account['allocations'] if 'orderId' in json.loads(r[3])}
fills = sorted(account['fills'], key=lambda r: (r['time'], r['id']))
books = defaultdict(deque)
lots = []
settlements = []
stop_shortfall = []
fees = D(0)
for fill in fills:
    owner = owners[str(fill['order_id'])]
    weights = {int(k): D(v) for k, v in owner['weights'].items()}
    total = sum(weights.values())
    qty, quote, fee = (D(fill[k]) for k in ('qty', 'quote', 'commission'))
    fees += fee * D(fill['price']) if fill['commission_asset'] == 'BTC' else fee
    if fill['buyer']:
        net = qty - (fee if fill['commission_asset'] == 'BTC' else D(0))
        spend = quote + (fee if fill['commission_asset'] == 'USDT' else D(0))
        for sleeve, weight in weights.items():
            quantity = net * weight / total
            lot = {'buy_order_id': fill['order_id'], 'sleeve': sleeve,
                   'time_ms': fill['time'], 'quantity': quantity,
                   'left': quantity, 'spend': spend * weight / total,
                   'proceeds': D(0), 'sold_cost': D(0), 'settlements': []}
            books[sleeve].append(lot)
            lots.append(lot)
    else:
        removed = qty + (fee if fill['commission_asset'] == 'BTC' else D(0))
        proceeds = quote - (fee if fill['commission_asset'] == 'USDT' else D(0))
        for sleeve, weight in weights.items():
            amount = removed * weight / total
            while amount > D('1e-23'):
                if not books[sleeve]:
                    raise ValueError('SELL exceeds owned quantity')
                lot = books[sleeve][0]
                take = min(amount, lot['left'])
                portion_proceeds = proceeds * take / removed
                portion_cost = lot['spend'] * take / lot['quantity']
                kind = 'native_STOP_LOSS' if owner['order']['type'] == 'STOP_LOSS' else 'MARKET_exit_reason_unknown'
                event = {'buy_order_id': lot['buy_order_id'], 'sell_order_id': fill['order_id'],
                         'sleeve': sleeve, 'time_ms': fill['time'], 'quantity': take,
                         'cost': portion_cost, 'proceeds': portion_proceeds,
                         'pnl': portion_proceeds - portion_cost, 'exit_kind': kind}
                settlements.append(event)
                lot['settlements'].append(event)
                lot['proceeds'] += portion_proceeds
                lot['sold_cost'] += portion_cost
                lot['left'] -= take
                amount -= take
                if lot['left'] <= D('1e-23'):
                    books[sleeve].popleft()
        if owner['order']['type'] == 'STOP_LOSS':
            stop = D(owner['order']['stopPrice'])
            # Recorded trigger-to-fill shortfall, not a recoverable cost claim.
            stop_shortfall.append({'sell_order_id': fill['order_id'], 'time_ms': fill['time'],
                                   'trigger_price': stop, 'fill_price': D(fill['price']),
                                   'trigger_vs_fill_quote': (stop - D(fill['price'])) * qty,
                                   'trigger_vs_fill_bp': (stop - D(fill['price'])) / stop * 10000})

def year(stamp):
    return datetime.fromtimestamp(stamp / 1000, timezone.utc).year

def aggregate(rows):
    return {'count': len(rows), 'cost_usdt': sum((r['cost'] for r in rows), D(0)),
            'proceeds_usdt': sum((r['proceeds'] for r in rows), D(0)),
            'realized_pnl_usdt': sum((r['pnl'] for r in rows), D(0)),
            'gross_profit_usdt': sum((max(r['pnl'], D(0)) for r in rows), D(0)),
            'gross_loss_usdt': sum((min(r['pnl'], D(0)) for r in rows), D(0))}

remaining = sum((r['left'] for r in lots), D(0))
sold_pnl = sum((r['pnl'] for r in settlements), D(0))
remaining_cost = sum((r['spend'] - r['sold_cost'] for r in lots), D(0))
last_daily = max(account['daily'].values(), key=lambda r: r['timestamp_ms'])
marked = remaining * D(last_daily['price_usdt'])
initial_cash = D(min(account['daily'].values(), key=lambda r: r['timestamp_ms'])['cash_usdt'])
cash_identity = D(account['cash_usdt']) - initial_cash - sold_pnl + remaining_cost
quantity_identity = remaining - D(account['btc'])
if abs(cash_identity) > D('1e-18') or abs(quantity_identity) > D('1e-20'):
    raise ValueError('Attribution cash/quantity identity failed')

cohorts = defaultdict(list)
for lot in lots:
    cohorts[lot['buy_order_id']].append(lot)
cohort_rows = []
for identity, group in cohorts.items():
    pnl = sum((r['proceeds'] - r['sold_cost'] for r in group), D(0))
    notional = sum((r['sold_cost'] for r in group), D(0))
    cohort_rows.append({'buy_order_id': identity, 'time_ms': group[0]['time_ms'],
                        'entry_year': year(group[0]['time_ms']), 'sleeves': [r['sleeve'] for r in group],
                        'cost_usdt': notional, 'realized_pnl_usdt': pnl,
                        'realized_pnl_per_cost': pnl / notional if notional else None,
                        'residual_btc': sum((r['left'] for r in group), D(0))})

days = sorted(account['daily'].values(), key=lambda r: r['timestamp_ms'])
returns = []
for prior, current in zip(days, days[1:]):
    before, after = D(prior['equity_usdt']), D(current['equity_usdt'])
    returns.append({'time_ms': current['timestamp_ms'], 'prior_owned_notional_usdt': D(prior['gross_notional_usdt']),
                    'equity_change_usdt': after-before, 'return_usdt': after / before - 1})
returns.sort(key=lambda r: r['return_usdt'])
loss_cohorts = sorted((r for r in cohort_rows if r['realized_pnl_usdt'] < 0), key=lambda r: r['realized_pnl_usdt'])
profit_cohorts = sorted((r for r in cohort_rows if r['realized_pnl_usdt'] > 0), key=lambda r: r['realized_pnl_usdt'], reverse=True)
result = {
    'format': 'spot-existing-fill-diagnosis-v1',
    'source': {'path': str(INPUT), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
               'bytes': len(raw), 'parent_binding': account['parent_binding'],
               'diagnostic_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
    'inventory': {'buy_batches': len(cohorts), 'fills': len(fills),
                  'recorded_sessions_not_executed_here': len(account['sessions']),
                  'owned_lots': len(lots), 'settlement_fragments': len(settlements)},
    'identities': {'cash_error_usdt': cash_identity, 'quantity_error_btc': quantity_identity,
                   'remaining_btc': remaining, 'remaining_cost_usdt': remaining_cost,
                   'remaining_mark_usdt': marked},
    'overall': aggregate(settlements),
    'fees_at_recorded_fill_prices_usdt': fees,
    'by_sleeve': {str(w): aggregate([r for r in settlements if r['sleeve']==w]) for w in (30, 40, 50)},
    'by_exit_order_type': {k: aggregate([r for r in settlements if r['exit_kind']==k])
                           for k in sorted({r['exit_kind'] for r in settlements})},
    'by_sell_year': {str(y): aggregate([r for r in settlements if year(r['time_ms'])==y])
                      for y in sorted({year(r['time_ms']) for r in settlements})},
    'cohorts': cohort_rows,
    'loss_concentration': {'loss_batches': len(loss_cohorts),
                         'total_losses_usdt': sum((-r['realized_pnl_usdt'] for r in loss_cohorts), D(0)),
                         'worst_three_usdt': sum((-r['realized_pnl_usdt'] for r in loss_cohorts[:3]), D(0)),
                         'worst_three': loss_cohorts[:3]},
    'profit_concentration': {'profit_batches': len(profit_cohorts),
                           'total_profits_usdt': sum((r['realized_pnl_usdt'] for r in profit_cohorts), D(0)),
                           'best_three_usdt': sum((r['realized_pnl_usdt'] for r in profit_cohorts[:3]), D(0)),
                           'best_three': profit_cohorts[:3]},
    'worst_five_daily_USDT_losses': returns[:5],
    'native_stop_trigger_fill_observations': stop_shortfall,
    'elapsed_seconds': time.monotonic()-started,
    'new_accounts': 0, 'new_sessions': 0, 'network_requests': 0,
    'limitations': ['Existing full-history account attribution; no new or counterfactual account.',
                   'All history already researched; no out-of-sample or prospective alpha evidence.',
                   'FIFO belongs to recorded ownership, not hypothetical independently funded sleeves.',
                   'Market-order exit reasons are unavailable in this projection and stay unknown.',
                   'Stop trigger-to-fill differences are recorded model outcomes, not maker savings or causal diagnoses.',
                   'PnL is USDT realized cash attribution; not CNY CAGR, MDD or adoption evidence.']}
ROOT.joinpath('diagnosis.json').write_text(json.dumps(result, default=str, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ('inventory', 'overall', 'by_sleeve', 'by_exit_order_type',
                                      'loss_concentration', 'profit_concentration',
                                      'fees_at_recorded_fill_prices_usdt', 'identities', 'elapsed_seconds')}, default=str, indent=2))
