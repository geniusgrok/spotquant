# Existing BTC mechanism inventory — 2026-10-05

Read-only repository/evidence inventory. No project changes, tests, account replay, public requests, or large-vault reads. The inventory covers the current two repositories' research implementations/specifications/results and selected historical result summaries; it is not a proof about every deleted experiment in Git history.

## Closed or already researched mechanisms

| Family | Existing evidence and boundary |
|---|---|
| Incumbent parameter/risk sensitivity | `coinquant/evidence/remeasure-20260929-m10/RESULT.md`, `coinquant/research/alpha_beta_spec.json`: ordinary risk/signal neighbours, capital/start timing diagnostics. Start-offset sensitivity is observed, not permission to optimize the schedule. |
| SMA reentry / participation / ATR / persistent core; primary freshness / ATR trail / compression / topup | `research/alpha_beta_spec.json` and accepted alpha-beta account evidence. Some Spot ATR work adopted; other expressions screened/rejected. Renaming these expressions is not a new mechanism. |
| Exit confirmation / stop-risk budgets / crowding; quality / cost horizon | `research/edge-RESULT.md`: Coin all three reject; Spot crowding adopted but historical improvement is from missing-input blocking, not actual crowding-halving profitability. |
| Price-only trend participation / pullback repair | `research/upgrade-RESULT.md`: Spot recovery reentry/slow SMA and Coin pullback repair reject. Coin primary/macro simultaneous positions already prevented by architecture. |
| Small slow cash core / cash-only short | `research/structure-RESULT.md`: Spot two quarter comparisons worse; Coin four quarter comparisons zero new shorts and zero treatment. |
| Daily paired active-flow signs | `research/flow-risk-RESULT.md`: completed perp imbalance>0 and Spot<=0, actual new-BUY veto; Spot 13 independent opportunities negative avoided P&L; Coin 7 negative/insufficient. |
| Soft expression of same flow / risk attribution / cost savings | `research/continuous-RESULT.md`: Spot conditional seven-day signal survives weak information gate, actual quarter treatment zero; Coin no information entrant. .75 budget does not open a new information family. ATR-pressure trims fail economic/simple controls. Fragment aggregation demonstrable fee saving zero. |
| Chase / repair / macro handoff / trend-range opportunity / joint caps | `research/persistent-RESULT.md`: chase six losing avoided-P&L events; repair zero; macro handoff one/restart zero; trend Spot 33/Coin 20 fails era gates; range insufficient. Shared joint gross/pressure controls and stateful entry rules already implemented. |
| ETF / OI contraction + positive active Spot support / option skew-term / old-coin supply / dollar funding | `research/nine-RESULT.md`, `research/loop-RESULT.md`: qualification or maturity pending, not profitable validated families. Actual joint stress budget passes only 2020Q1; second window lacks treatment; state cap fails first. |
| Persistent Spot-led active flow | `research/loop-spec.json`, `research/loop-RESULT.md`: two days Spot>.10, perp<=0, both Spot daily prices up and basis<=0; 791 complete starting contexts/251 non-overlapping periods but zero triggers. Mirrored inverse BUY expression lacks usable treatment. |
| Known announcement / IV risk / intraday limit execution / protection liquidity gap | `research/loop-RESULT.md`: calendar source unavailable, option one receipt day/unmatured, historical same-clock queue/depth absent, no qualified protection gap. |
| Continuous daily trend / shock recovery / independent downside / funding carry / state combination | `research/core-RESULT.md`: trend core economically deteriorates and was rolled back; shock 0/3 eras; downside 0/3; carry corrected-clock and holding-cost repair both 0/3; state no complementary improvement. |
| Genuine deleveraging with forced selling / option risk / executable dated basis | `research/replacement-RESULT.md`: all WAIT qualified data; no account entrant. Full adoption now requires material economic improvement, not an install-anyway clause. |

## One mechanism worth a small falsification screen

**Price response against active sell pressure**, using only already available completed BTC Spot daily bars. This is a new interaction question, not the old positive-active-buy confirmation or the Spot/perp sign disagreement filter. Existing "Spot absorption" specifications specifically require positive active Spot flow and OI/forced-selling evidence; they do not test active Spot net selling with a nonnegative price response.

Completed day fields `[open,high,low,close,quote,taker_buy_quote]` permit:

- Signed active imbalance `s = 2*taker_buy_quote/quote - 1`.
- Same-day response `r = close/open - 1`.
- Fixed sign event `s<0 and r>=0`; optional continuous strength `max(-s,0)*max(r/prior20_RMS,0)` decided before results, not threshold grids.
- Ask whether this interaction predicts a positive seven-day cost-net BTC price proxy from the **next frozen actual manual session** beyond contemporaneous price response, prior20 momentum/RMS, active Spot flow itself, and the already-tested perp/Spot sign flag. Distinguish entire opportunity generator from effect on incumbent actually legal BUY/flat states.
- Compare information at day completion+60s and return at the original manual clock. If the effect vanishes after the manual delay, retire this research expression; do not select more profitable historical session offsets.
- Use non-overlapping events and the fixed historical eras; apply explicit fee/slippage/funding approximations for screening. No result from this proxy establishes actual account profit, executable order fills, or genuine participant identity. "Passive absorption" is a hypothesis, not observed owner attribution from candles.
- Falsify first. Reject if net effect is absent/inconsistent after price/flow controls or lacks sufficient independent events. Do not turn a failed interaction into the old opposite-sign flow filter by changing thresholds or signs.

No performance result was computed by this inventory agent.

## One distinct fallback

**Pre-known UTC weekend liquidity/risk regime** has no matching completed experiment found in current research sources/specs/results. A known day-of-week dummy is causal without needing retrospective economic-release vintages. First ask if net seven-day returns or future downside differ at the frozen actual starts, after momentum/volatility controls; if risk differentiation survives, compare against simple constant smaller risk before proposing weekend-specific new-risk budgets. Use a single fixed Sat/Sun definition, not best weekday/hour searches. No contemporaneous order-book cost or spread can be inferred from daily bars alone. The existing CPI/Fed announcement calendar branch and publication-date FX rules are different mechanisms.

## Exact available small inputs

1. `/workspace/btc-decision-loop-20261004/artifacts/market.json.gz` — 7,353,213 bytes, SHA256 `aa198d0a4a113659c5c00825e0fd69860f647d36678aeccd0d72ce6f5f5e5869`.
   - `spot`: 2,819 completed UTC daily bars, open_ms 1546300800000 to 1789776000000.
   - `coin4`: 14,724 completed 4h bars, open_ms 1577836800000 to 1789848000000. Daily aggregation must sum quote and taker amounts before computing imbalance.
   - `mark`: 260,611 minute bars for selected old risk months; unused for the information screen.
   - Rows are `[open, high, low, close, quote_volume, taker_buy_quote_volume]` for Spot/coin4; mark has four prices.
2. Same-path `.receipt.json` binds parser and original ZIP/CHECKSUM metadata plus parsed hash. Copy of receipt also in `/workspace/spotquant/evidence/btc-loop-20261004/market.json.gz.receipt.json`.
3. Original small official archives: `/tmp/spotquant-market/klines/1d/BTCUSDT-1d-*.zip` and `/tmp/coinquant-market/klines/4h/BTCUSDT-4h-*.zip`, with `daily` subdirectories and CHECKSUM companions. Prior flow screen read roughly 1.15 MB including warmup; no need to scan aggregate-trade vault. Raw CSV additionally contains trade count, which the current six-field parsed cache omits. No trade-count signal analysis found in current code; not an extra proposed route here.
4. Original frozen manual clock: `/workspace/coinquant/research/session_schedule.json` (795 historical starts; reading this list is not executing 795 sessions).
5. Small complete incumbent ledger projections and parent identities:
   - `/workspace/spotquant/evidence/btc-flow-risk-20261004/spot-baseline-projection.json.gz` — 692,654 bytes, SHA256 `ef32a84a7e89cfd7ea3d76a8c6fa56a1da95546500269a8a0b688047f94a2118`.
   - `/workspace/spotquant/evidence/btc-flow-risk-20261004/coin-baseline-projection.json.gz` — 876,880 bytes, SHA256 `df118eb7eb89140e0a4a415c2ba0f521b14f8603ec148355109d07d35384436d`.
   - Parent/source IDs are preserved in `baseline-inputs.json`; do not relabel these historical producers with a new source revision.

Completed-bar availability+60s is the existing modeled causal convention, not measured historical publication latency. All previously seen historical periods remain development data. New mechanism novelty does not make the historical data a fresh out-of-sample proof.
