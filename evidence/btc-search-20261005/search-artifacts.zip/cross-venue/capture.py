"""One fixed, small, public data-availability probe; no accounts or replay."""
import concurrent.futures
import hashlib
import json
import pathlib
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parent
ENDPOINTS = [
    ("coinbase-btc-usd-book", "https://api.exchange.coinbase.com/products/BTC-USD/book?level=1"),
    ("coinbase-btc-usdt-book", "https://api.exchange.coinbase.com/products/BTC-USDT/book?level=1"),
    ("coinbase-usdt-usd-book", "https://api.exchange.coinbase.com/products/USDT-USD/book?level=1"),
    ("coinbase-btc-usd-trades", "https://api.exchange.coinbase.com/products/BTC-USD/trades?limit=20"),
    ("coinbase-time", "https://api.exchange.coinbase.com/time"),
    ("kraken-usd-tickers", "https://api.kraken.com/0/public/Ticker?pair=XBTUSD,USDTUSD"),
    ("kraken-btc-usd-trades", "https://api.kraken.com/0/public/Trades?pair=XBTUSD&count=20"),
]

def iso(ns):
    return datetime.fromtimestamp(ns / 1e9, timezone.utc).isoformat()

def get_one(endpoint):
    name, url = endpoint
    started_ns = time.time_ns()
    mono = time.monotonic()
    status, headers, body, error = None, {}, b"", None
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "BTC-Public-Data-Availability-Research/1.0", "Accept": "application/json"})
        with urllib.request.urlopen(request, timeout=10) as response:
            status = response.status
            headers = dict(response.headers.items())
            body = response.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        headers = dict(exc.headers.items()) if exc.headers else {}
        body = exc.read()
        error = repr(exc)
    except Exception as exc:
        error = repr(exc)
    finished_ns = time.time_ns()
    raw_path = ROOT / (name + ".raw")
    raw_path.write_bytes(body)
    receipt = {
        "name": name, "url": url, "method": "GET", "private_request": False,
        "request_ns": started_ns, "receipt_ns": finished_ns,
        "request_utc": iso(started_ns), "receipt_utc": iso(finished_ns),
        "elapsed_seconds": time.monotonic() - mono,
        "status": status, "headers": headers, "error": error,
        "raw_file": raw_path.name, "bytes": len(body),
        "raw_sha256": hashlib.sha256(body).hexdigest(),
    }
    (ROOT / (name + ".receipt.json")).write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    return receipt

if __name__ == "__main__":
    ROOT.mkdir(parents=True, exist_ok=True)
    if (ROOT / "receipts.json").exists():
        raise SystemExit("Already captured: never silently repeat the fixed probe.")
    spec = {
        "format": "btc-cross-spot-availability-20261005-v1",
        "registered_ns": time.time_ns(),
        "hypothesis": "BTC demand migration between independent USD and USDT spot venues may contain incremental information beyond incumbent BTC momentum, volatility, Binance spot/perpetual flow, and ETF tables.",
        "fixed_probe": "One simultaneous request batch for Coinbase BTC/USD and BTC/USDT books, Coinbase USDT/USD conversion book, Kraken BTC/USD and USDT/USD tickers, and BTC/USD recent trades at each venue.",
        "max_public_gets": 7, "retry_count": 0, "request_timeout_seconds": 10,
        "binance_requests": 0, "accounts": 0, "orders": 0, "replay_sessions": 0,
        "qualification": {
            "receipt_span_seconds_max": 10,
            "request_latency_seconds_max": 2,
            "all_comparison_legs_need_bid_ask_units_and_venue_event_time": True,
            "venue_event_age_seconds_max": 2,
            "http_date_not_orderbook_event_time": True,
            "trade_aggressor_direction_requires_bound_authoritative_semantics": True,
            "one_snapshot_not_predictive_alpha_or_economic_evidence": True,
            "book_midpoint_premium_not_executable_arbitrage": True,
            "qualified_forward_labels_need_future_actual_receipts_and_matched_outcomes": True,
        },
        "analysis_lock": "No alternative thresholds, delayed retry, weekday selection, trade-side reinterpretation, or backfilled reception time after observing this result.",
        "endpoints": [{"name": name, "url": url} for name, url in ENDPOINTS],
        "producer_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    }
    (ROOT / "spec.json").write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n")
    with concurrent.futures.ThreadPoolExecutor(max_workers=7) as executor:
        receipts = list(executor.map(get_one, ENDPOINTS))
    result = {
        "spec_sha256": hashlib.sha256((ROOT / "spec.json").read_bytes()).hexdigest(),
        "public_gets": len(receipts), "retries": 0, "private_requests": 0,
        "accounts": 0, "orders": 0, "replay_sessions": 0,
        "http_200": sum(r["status"] == 200 for r in receipts),
        "raw_bytes": sum(r["bytes"] for r in receipts),
        "request_span_seconds": (max(r["request_ns"] for r in receipts) - min(r["request_ns"] for r in receipts)) / 1e9,
        "receipt_span_seconds": (max(r["receipt_ns"] for r in receipts) - min(r["receipt_ns"] for r in receipts)) / 1e9,
        "capture_total_seconds": (max(r["receipt_ns"] for r in receipts) - min(r["request_ns"] for r in receipts)) / 1e9,
        "receipts": receipts,
    }
    (ROOT / "receipts.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "receipts"}, ensure_ascii=False))
    for receipt in receipts:
        print(json.dumps({k: receipt[k] for k in ("name", "status", "bytes", "elapsed_seconds", "error")}, ensure_ascii=False))
