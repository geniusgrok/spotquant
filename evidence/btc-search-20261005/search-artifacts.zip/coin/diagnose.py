"""Saved-ledger diagnosis only: no replay, fitting, trading or CAGR inference."""
import collections, datetime, gzip, hashlib, json
from decimal import Decimal as D
from pathlib import Path
OUT=Path(__file__).parent
ROOT=Path('/workspace/coinquant')
SRC=ROOT/'evidence/btc-flow-risk-20261004/coin-baseline-projection.json.gz'
j=json.loads(gzip.decompress(SRC.read_bytes()))
led=j['opportunity_ledger']; writes={e['identity']:e for e in led if e['event']=='write_attempt' and e['method']=='POST' and e['payload'].get('side')=='BUY'}
meta={e['trade']['id']:e for e in led if e['event']=='fill'}
quantity=D(0); baskets=[]; current=None
for t in sorted(j['trades'],key=lambda t:(t['time'],t['id'])):
 q,p=D(t['qty']),D(t['price']); fm=meta[t['id']]
 if t['side']=='BUY':
  if not quantity:
   w=writes[fm['client_order_id']]
   current={'campaign':w['opportunity'],'at_ms':t['time'],'closed_ms':None,'buy_notional':D(0),'buy_qty':D(0),'sell_qty':D(0),'fill_count':0,'buy_orders':set(),'exit_types':set(),'first_order':fm['client_order_id']};baskets.append(current)
  current['buy_notional']+=q*p;current['buy_qty']+=q;current['buy_orders'].add(fm['client_order_id']);quantity+=q
 else:
  if current is None or q>quantity:raise ValueError('unowned sale')
  current['sell_qty']+=q;quantity-=q;current['exit_types'].add(fm.get('exit_type'))
  if not quantity:current['closed_ms']=t['time']
 current['fill_count']+=1
last=max(t['time'] for t in j['trades'])
for b in baskets:
 for income in ['REALIZED_PNL','COMMISSION','FUNDING_FEE']:
  b[income]=sum((D(x['income']) for x in j['funding_ledger'] if b['at_ms']<=x['time']<=(b['closed_ms'] or last) and x['incomeType']==income),D(0))
 b['net']=sum((b[k] for k in ['REALIZED_PNL','COMMISSION','FUNDING_FEE']),D(0))
 b['net_over_notional']=b['net']/b['buy_notional']
 b['family']='primary' if b['campaign']>0 else 'macro'
 b['hours']=(D(b['closed_ms'] or last)-b['at_ms'])/3600000
 b['buy_orders']=sorted(b['buy_orders']);b['exit_types']=sorted(map(str,b['exit_types']))
 entry=next(e for e in led if e['event']=='entry_sizing' and e['opportunity']==b['campaign'] and e['at_ms']<=b['at_ms'])
 b['first_sizing']=entry;b['first_order_requested']=D(writes[b['first_order']]['payload']['quantity'])
 b['first_order_filled']=sum((D(t['qty']) for t in j['trades'] if t['side']=='BUY' and meta[t['id']]['client_order_id']==b['first_order']),D(0))
 b['final_fill_over_first_requested']=b['buy_qty']/b['first_order_requested']
 b['first_fill_fraction']=b['first_order_filled']/b['first_order_requested']
 constraints=collections.Counter(e['constraint'] for e in led if e['event']=='topup_sizing' and e['opportunity']==b['campaign'])
 b['topup_constraints']=dict(constraints)
 b['gross_loss_but_funding_positive']=b['REALIZED_PNL']<0 and b['FUNDING_FEE']>0
all_filled={meta[t['id']]['client_order_id'] for t in j['trades'] if t['side']=='BUY'}
zero=[]
for identity,w in writes.items():
 if identity in all_filled:continue
 opp=w['opportunity']; later=[b for b in baskets if b['campaign']==opp and b['at_ms']>w['at_ms']]
 nextdecision=next((e for e in led if e['event']=='decision' and e['at_ms']>w['at_ms'] and e['opportunity']==opp),None)
 zero.append({'write':w,'later_same_campaign_fill_ms':later[0]['at_ms'] if later else None,'next_same_opportunity_decision':nextdecision})
byfamily={}
for fam in ['primary','macro']:
 bs=[b for b in baskets if b['family']==fam];byfamily[fam]={'campaigns':len(bs),'positive':sum(b['net']>0 for b in bs),'negative':sum(b['net']<0 for b in bs),'gross_realized':sum((b['REALIZED_PNL'] for b in bs),D(0)),'commission':sum((b['COMMISSION'] for b in bs),D(0)),'funding':sum((b['FUNDING_FEE'] for b in bs),D(0)),'net':sum((b['net'] for b in bs),D(0))}
byyear={}
for b in baskets:
 year=datetime.datetime.fromtimestamp(b['at_ms']/1000,datetime.timezone.utc).year
 byyear.setdefault(year,{'campaigns':0,'gross':D(0),'fees':D(0),'funding':D(0),'net':D(0)})
 byyear[year]['campaigns']+=1
 for a,key in [('gross','REALIZED_PNL'),('fees','COMMISSION'),('funding','FUNDING_FEE'),('net','net')]:byyear[year][a]+=b[key]
funding_negative_gross_positive=[b for b in baskets if b['REALIZED_PNL']>0 and b['net']<0]
report={'analysis':'saved_coin_campaign_diagnosis_v1','source_path':str(SRC),'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'parent_binding':j['parent_binding'],'analysis_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'replayed_sessions':0,'new_account_measurements':0,'network_requests':0,'candidate_adopted':False,'by_family':byfamily,'by_entry_year':byyear,'baskets':baskets,'zero_fill_writes':zero,'gross_positive_net_negative_campaigns':[b['campaign'] for b in funding_negative_gross_positive],'ledger_totals':{k:sum((D(x['income']) for x in j['funding_ledger'] if x['incomeType']==k),D(0)) for k in ['REALIZED_PNL','COMMISSION','FUNDING_FEE']},'limitations':['All observed history is development data.','Amounts are realized saved-wallet attribution, not candidate profits, independent alpha, or CAGR.','Entry-year grouping includes whole subsequent realized campaign result.','Largest cash gains depend on wallet compounding; ranks cannot be used as tradable filters.','No fill or funding counterfactual; no claimed loss prevention.']}
(OUT/'diagnostic.json').write_text(json.dumps(report,default=str,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['baskets','zero_fill_writes']},default=str,indent=2))
print('zero fill writes',len(zero),'same campaign eventual fills',sum(z['later_same_campaign_fill_ms'] is not None for z in zero))
print('exit types',collections.Counter(k for b in baskets for k in b['exit_types']))
print('STOP_BUDGET CAMPAIGNS',sum('stop_budget' in b['topup_constraints'] for b in baskets))
print('FIRST PARTIAL UNDER .25',sum(b['first_fill_fraction']<D('.25') for b in baskets),'FINAL UNDER .25',sum(b['final_fill_over_first_requested']<D('.25') for b in baskets))
print('TOP 8 NET',[(b['campaign'],str(b['net']),str(b['net_over_notional']),b['family']) for b in sorted(baskets,key=lambda b:b['net'],reverse=True)[:8]])
print('BOTTOM 8 NET',[(b['campaign'],str(b['net']),str(b['net_over_notional']),b['family']) for b in sorted(baskets,key=lambda b:b['net'])[:8]])
