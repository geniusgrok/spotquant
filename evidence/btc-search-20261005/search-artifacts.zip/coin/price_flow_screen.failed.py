"""One fixed price-response screen using existing small immutable monthly spot Klines."""
import bisect, csv, gzip, hashlib, io, json, time, zipfile
from pathlib import Path
from decimal import Decimal as D
OUT=Path(__file__).parent;ROOT=Path('/workspace/coinquant');DAY=86400000
started=time.perf_counter();sources=[]
spec=OUT/'screen-spec.json';s=json.loads(spec.read_text());sources.append({'path':str(spec),'sha256':hashlib.sha256(spec.read_bytes()).hexdigest()})
account=ROOT/'evidence/btc-flow-risk-20261004/coin-baseline-projection.json.gz';j=json.loads(gzip.decompress(account.read_bytes()));sources.append({'path':str(account),'sha256':hashlib.sha256(account.read_bytes()).hexdigest()})
parent=ROOT/'evidence/btc-flow-risk-20261004/screen-recovery2.json';p=json.loads(parent.read_text());sources.append({'path':str(parent),'sha256':hashlib.sha256(parent.read_bytes()).hexdigest()})
bars={};compressed=0
for src in p['inputs']:
 if '/spotquant-market/klines/1d/' not in src['path']:continue
 f=Path(src['path']);raw=f.read_bytes();sha=hashlib.sha256(raw).hexdigest()
 if sha!=src['sha256']:raise ValueError('immutable Kline source differs')
 sources.append({'path':str(f),'sha256':sha,'bytes':len(raw)});compressed+=len(raw)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  names=[n for n in z.namelist() if not n.endswith('/')]
  if len(names)!=1:raise ValueError('ambiguous monthly archive')
  for row in csv.reader(io.StringIO(z.read(names[0]).decode())):
   if not row[0].isdigit():continue
   stamp=int(row[0]);stamp=stamp//1000 if stamp>10**14 else stamp
   o,h,l,c,q,t=map(D,[row[1],row[2],row[3],row[4],row[7],row[10]])
   if not(0<l<=min(o,c)<=max(o,c)<=h and q>0 and 0<=t<=q):raise ValueError('invalid Kline')
   v={'open':o,'high':h,'low':l,'close':c,'imbalance':2*t/q-1,'location':(c-l)/(h-l) if h>l else D('.5')}
   if stamp in bars and bars[stamp]!=v:raise ValueError('conflicting Kline')
   bars[stamp]=v
led=j['opportunity_ledger'];decisions=[e for e in led if e['event']=='decision']
# One original first decision per session. No outcome-dependent choice of cycle.
decs=[next((e for e in decisions if sess['start_ms']<=e['at_ms']<sess['start_ms']+300000),None) for sess in j['sessions']]
absorption=[];considered=[];through=-1
for e in decs:
 if e is None or D(e['quantity_before'])!=0:continue
 day=(e['at_ms']-60000)//DAY*DAY-DAY
 if day not in bars or day+7*DAY not in bars:continue
 b=bars[day];selected=b['imbalance']<=D('-.1') and b['close']>=b['open'] and b['location']>=D('.75')
 ref=D(e['decision_mark']);gross=bars[day+7*DAY]['close']/ref-1
 rec={'at_ms':e['at_ms'],'completed_day_ms':day,'feature_available_ms':day+DAY+60000,'initial_action':e['action'],'incumbent_opportunity':e['opportunity'],'imbalance':b['imbalance'],'close_location':b['location'],'daily_return':b['close']/b['open']-1,'selected':selected,'reference_mark':ref,'proxy_end_ms':day+8*DAY,'gross_price_return':gross,'base_price_minus_cost_proxy':gross-D('.0037'),'stress_price_minus_cost_proxy':gross-D('.0074')}
 considered.append(rec)
 if selected and e['at_ms']>through:absorption.append(rec);through=rec['proxy_end_ms']
# Actual campaign baskets are previously diagnosed; use causal first enter decision, not later fill date.
dpath=OUT/'diagnostic.json';d=json.loads(dpath.read_text());sources.append({'path':str(dpath),'sha256':hashlib.sha256(dpath.read_bytes()).hexdigest()})
entrydecs=[e for e in decisions if e['action']=='enter'];entrytimes=[e['at_ms'] for e in entrydecs]
exhaustion=[];exall=[]
for campaign in d['baskets']:
 stamp=campaign['first_sizing']['at_ms'];e=entrydecs[bisect.bisect_right(entrytimes,stamp)-1]
 if e['opportunity']!=campaign['campaign']:raise ValueError('causal entry owner differs')
 day=(e['at_ms']-60000)//DAY*DAY-DAY
 if day not in bars:continue
 b=bars[day];selected=b['imbalance']>=D('.1') and b['close']<=b['open'] and b['location']<=D('.25')
 rec={'campaign':campaign['campaign'],'at_ms':e['at_ms'],'completed_day_ms':day,'feature_available_ms':day+DAY+60000,'imbalance':b['imbalance'],'close_location':b['location'],'daily_return':b['close']/b['open']-1,'selected':selected,'net_actual_income_usdt':D(campaign['net']),'buy_notional_usdt':D(campaign['buy_notional']),'avoided_actual_income_usdt':-D(campaign['net'])}
 exall.append(rec)
 if selected:exhaustion.append(rec)
def halves(rows):
 n=len(rows)//2;return[rows[:n],rows[n:]]
a_parts=halves(absorption);e_parts=halves(exall)
a_gates={'independent10':len(absorption)>=10,'half3':all(len(h)>=3 for h in a_parts),'positive_base_both':all(h and sum(r['base_price_minus_cost_proxy'] for r in h)>0 for h in a_parts),'positive_stress_both':all(h and sum(r['stress_price_minus_cost_proxy'] for r in h)>0 for h in a_parts)}
e_effect=[sum((r['avoided_actual_income_usdt'] for r in h if r['selected']),D(0)) for h in e_parts];e_uniform=[-D('.25')*sum((r['net_actual_income_usdt'] for r in h),D(0)) for h in e_parts]
e_gates={'independent10':len(exhaustion)>=10,'half3':all(sum(r['selected'] for r in h)>=3 for h in e_parts),'positive_avoided_both':all(x>0 for x in e_effect),'beats_uniform25_both':all(x>y for x,y in zip(e_effect,e_uniform))}
result={'format':'coin-price-flow-response-screen-v1','spec_sha256':sources[0]['sha256'],'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_bindings':sources,'compressed_Kline_bytes_read':compressed,'absorption':{'status':'SUPPORT_PENDING' if not(a_gates['independent10'] and a_gates['half3']) else 'REJECT_PRICE_SCREEN' if not all(a_gates.values()) else 'GROSS_SCREEN_PASS_NEEDS_CONTROLS','gates':a_gates,'independent_events':len(absorption),'eligible_first_session_decisions':len(considered),'mean_base_price_proxy':sum((r['base_price_minus_cost_proxy'] for r in absorption),D(0))/len(absorption) if absorption else None,'rows':absorption,'all_rows':considered},'exhaustion':{'status':'SUPPORT_PENDING' if not(e_gates['independent10'] and e_gates['half3']) else 'REJECT_CASH_ATTRIBUTION' if not all(e_gates.values()) else 'CASH_SCREEN_PASS_NEEDS_CONTROLS','gates':e_gates,'independent_events':len(exhaustion),'eligible_campaigns':len(exall),'avoided_cash_by_halves':e_effect,'uniform25_cash_by_halves':e_uniform,'rows':exhaustion,'all_rows':exall},'elapsed_seconds':time.perf_counter()-started,'new_replayed_sessions':0,'new_accounts':0,'network_requests':0,'adopted':False,'limitations':['Price proxy lacks futures funding, fills, native protection and wallet constraints.','No candidate performance or CAGR inference; no account entrant.','Historical paths have been repeatedly used and remain development data.','No thresholds loosened, grid fit, or loss rows removed.']}
(OUT/'price-flow-screen.json').write_text(json.dumps(result,default=str,indent=2)+'\n')
print(json.dumps({k:{q:v for q,v in x.items() if 'rows' not in q} if k in ['absorption','exhaustion'] else x for k,x in result.items() if k!='source_bindings'},default=str,indent=2))
