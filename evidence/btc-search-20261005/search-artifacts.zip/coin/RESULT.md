# Coinquant saved-account opportunity search — 2026-10-05

No runtime files, defaults, account states or existing evidence were changed. New output lives only in this directory. No tests, account sessions, 795 replay, network requests or large-vault reads. The source is the saved, accepted incumbent/base account projection (876,880 compressed bytes), bound to producer `37061a7f588f97cc16852551cab6cd2e51acb920` / Python `ba63895131db566e708a5c96cde4504beace39fa0bdd54881d039dd5b8ef4c50`; its full parent identity and compressed SHA are in diagnostic.json.

## Useful diagnosis already performed

Actual fills define 50 nonoverlapping, closed campaigns. Attribution of each campaign's actual realized PNL, commission and funding exactly sums to the saved income ledger; this is existing cash attribution and not a changed account or CAGR.

| Source | Campaigns | Positive / negative | Gross realized USDT | Fees USDT | Funding USDT | Actual net income USDT |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Primary SX60 | 30 | 21 / 9 | 327,666.32 | −14,191.14 | −20,118.71 | 293,356.48 |
| Macro DFII10 | 20 | 9 / 11 | −375.03 | −1,099.40 | −1,614.45 | −3,088.88 |

The macro leg's negative cash attribution does **not** establish that removing it increases final wealth by that amount. `evidence/complete-delivery-20261001/RESULT.md` already contains the complete no-macro account: base CAGR 120.7362% versus incumbent 119.2284%, MDD 44.2542% versus 44.1051%, and trigger-slip matching failed. Thus simply remove-macro is an already tested small improvement with an adverse risk/stress tradeoff, not a new route and not eligible for a repeated full replay.

No gross-positive campaign became net-negative after actual costs and funding. Funding drains 21,733.16 USDT, but these historical losers are not explained solely by fees erasing small positive direction forecasts. This weakens an undifferentiated "just reduce funding" repair argument; the prior cost-horizon failure remains binding.

Exit causes are 36 MARKET, 12 STOP_MARKET and 2 TAKE_PROFIT_MARKET. These are observed event counts, not hypothetical ideal exits. First IOC filled less than 25% in 17 campaigns, but after actual same-session adds only 2 remained below 25% of the original first requested amount. There are 19 campaigns with at least one stop_budget add constraint; repeated constraint polls cannot be counted as independent lost trades or repaired profits. These aggregate diagnostics do not prove changing topup improves anything; old single-topup/quality/fresh-entry failures are retained.

The 12 zero-fill BUY IOC orders comprise **3 initial attempts and 9 add attempts**. All 3 zero-fill initial attempts later opened the same recorded opportunity under the existing rules. Thus there is no evidence here that zero fills prematurely consumed and permanently lost 12 campaigns. `zero-fill-classification.json` binds the observed quantity at each write. No speculative IOC retry fix is justified by that count.

## Two distinct, fixed hypotheses actually screened

The spec was saved before the new screen. This is one price-versus-flow information family with two expressions, **not** a threshold search. Existing ratio-only flow disagreement, quality-budget, price-only pullback and shock tests do not test this precise opposite-signed flow/price relationship. The qualified-OI forced-liquidation absorption route remains separately pending and is not relabelled as complete here.

1. **Seller absorption as a new opportunity.** A completed spot UTC day has aggressive sell imbalance ≤−10%, yet price closes up and in the upper quarter of its range. Use the first original manual session decision while the incumbent account is flat, then retain nonoverlapping fixed completed-day outcomes. This tests whether price resilience against aggressive selling reveals passive demand that simple flow ratio or price momentum misses.
2. **Buyer exhaustion as an entry veto.** A completed spot UTC day has aggressive buy imbalance ≥+10%, yet closes down and in its lower quarter. Inspect only the first true entry of each actual campaign, and attribute its actual settled income. This tests whether aggressive demand failing to advance price helps avoid losing entries.

| Expression | Eligible records | Independent affected events | Result |
| --- | ---: | ---: | --- |
| Seller absorption | 703 first session observations while flat, with causal feature and mature endpoint | 2 | SUPPORT_PENDING; both outcomes negative; mean price minus base cost proxy −8.8094% |
| Buyer exhaustion veto | 50 actual initial campaign entries | 0 | SUPPORT_PENDING; no action, no attributable avoided income |

The absorption proxy outcomes were −13.3283% and −4.2905% after 0.37% base roundtrip cost proxy; doubled-cost proxy was negative in both. Both rows remain in price-flow-screen.json. Only 2 observations cannot prove a general negative edge, but they provide no economic basis to write an account execution adapter or relax thresholds. No incremental regression was fitted after this sparse and unfavorable outcome. Buy exhaustion has no actual support; zero events cannot be described as an effective beta filter.

The endpoint is the close of the completed-day bar seven days after the feature day, as frozen before results, rather than an exactly seven-day executable holding period. Futures funding, fills, margin, native stop paths and reinvestment are absent. Spot endpoint versus recorded perpetual mark also has cross-market basis. These price proxies do not establish candidate profits, independent account returns, CAGR or alpha. All historical input remains repeatedly used development data.

Only 204,552 bytes of small monthly spot ZIPs already bound by the accepted prior input manifest were read for these screens. Each source matched that existing recorded SHA; no big trade/mark archive was read. The first screen exited on a missing descriptive action field in an original blocked decision record; no result was accepted. The original failed producer and failure receipt are preserved. Repair kept the same first observed decision and null descriptive action, with no change in signal, feature time, selection or outcome. The recovered fixed screen completed in 0.858 seconds. The prior account diagnosis completed in approximately 0.84 seconds; these are analysis runs, not account measurements or software tests.

Decision: **zero account entrants, no default changes**. This search has narrowed two new cheap hypotheses and refuted the misleading "12 zero fills = 12 missed campaigns" interpretation. It has not proven an improvement, a return ceiling or a strategy defect. Reopen these fixed price-flow hypotheses only with genuinely new supported events; do not tune them on these two losing rows. Better information beyond this weak candle proxy remains the necessary next route, especially qualified intraday OI/liquidation/spot response and actual executable cross-market data described in replacement-spec.json.
