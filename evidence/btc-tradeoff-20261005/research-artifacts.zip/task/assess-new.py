"""Actual independent-wallet tradeoffs and fixed joint daily diagnostics."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,'/workspace/spotquant')
from research.tradeoff_assessment import DAY, assess_comparison, wallet_view, wallet_metrics

ROOT=Path(__file__).parent
OLD=Path('/workspace/btc-search-next-20261005')
OUT=ROOT/'assessment-new-wallets.json'
if OUT.exists():raise ValueError('preserve prior assessment')
receipts=[]
def read(path, expected=None):
    raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
    if expected and sha!=expected:raise ValueError('accepted bytes changed '+str(path))
    receipts.append(dict(path=str(path),sha256=sha,bytes=len(raw)))
    return json.loads(raw),sha
spec,_=read(ROOT/'spec.json','a7323d6722940c9db62857ce9d9fd5ce1191ab1f03cd81812f332f394b71d929')
packet,_=read(Path(spec['daily_packet']),spec['daily_sha256'])
reused,_=read(ROOT/'assessment-reused-six-wallets.json')
binding=reused['benchmark']['source']
older,_=read(Path(binding['path']),binding['sha256'])
for t,row in older['bars'].items():
    if t not in packet['bars'] or any(row[k]!=packet['bars'][t][k] for k in ['open','high','low','close']):
        raise ValueError('old price subset changed')
benchmark={int(t)+DAY:float(row['close']) for t,row in packet['bars'].items()}
baseline0,_=read(OLD/'accounts/2020-04-01-baseline.json')
identity=baseline0['identity']
command=['python3.13','-c','import json;from research.session_market import load_base;print(json.dumps(load_base("/tmp/coinquant-market").identity))']
current_market=json.loads(subprocess.check_output(command,cwd='/workspace/coinquant',text=True))
if current_market!=identity['base_market_identity']:raise ValueError('market/funding changed')
changed=subprocess.check_output(['git','diff','--name-only',identity['source']['git_head'],'HEAD','--',
    'coinquant','research/session_market.py','research/complete_perp.py','research/unified_perp.py','research/rebuild.py'],
    cwd='/workspace/coinquant',text=True)
if changed.strip():raise ValueError('incumbent economic dependency changed')
accepted_old={r['path']:r['sha256'] for r in reused['receipts'] if '/accounts' in r['path'] and '-baseline.json' in r['path'] or '/accounts-macro-only/' in r['path'] and '-macro-fragmented' in r['path']}
wallets={};views={};loaded={};new_paths=[]
def conditions(kind,row):
    return dict(market='Binance BTCUSDT '+('USDT-margined perpetual' if kind=='coin' else 'spot'),
        valuation_currency='USDT',reporting_currency='CNY',
        initial_state=dict(kind='cold_cash',cash_usdt=row['initial_usdt'],btc='0',pending_intents=[]),
        market_data=dict(comparison_daily_subset=binding['sha256'],extended_daily=spec['daily_sha256'],
                         base_market=hashlib.sha256(json.dumps(current_market,sort_keys=True).encode()).hexdigest() if kind=='coin' else None),
        fx=identity['fx_sha256'],cost_model=dict(fee_rate='.00075' if kind=='coin' else '.001',fx_each_way='.999',
            funding='original frozen historical settlements' if kind=='coin' else 'none'),
        execution_model=dict(matcher='trade_print' if kind=='coin' else 'OHLC',read_ms=200,write_ms=1000,mark_gap='bound' if kind=='coin' else None),
        clock=dict(schedule_sha256=identity['schedule_sha256'],terminal=row['window'][1],timezone='UTC'))
def add(kind,begin,policy,path,old=False):
    row,sha=read(path,accepted_old.get(str(path)) if old else None)
    if any('risk identity' in str(e) or 'incompatible' in str(e) or 'history must start' in str(e)
           for s in row['sessions'] for e in s.get('errors',[])):
        raise ValueError('invalid strategy integration '+str(path))
    cond=conditions(kind,row)
    assert row['identity']['fx_sha256']==cond['fx']
    assert row['identity']['schedule_sha256']==cond['clock']['schedule_sha256']
    if not old:
        assert row['identity']['price_sha256']==spec['daily_sha256']
        assert row['identity']['features_sha256']==spec['features_sha256']
        new_paths.append(str(path))
    if kind=='coin':
        for field in ['loaded_minute_files','loaded_print_files']:
            for name,digest in row[field].items():
                key=field,name
                if key in loaded and loaded[key]!=digest:raise ValueError('conflicting touched source')
                loaded[key]=digest
    view=wallet_view(row,kind=kind,source=dict(path=str(path),sha256=sha,accepted=True),conditions=cond,
                     original_gate={'status':'original frozen negative result retained'} if old and policy=='macro' else None)
    # Descriptions differ; dependency equality above binds the exact same venue.
    if kind=='coin':view['price_model']='official minute mark / original print matcher / retained envelope bounds'
    key=kind,begin,policy;wallets[key]=row;views[key]=view
for begin,end in spec['windows']:
    add('coin',begin,'baseline',OLD/'accounts'/(begin+'-baseline.json'),True)
    add('coin',begin,'macro',OLD/'accounts-macro-only'/(begin+'-macro-fragmented-upday-new-entry-veto.json'),True)
    add('coin',begin,'uniform75',ROOT/('coin-recovery' if begin=='2020-04-01' else 'coin-recovery2')/(begin+'-uniform75.json'))
    add('coin',begin,'channel',ROOT/'coin-recovery2'/(begin+'-channel.json'))
    add('coin',begin,'channel-short',ROOT/'coin-short'/(begin+'-channel-short.json'))
    add('spot',begin,'baseline',ROOT/('spot-recovery' if begin=='2020-04-01' else 'spot-accounts')/(begin+'-baseline.json'))
    for policy in ['defensive-base','tactical','constant25']:
        add('spot',begin,policy,ROOT/'spot-recovery2'/(begin+'-'+policy+'.json'))
comparisons=[]
for kind in ['coin','spot']:
    for begin,end in spec['windows']:
        for policy in (['macro','channel','channel-short'] if kind=='coin' else ['defensive-base','tactical']):
            report=assess_comparison(views[kind,begin,'baseline'],views[kind,begin,policy],benchmark,
                purpose='Distinct risk/entry core versus incumbent and simple independently financed control.',
                accepted_costs='Lower return can be accepted for clearly greater overall downside/recovery/cost benefit; no winner counting.',
                risk_control=views[kind,begin,'uniform75' if kind=='coin' else 'constant25'])
            report.update(kind=kind,policy=policy,window=[begin,end]);comparisons.append(report)
joint=[]
pairs=[('baseline','baseline'),('macro','baseline'),('uniform75','baseline'),('channel','baseline'),
       ('channel-short','baseline'),('baseline','defensive-base'),('baseline','tactical')]
for begin,end in spec['windows']:
    for coin,spot in pairs:
        left,right=views['coin',begin,coin],views['spot',begin,spot]
        assert left['daily'].keys()==right['daily'].keys()
        view=dict(left,initial_cny='20000',initial_usdt=str(float(left['initial_usdt'])+float(right['initial_usdt'])),
            daily={t:{c:left['daily'][t][c]+right['daily'][t][c] for c in ['CNY','USDT']} for t in left['daily']},
            final_cny=left['final_cny']+right['final_cny'],return_cny=(left['final_cny']+right['final_cny'])/20000-1,
            mdd_path_proxy=None,fees_usdt=left['fees_usdt']+right['fees_usdt'],
            funding_paid_usdt=left['funding_paid_usdt']+right['funding_paid_usdt'],fill_count=left['fill_count']+right['fill_count'])
        metric=wallet_metrics(view,benchmark)
        joint.append(dict(window=[begin,end],coin=coin,spot=spot,actual_capital_cny=20000,
            sources=[left['source'],right['source']],metrics=metric,scaled_curves=False,transfers=0,
            limitation='Actual independently financed daily sums only; joint continuous/native risk is unknown. No allocation search.'))
result=dict(comparisons=comparisons,joint=joint,receipts=receipts,new_wallets=len(new_paths),
    accepted_new_sessions=sum(row['session_count'] for key,row in wallets.items() if views[key]['source']['path'] in new_paths),
    new795=0,old_wallets_reused=4,bridge=dict(old_daily_subset_equal=True,coin_economic_source_equal=True,
        full_base_market_identity_equal=True,touched_digest_conflicts=0,raw_producer_identities_retained=True),
    adopted=False,source_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with OUT.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
for c in comparisons:
    print(json.dumps({'kind':c['kind'],'policy':c['policy'],'window':c['window'],
        'metrics':{k:{m:v[m] for m in ['return_cny','mdd_path_proxy','daily_es5_loss_usdt','beta_up_days','beta_down_days','longest_underwater_days_observed_usdt']}
                   for k,v in c['metrics'].items()}}))
