"""One qualification recovery: fresh selection, then actual paired greeks."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,'/workspace/spotquant')
from research.persistent_data import finite_request, option_candidates
ROOT=Path(__file__).parent
OUT=ROOT/'public-selection-recovery'
OUT.mkdir(exist_ok=False)
original=json.loads((ROOT/'public/receipts.json').read_text())
plan=dict(original_receipts_sha256=hashlib.sha256((ROOT/'public/receipts.json').read_bytes()).hexdigest(),
    reason='Original put actual delta -0.19857 is outside frozen .20-.30 magnitude; retain BLOCK, use fresh summary once to select near25delta. New call is required for a fresh paired observation.',
    max_added_requests=3,max_total_requests=12,max_total_bytes=3000000,thresholds_unchanged=True)
(OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
receipt=finite_request('option-summary','https://www.deribit.com/api/v2/public/get_book_summary_by_currency?currency=BTC&kind=option',OUT)
records=[receipt]
if receipt['status']==200 and receipt.get('raw_file'):
    packet=json.loads((OUT/receipt['raw_file']).read_bytes())
    candidates=[(term,side,name) for term,side,name in option_candidates(packet,receipt['receipt_ms']) if term==30]
    requests=[('option-30-'+side,'https://www.deribit.com/api/v2/public/ticker?instrument_name='+name)
              for term,side,name in candidates]
    with ThreadPoolExecutor(max_workers=2) as pool:records+=list(pool.map(lambda r:finite_request(*r,OUT),requests))
else:candidates=[]
result=dict(receipts=records,candidates=candidates,total_requests=original['requests']+len(records),
    total_bytes=original['bytes']+sum(r.get('bytes',0) for r in records),retries=0,orders=0,
    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
assert result['total_requests']<=12 and result['total_bytes']<=3000000
(OUT/'receipts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'total_requests':result['total_requests'],'total_bytes':result['total_bytes'],'candidates':candidates,
                  'status':[(r['name'],r['status']) for r in records]}))
