"""Finite new inputs for unresolved BTC risk and USDT-dated-contract routes."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).parent
OUT = ROOT/'public'
OUT.mkdir(exist_ok=False)
records = []

def fetch(item):
    name, url, limit = item
    record = dict(name=name, url=url, request_ms=int(time.time()*1000), status=None,
                  historical_availability_proven=False)
    raw = None
    try:
        with urlopen(Request(url, headers={'User-Agent':'btc-personal-research/1.0'}), timeout=5) as response:
            record['status'] = response.status
            raw = response.read(limit+1)
        if len(raw) > limit:
            raw = None
            raise ValueError('registered response bound exceeded')
    except HTTPError as exc:
        raw = exc.read(min(limit,8192))
        record.update(status=exc.code,error='HTTPError')
    except Exception as exc:
        record.update(error=type(exc).__name__,detail=str(exc)[:200])
    record['receipt_ms'] = int(time.time()*1000)
    if raw is not None:
        filename = name+'.raw'
        with (OUT/filename).open('xb') as stream:stream.write(raw)
        record.update(raw_file=filename,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    return record

old = Path('/workspace/btc-persistent-20261004/artifacts/public')
prior = json.loads((old/'receipts.json').read_text())['receipts']
requests = []
selection = []
for side in ['C','P']:
    ref = next(r for r in prior if r['name']=='option-30-'+side)
    raw = (old/ref['raw_file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ref['sha256']
    name = json.loads(raw)['result']['instrument_name']
    selection.append(dict(instrument=name,source_sha256=ref['sha256'],purpose='selection only; new actual greeks must qualify'))
    requests.append(('option-30-'+side,'https://www.deribit.com/api/v2/public/ticker?'+urlencode({'instrument_name':name}),50000))
requests += [
    ('btc-usdt-rv','https://api.kraken.com/0/public/OHLC?pair=XBTUSDT&interval=1440',300000),
    ('usdt-dated-instruments','https://www.okx.com/api/v5/public/instruments?instType=FUTURES&uly=BTC-USDT',500000),
]
plan = dict(spec_sha256=hashlib.sha256((ROOT/'spec.json').read_bytes()).hexdigest(),
    question='Can fresh actual near25-delta IV pair have causal BTCUSDT RMS, and is a dated USDT-linear executable pair available on an alternative venue?',
    requests=requests,selection=selection,max_requests=12,max_bytes=3000000,
    no_retry_for_prior_451=True,cross_venue_stream_reused=True,orders=0,accounts=0)
with (OUT/'plan.json').open('x') as stream:json.dump(plan,stream,indent=2);stream.write('\n')
with ThreadPoolExecutor(max_workers=4) as pool:records += list(pool.map(fetch,requests))
instrument = next(r for r in records if r['name']=='usdt-dated-instruments')
eligible = []
if instrument['status']==200 and instrument.get('raw_file'):
    packet=json.loads((OUT/instrument['raw_file']).read_bytes())
    for row in packet.get('data',[]):
        if (row.get('uly')=='BTC-USDT' and row.get('ctType')=='linear' and row.get('settleCcy')=='USDT'
                and row.get('state')=='live' and int(row.get('expTime','0'))>int(time.time()*1000)):
            eligible.append(row)
if eligible:
    chosen=min(eligible,key=lambda r:int(r['expTime']))
    urls=[('spot-book','https://www.okx.com/api/v5/market/books?instId=BTC-USDT&sz=5',50000),
          ('dated-book','https://www.okx.com/api/v5/market/books?'+urlencode({'instId':chosen['instId'],'sz':5}),50000)]
    with ThreadPoolExecutor(max_workers=2) as pool:records += list(pool.map(fetch,urls))
else:chosen=None
assert len(records)<=12 and sum(r.get('bytes',0) for r in records)<=3000000
result=dict(receipts=records,eligible_instruments=eligible,selected_contract=chosen,
    requests=len(records),bytes=sum(r.get('bytes',0) for r in records),retries=0,orders=0,accounts=0,
    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with (OUT/'receipts.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'requests':result['requests'],'bytes':result['bytes'],'eligible_contracts':len(eligible),
                  'status':[(r['name'],r['status']) for r in records]}))
