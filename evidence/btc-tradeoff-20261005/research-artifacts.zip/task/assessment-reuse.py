"""Reconsider six accepted wallets; read small outputs only, no economic replay."""
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, '/workspace/spotquant')
from research.tradeoff_assessment import DAY, assess_comparison, wallet_view

OLD = Path('/workspace/btc-search-next-20261005')
OUT = Path(__file__).parent / 'assessment-reused-six-wallets.json'
if OUT.exists():
    raise ValueError('preserve original reconsideration output')
receipts = []


def read(path, expected=None):
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if expected is not None and digest != expected:
        raise ValueError('accepted dependency changed: ' + str(path))
    receipts.append({'path': str(path), 'sha256': digest, 'bytes': len(raw)})
    return json.loads(raw)


gates = {family: read(OLD / folder / 'assessment.json') for family, folder in
         [('all-new', 'accounts'), ('macro-only', 'accounts-macro-only')]}
specs = {family: read(OLD / folder / 'spec.json', gates[family]['spec_sha256']) for family, folder in
         [('all-new', 'accounts'), ('macro-only', 'accounts-macro-only')]}
daily_binding = next(r for r in specs['all-new']['inputs'] if r['path'].endswith('/daily-composition.json'))
bars = read(Path(daily_binding['path']), daily_binding['sha256'])['bars']
benchmark = {int(t) + DAY: float(bar['close']) for t, bar in bars.items()}
accepted = {}
for gate in gates.values():
    if gate['complete_comparable'] is not True:
        raise ValueError('reuse requires already accepted comparable accounts')
    for ref in gate['raw_sources']:
        if ref['path'] in accepted and accepted[ref['path']] != ref['sha256']:
            raise ValueError('inconsistent accepted source')
        accepted[ref['path']] = ref['sha256']
rows = {path: read(Path(path), digest) for path, digest in accepted.items()}


def view(path, family):
    row = rows[str(path)]
    identity = row['identity']
    conditions = {
        'market': 'Binance BTCUSDT USDT-margined perpetual',
        'valuation_currency': 'USDT', 'reporting_currency': 'CNY',
        'initial_state': {'kind': 'cold_cash', 'cash_usdt': row['initial_usdt'], 'btc': '0', 'pending_intents': []},
        'market_data': {'base_market_identity_sha256': hashlib.sha256(json.dumps(
            identity['base_market_identity'], sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'daily_composition_sha256': identity['daily_composition_sha256']},
        'fx': identity['fx_sha256'],
        'cost_model': {'fee_rate': identity['original_fee'], 'fx_conversion_factor_each_way': '.999',
                       'funding': 'original frozen market historical settlements'},
        'execution_model': {key: identity[key] for key in ('matcher', 'read_latency_ms', 'write_latency_ms', 'mark_gap')},
        'clock': {'schedule_sha256': identity['schedule_sha256'], 'terminal': row['window'][1], 'timezone': 'UTC'},
    }
    gate = gates[family]
    original = {'status': gate['status'], 'return_route': gate['return_route'], 'risk_route': gate['risk_route'],
                'result': next(r for r in gate['results'] if r['window'] == row['window'])}
    return wallet_view(row, kind='coin', source={'path': str(path), 'sha256': accepted[str(path)], 'accepted': True},
                       conditions=conditions, original_gate=original)


comparisons = []
for begin in ('2020-04-01', '2023-10-01'):
    baseline = OLD / 'accounts' / (begin + '-baseline.json')
    for family, folder, policy in [('all-new', 'accounts', 'fragmented-upday-new-entry-veto'),
                                   ('macro-only', 'accounts-macro-only', 'macro-fragmented-upday-new-entry-veto')]:
        path = OLD / folder / (begin + '-' + policy + '.json')
        if begin == '2023-10-01' and family == 'all-new':
            path = path.parent / 'recovery' / path.name
        report = assess_comparison(view(baseline, family), view(path, family), benchmark,
            purpose='Reconsider fragmentation veto for lower downside/tail exposure using original selected quarters.',
            accepted_costs='A lower return may be acceptable if material risk/recovery benefits clearly outweigh it; '
                           'no post-result fitted utility weights, gate relabelling, or automatic segment-loss rejection.')
        report.update(family=family, window=rows[str(path)]['window'],
                      treatment_count=len(rows[str(path)]['independent_vetoed_opportunities']))
        comparisons.append(report)
result = {
    'assessment_type': 'post_result_user_authorized_benefit_harm_reconsideration',
    'accepted_wallets_reused': len(rows), 'new_wallets': 0, 'new_sessions': 0, 'new795': 0,
    'comparisons': comparisons, 'receipts': receipts,
    'original_producers': {path: {k: value for k, value in row['identity'].items()
                                if k in ('source', 'wrapper_sha256', 'specification_sha256', 'original_wrapper_sha256')}
                           for path, row in rows.items()},
    'benchmark': {'currency': 'BTCUSDT', 'timestamp': 'original spot day open + 86400000, completed close',
                  'source': daily_binding, 'usage': 'post-result descriptive regression only, never decision input'},
    'assessment_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'assessment_module_sha256': hashlib.sha256(Path('/workspace/spotquant/research/tradeoff_assessment.py').read_bytes()).hexdigest(),
    'decision': {'status': 'EXPLICIT_NET_BENEFIT_JUDGMENT_REQUIRED', 'adopted': False,
                 'original_phase_status_unchanged': 'REJECT_FIXED_EXPRESSION_FINITE_PHASE',
                 'remaining': 'Independent simple risk-budget control and execution-cost stress are missing; '
                              'selected quarters and thin treatments do not establish full default/net benefit.'},
}
OUT.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
for row in comparisons:
    print(json.dumps({'window': row['window'], 'family': row['family'],
                      'metrics': {k: {m: v[m] for m in ('return_cny', 'mdd_path_proxy', 'daily_es5_loss_usdt',
                        'daily_volatility_annual_usdt', 'longest_underwater_days_observed_usdt',
                        'beta_btc_usdt', 'beta_up_days', 'beta_down_days', 'fees_usdt', 'funding_paid_usdt')}
                                  for k, v in row['metrics'].items()},
                      'pareto': row['comparison']['pareto']['relation']}))
