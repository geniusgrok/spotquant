import json
from pathlib import Path
import subprocess
import sys

repo = sys.argv[1]
root = Path(__file__).parent
kind = repo.removesuffix('quant')
cases = ([('2023-10-01', 'uniform75'), ('2020-04-01', 'channel'), ('2023-10-01', 'channel')]
         if kind == 'coin' else [(begin, policy) for begin in ['2020-04-01','2023-10-01']
                                for policy in ['defensive-base','tactical','constant25']])
attempts = []
for begin, policy in cases:
    name = begin+'-'+policy
    out = root/(kind+'-recovery2')/(name+'.json')
    scratch = Path('/tmp/btc-tradeoff-20261005')/(kind+'-recovery2')/name
    command = ['python3.13','-m','research.tradeoff_accounts','--spec',str(root/'spec.json'),
               '--policy',policy,'--begin',begin,'--out',str(out),'--scratch',str(scratch)]
    done = subprocess.run(command,cwd='/workspace/'+repo)
    attempts.append(dict(case=name,returncode=done.returncode,out=str(out),scratch=str(scratch)))
    (root/(kind+'-recovery2-attempts.json')).write_text(json.dumps(attempts,indent=2)+'\n')
    if done.returncode or json.loads(out.read_text())['complete_finite'] is not True:
        sys.exit(1)
