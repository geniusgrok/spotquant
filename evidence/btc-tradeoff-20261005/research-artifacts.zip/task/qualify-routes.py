"""Qualify bounded original receipts; no acquisition, account or state writes."""
from datetime import datetime, timezone
from decimal import Decimal as D
import hashlib
import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,'/workspace/coinquant')
from research.tradeoff_routes import evaluate, DAY
ROOT=Path(__file__).parent
OUT=ROOT/'route-qualification.json'
if OUT.exists():raise ValueError('preserve original qualification')
bindings=[]
def load(path,expected=None):
    raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
    if expected and sha!=expected:raise ValueError('receipt binding changed')
    bindings.append(dict(path=str(path),sha256=sha,bytes=len(raw)))
    return json.loads(raw)
first=load(ROOT/'public/receipts.json')
second=load(ROOT/'public-selection-recovery/receipts.json')
rvref=next(r for r in first['receipts'] if r['name']=='btc-usdt-rv')
rvpacket=load(ROOT/'public'/rvref['raw_file'],rvref['sha256'])
if rvpacket['error'] or set(rvpacket['result'])!={'XBTUSDT','last'}:raise ValueError('BTCUSDT OHLC pair unavailable')

def option_context(receipts,folder):
    refs=[next(r for r in receipts if r['name']=='option-30-'+side) for side in ['C','P']]
    rows=[load(folder/r['raw_file'],r['sha256'])['result'] for r in refs]
    now=max([r['receipt_ms'] for r in refs]+[rvref['receipt_ms']])
    if rows[0]['instrument_name'].split('-')[1]!=rows[1]['instrument_name'].split('-')[1]:raise ValueError('expiry mismatch')
    stamps=[r['timestamp'] for r in rows]
    if any(not 0<=now-t<=60000 for t in stamps) or max(stamps)-min(stamps)>1000:
        raise ValueError('actual fresh paired option clocks required')
    bars=[r for r in rvpacket['result']['XBTUSDT'] if int(r[0])*1000+DAY<=now]
    selected=bars[-21:]
    if len(selected)!=21 or any(int(b[0])-int(a[0])!=86400 for a,b in zip(selected,selected[1:])):
        raise ValueError('twenty actual contiguous completed BTCUSDT returns required')
    if any(int(r[0])%86400 or not 0<D(r[3])<=min(D(r[1]),D(r[4]))<=max(D(r[1]),D(r[4]))<=D(r[2]) for r in selected):
        raise ValueError('invalid actual daily OHLC')
    closes=[D(r[4]) for r in selected]
    returns=[b/a-1 for a,b in zip(closes,closes[1:])]
    rms=(sum((r*r for r in returns),D(0))/20*365).sqrt()
    expiry=datetime.strptime(rows[0]['instrument_name'].split('-')[1],'%d%b%y').replace(hour=8,tzinfo=timezone.utc)
    context=dict(base='BTC',quote='USDT',end_ms=max(stamps),available_ms=now,
        source_sha256=[r['sha256'] for r in refs]+[rvref['sha256']],
        tenor_days=str((D(int(expiry.timestamp()*1000))-max(stamps))/DAY),
        call_delta=str(rows[0]['greeks']['delta']),put_delta=str(rows[1]['greeks']['delta']),
        call_iv=str(D(str(rows[0]['mark_iv']))/100),put_iv=str(D(str(rows[1]['mark_iv']))/100),
        realized_rms20_annual=str(rms),rv_completed_ms=int(selected[-1][0])*1000+DAY,rv_available_ms=rvref['receipt_ms'])
    return context,now

original,now1=option_context(first['receipts'],ROOT/'public')
recovered,now2=option_context(second['receipts'],ROOT/'public-selection-recovery')
stream_path=Path('/workspace/btc-search-next-20261005/stream/qualification.json')
stream=load(stream_path)
result=dict(
    original_packet=dict(decision_ms=now1,**{'option-risk':original}),
    original_verdict=evaluate(dict(decision_ms=now1,**{'option-risk':original})),
    recovered_packet=dict(decision_ms=now2,**{'option-risk':recovered}),
    recovered_verdict=evaluate(dict(decision_ms=now2,**{'option-risk':recovered})),
    cross_venue=dict(status='WAIT_COMPLETE_WINDOW_CONVERSION_AND_MATURITY',
        reused_original_status=stream['status'],complete_window=stream['fixed_window_completeness_proven'],
        conversion_qualified=stream['USDT_conversion_continuous_fresh_midquote_qualified'],
        mature_forward_outcomes=stream['mature_forward_outcomes'],new_capture=0,
        expressions=['independent-demand-entry','risk-budget-use']),
    absorption=dict(status='WAIT_MATCHED_OI_LIQUIDATION_AND_FLOW',
        original_451_preserved=True,retries=0,expressions=['event-entry','event-decay-exit']),
    expiry_basis=dict(status='WAIT_ELIGIBLE_USDT_LINEAR_DATED_CONTRACT',
        eligible_contracts=len(first['eligible_instruments']),raw_instrument_receipt=next(r for r in first['receipts'] if r['name']=='usdt-dated-instruments'),
        inverse_or_USDC_substitution=False,expressions=['executable-net-cost-screen']),
    maturity=dict(independent_bound_receipt_days=2,matured_nonoverlapping_option_outcomes=0,
        earliest_new_observation_7day_outcome_ms=now2+7*DAY,
        economic_or_tail_predictor_qualification=False,
        note='One added actual UTC receipt day is not seven days of outcomes or independent halves. Old observations remain source-bound.'),
    rv_meaning='Actual Kraken XBTUSDT (BTC/USDT alias) completed daily close RMS20; annual365, not USD-price conversion or executable option IV.',
    receipts=bindings,requests=second['total_requests'],raw_bytes=second['total_bytes'],
    original_negative_pair_retained=True,thresholds_unchanged=True,
    new_accounts=0,new_sessions=0,new795=0,orders=0,native_qualified=False,
    source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/coinquant',text=True).strip(),
    module_sha256=hashlib.sha256(Path('/workspace/coinquant/research/tradeoff_routes.py').read_bytes()).hexdigest(),
    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with OUT.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'original_option':result['original_verdict']['observations']['option-risk'],
    'recovered_option':result['recovered_verdict']['observations']['option-risk'],
    'causal_rms20_annual':recovered['realized_rms20_annual'],
    'maturity':result['maturity'],'requests':result['requests'],'bytes':result['raw_bytes']}))
