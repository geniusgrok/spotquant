"""Exactly one final full compile/test run per repository."""
import json
from pathlib import Path
import re
import subprocess
import sys
import time
repo=sys.argv[1]
root=Path('/workspace')/repo
out=Path(__file__).parent/'software'
out.mkdir(exist_ok=True)
result_path=out/(repo+'-result.json')
if result_path.exists():raise ValueError('reuse completed final software evidence')
git=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip()
if git('status','--porcelain'):raise ValueError('freeze final test source')
source=git('rev-parse','HEAD')
checks=[]
for name,command in [('compile',['python3.13','-m','compileall','-q',repo,'research','tests']),
                     ('unittest',['python3.13','-m','unittest','discover','-s','tests','-v'])]:
    log=out/(repo+'-'+name+'.log');began=time.monotonic()
    with log.open('x') as stream:done=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
    checks.append(dict(name=name,command=command,returncode=done.returncode,elapsed_seconds=time.monotonic()-began,log=str(log)))
    if done.returncode:break
result=dict(source_head=source,source_unchanged=git('rev-parse','HEAD')==source,checks=checks,
    passed=all(c['returncode']==0 for c in checks) and len(checks)==2,
    remote_ci_pass_claimed=False,full_suite_runs=1)
if checks[-1]['name']=='unittest':
    text=Path(checks[-1]['log']).read_text();match=re.search(r'Ran (\d+) tests in ([\d.]+)s',text)
    if match:result.update(test_count=int(match[1]),reported_test_seconds=float(match[2]))
    skip=re.search(r'OK \(skipped=(\d+)\)',text)
    result['skipped']=int(skip[1]) if skip else 0
with result_path.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] and result['source_unchanged'] else 1)
