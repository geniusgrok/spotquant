"""Read-only shared model evaluation. A preview never consumes an opportunity."""
from .campaign import Campaign
from .types import Blocked
from decimal import Decimal as D


def advance(state, venue):
    saved=state.get('linear_campaign')
    model=Campaign.restore(saved) if saved is not None else Campaign()
    if saved is None:state.set('market_bootstrap',True)
    bootstrap=bool(state.get('market_bootstrap'))
    def save_page(bars):
        for bar in bars:
            model.update(bar['time']+model.model.interval,bar['high'],bar['low'],bar['close'])
        state.set('linear_campaign',model.checkpoint())
    market=venue.completed_market(start=model.last,on_page=save_page)
    if market.get('interval_ms')!=model.model.interval:
        raise Blocked('missing complete model history')
    for bar in market['candles']:
        if bar['time']+model.model.interval>model.last:
            model.update(bar['time']+model.model.interval,bar['high'],bar['low'],bar['close'])
    if model.last!=market['complete_through']:
        raise Blocked('market and checkpoint boundaries differ')
    if bootstrap and not getattr(model, 'continuous_entry', False):
        # Price reconstruction cannot establish historical fill ownership, so a
        # cold start consumes a still-active impulse. The flag clears only when
        # the macro step of the same cold start has completed (session.cycle).
        model.consumed=model.primary_consumed=model.model.active.identity if model.model.active else None
    state.set('linear_campaign',model.checkpoint())
    return model,market,bootstrap


def preview(model,snapshot):
    quantity=D(snapshot['quantity_btc'])
    if not quantity.is_finite():raise Blocked('invalid native quantity')
    action=model.action(quantity)
    return dict(action=action,opportunity=model.active,
                protection_required=bool(quantity) and not (snapshot.get('native_full_position_protected') and snapshot.get('stop_before_liquidation')),
                consumed_campaign=(model.macro_consumed if model.macro_opportunity is not None and
                                   model.active is model.macro_opportunity
                                   else model.primary_consumed),position_campaign=model.position_campaign,
                target_fraction=str(model.entry_fraction('.0011')) if action=='enter' or action=='hold' and getattr(model,'continuous_entry',False) else None,
                quantity_btc=str(quantity) if action=='hold' else '0' if action in ('exit','flat','consumed') else None,
                quantity_status='native preflight required' if action=='enter' else 'shared inventory decision',
                model=getattr(model, 'core_rule', 'SX60+DFII10'),macro_observation=model.macro_observation,
                qualification='NOT_QUALIFIED')
