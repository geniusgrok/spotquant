"""Read-only attribution of accepted BTC accounts; never executes a producer.

CLI outputs a new directory containing attribution.json and attribution.md.
Price changes during cash periods describe opportunity, never earned profit.
"""
import argparse
from bisect import bisect_right
from collections import Counter, defaultdict
from decimal import Decimal as D
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

from spotquant.follow import _base_delta, _sell_applied, grouped_close_dust
from spotquant.preview import BASE_STEP

ROOT = Path(__file__).resolve().parents[1]
RETAINED = Path('/workspace/btc-alpha-beta-completed-evidence-20261002')
SLEEVES = (30, 40, 50)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path, expected=None):
    digest = sha(path)
    require(expected is None or digest == expected, 'input SHA mismatch: ' + str(path))
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result
    opener = gzip.open if Path(path).suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8') as stream:
        body = json.load(stream, object_pairs_hook=pairs,
                         parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    require(sha(path) == digest, 'input changed while reading: ' + str(path))
    return body, digest


def exit_kind(owner, link, sleeve):
    if owner is None:
        return 'unknown'
    if owner['order']['type'] == 'STOP_LOSS':
        return 'stop'
    if link is None:
        return 'unknown'
    value = link.get('exit_type')
    value = value.get(str(sleeve)) if isinstance(value, dict) else value
    if value is None:
        return 'unknown'
    return {'stop-through': 'stop', 'sma': 'sma', 'extended': 'extended', 'stop': 'stop'}.get(value, 'other')


def spot_attribution(account, rich):
    """Fold actual allocated net BTC; reuse runtime full-close dust predicates.

    Flat means no active tactical campaign, including proven retained dust.
    Exact account zero and dust quantities are reported separately.
    """
    owners = {}
    for row in account['allocations']:
        payload, result = json.loads(row[1]), json.loads(row[3])
        if 'orderId' in result:
            key = str(result['orderId'])
            require(key not in owners, 'duplicate Spot order allocation')
            owners[key] = dict(payload, native_status=result.get('status'),
                               native_executed_qty=result.get('executedQty'))
    links = {}
    for index, row in enumerate(rich.get('opportunity_ledger', [])):
        if row['event'] == 'fill':
            key = (row['id'], row['order_id'])
            require(key not in links, 'duplicate rich Spot fill')
            links[key] = (index, row)
    positions = {w: None for w in SLEEVES}
    last_exit = {w: None for w in SLEEVES}
    entered = set()
    unknown = set()
    fills = sorted(account['fills'], key=lambda f: (f['time'], f['id']))
    exits, flat_daily = [], []
    cursor = 0
    initial_ms = min((s['start_ms'] for s in account.get('sessions', [])), default=None)
    daily = sorted((r for r in account['daily'].values() if r['timestamp_ms'] != initial_ms),
                   key=lambda r: r['timestamp_ms'])
    for day in daily:
        # Spot raw daily timestamp is the actual end-of-day valuation boundary.
        while cursor < len(fills) and fills[cursor]['time'] <= day['timestamp_ms']:
            raw = fills[cursor]
            cursor += 1
            owner = owners.get(str(raw['order_id']))
            linked = links.get((raw['id'], raw['order_id']))
            link = linked[1] if linked else None
            if link is not None:
                require(all(raw[k] == link[k] for k in raw), 'rich fill differs from canonical fill')
            event = {'fill': raw, 'rich_ledger_index': linked[0] if linked else None,
                     'owner': owner, 'sleeves': []}
            if owner is None:
                unknown.update(SLEEVES)
                if not raw['buyer']:
                    event['classification'] = 'unknown'
                    exits.append(event)
                continue
            group = owner['sleeves']
            weights = {int(k): D(v) for k, v in owner['weights'].items()}
            require(set(group) <= set(SLEEVES) and set(weights) == set(group) and
                    all(v >= 0 for v in weights.values()) and sum(weights.values()) > 0,
                    'invalid Spot owner weights')
            trade = dict(raw, **{k: D(raw[k]) for k in ('qty', 'price', 'commission')})
            delta, given = abs(_base_delta(trade)), D(0)
            applied = None if raw['buyer'] else _sell_applied(positions, owner, str(raw['order_id']), trade['qty'])
            for i, w in enumerate(group):
                qty = delta - given if i == len(group) - 1 else delta * weights[w] / sum(weights.values())
                given += qty
                prior = positions[w]
                before = D(prior['qty']) if prior else D(0)
                if raw['buyer']:
                    entered.add(w)
                    positions[w] = dict(prior or {}, qty=str(before + qty), dust=False)
                    continue
                if prior is None or qty > before + BASE_STEP:
                    unknown.add(w)
                    event['sleeves'].append({'sleeve': w, 'classification': 'unknown', 'flat_after': None})
                    continue
                remaining = max(D(0), before - qty)
                flat = remaining < BASE_STEP or grouped_close_dust(owner, remaining, trade['price'], applied)
                counters = dict(prior.get('sell_applied', {}))
                counters[str(raw['order_id'])] = None if applied is None else str(applied)
                positions[w] = dict(qty=str(remaining), dust=flat, sell_applied=counters)
                kind = exit_kind(owner, link, w) if w not in unknown else 'unknown'
                detail = {'sleeve': w, 'classification': kind, 'quantity_before': str(before),
                          'net_btc_sold': str(qty), 'retained_btc': str(remaining), 'flat_after': flat}
                event['sleeves'].append(detail)
                if flat:
                    last_exit[w] = {'fill_id': raw['id'], 'order_id': raw['order_id'],
                                    'time': raw['time'], 'classification': kind}
            if not raw['buyer']:
                exits.append(event)
        for w in SLEEVES:
            position = positions[w]
            if w not in unknown and position and not position.get('dust'):
                continue
            kind = 'unknown' if w in unknown else (last_exit[w]['classification'] if last_exit[w] else
                                                   'never-entered' if w not in entered else 'unknown')
            flat_daily.append({'timestamp_ms': day['timestamp_ms'], 'sleeve': w, 'classification': kind,
                               'last_actual_exit': last_exit[w], 'retained_owned_btc': (position or {}).get('qty', '0'),
                               'account_btc': day['btc'], 'account_exactly_zero': D(day['btc']) == 0,
                               'price_usdt': day['price_usdt']})
    require(cursor == len(fills), 'Spot fills beyond last daily valuation')
    # Consolidate contiguous daily intervals only; unknown observations stay unknown.
    intervals = []
    for w in SLEEVES:
        for row in [r for r in flat_daily if r['sleeve'] == w]:
            previous = intervals[-1] if intervals else None
            if (previous and previous['sleeve'] == w and previous['classification'] == row['classification'] and
                    previous['last_actual_exit'] == row['last_actual_exit'] and
                    row['timestamp_ms'] - previous['last_timestamp_ms'] == 86400000):
                previous['last_timestamp_ms'] = row['timestamp_ms']
                previous['last_price_usdt'] = row['price_usdt']
                previous['observations'] += 1
            else:
                intervals.append({'sleeve': w, 'classification': row['classification'],
                                  'last_actual_exit': row['last_actual_exit'], 'first_timestamp_ms': row['timestamp_ms'],
                                  'last_timestamp_ms': row['timestamp_ms'], 'first_price_usdt': row['price_usdt'],
                                  'last_price_usdt': row['price_usdt'], 'observations': 1})
    for interval in intervals:
        interval['price_change_diagnostic'] = str(D(interval['last_price_usdt']) / D(interval['first_price_usdt']) - 1)
        interval['realizable_profit'] = None
    return {'actual_sell_fills': exits, 'flat_daily': flat_daily, 'flat_intervals': intervals,
            'unresolved_sell_fills': sum(e.get('classification') == 'unknown' or
                any(s['classification'] == 'unknown' for s in e['sleeves']) for e in exits),
            'exit_sleeve_counts': dict(Counter(x['classification'] for e in exits for x in e['sleeves'])),
            'flat_sleeve_day_counts': dict(Counter(x['classification'] for x in flat_daily)),
            'limitations': ['Flat is a closed tactical campaign; retained owned dust is not exact account zero.',
                            'Daily endpoints do not prove uninterrupted intraday flatness.',
                            'The initialization valuation is excluded from elapsed daily endpoint counts.',
                            'Future endpoint price changes are opportunity diagnostics, never earned or realizable profit.',
                            'Missing ownership poisons affected sleeve attribution; missing exit reasons remain unknown.']}


def coin_events(account):
    """Use actual opportunity identity; fills inherit only an explicit client link."""
    ledger = account.get('opportunity_ledger', [])
    writes = {}
    for row in ledger:
        if row['event'] == 'write_attempt' and row.get('opportunity') is not None:
            key = row['identity']
            require(key not in writes or writes[key] == row['opportunity'], 'conflicting Coin client opportunity')
            writes[key] = row['opportunity']
    groups, unknown = defaultdict(list), []
    for index, row in enumerate(ledger):
        if row['event'] == 'opportunity':
            opportunity = row.get('identity')
        else:
            opportunity = row.get('opportunity')
            if row['event'] == 'fill':
                opportunity = writes.get(row.get('client_order_id'))
        wrapped = {'ledger_index': index, 'raw': row}
        if opportunity is None:
            unknown.append(wrapped)
        else:
            groups[str(opportunity)].append(wrapped)
    for rows in groups.values():
        rows.sort(key=lambda r: (r['raw'].get('at_ms', -1), r['ledger_index']))
    return groups, unknown


def differences(left, right, prefix=''):
    """Exact raw differences, including numeric representations and timestamps."""
    if isinstance(left, dict) and isinstance(right, dict):
        result = {}
        for key in sorted(left.keys() | right.keys()):
            path = prefix + key
            if key not in left or key not in right:
                result[path] = {'left_present': key in left, 'right_present': key in right,
                                'left': left.get(key), 'right': right.get(key)}
            else:
                result.update(differences(left[key], right[key], path + '.'))
        return result
    return {} if type(left) is type(right) and left == right else {prefix.rstrip('.'): {'left': left, 'right': right}}


TIMING_IDENTITIES = {'at_ms', 'age_ms', 'created_at_ms', 'identity', 'opportunity', 'trigger.identity',
                     'client_order_id', 'payload.newClientOrderId',
                     'trade.time', 'trade.orderId', 'trade.id'}
EVENT_OUTCOMES = {
    'decision': {
        'action': 'original_decide returns its action',
        'reason': 'original_decide returns or raises a RECOVERABLE exception',
        'quantity_after': 'original_decide returns its resulting snapshot',
        'constraint': 'original_decide returns; engine.entry_constraint summarizes later entry sizing',
        'error': 'original_decide raises a RECOVERABLE exception',
    },
    'opportunity': {'post_run_diagnostic_closes': 'the historical run completes'},
}


def divergence_category(event, fields):
    if '' in fields:
        return 'event_availability_unknown'
    if fields & {'exit_type'}:
        return 'exit'
    if event == 'topup_sizing':
        return 'top_up'
    if fields & {'decision_mark', 'entry_estimate', 'bar_ms', 'trigger', 'trade.price', 'payload.price'}:
        return 'different_observations'
    if event == 'entry_sizing':
        if fields <= {'accepted_btc'}:
            return 'rounding'
        return 'sizing'
    if fields & {'wallet_usdt', 'idle_cash_usdt', 'sizing_capital_usdt', 'quantity_before'}:
        return 'prior_account_state'
    if event == 'fill':
        return 'exit' if 'exit_type' in fields else 'fill_execution'
    if event == 'cycle_blocked':
        return 'timeout_or_blocked_observation'
    if event == 'write_attempt' and 'payload.quantity' in fields:
        return 'requested_size'
    return 'other_or_unknown'


def coin_comparison(original, shifted):
    left, unknown_left = coin_events(original)
    right, unknown_right = coin_events(shifted)
    # Macro raw identities encode creation time. Associate uniquely equal full
    # causal contexts, while retaining distinct actual IDs and every raw diff.
    def contextual(groups):
        proposed = {}
        for identity, rows in groups.items():
            declarations = [r['raw'] for r in rows if r['raw']['event'] == 'opportunity']
            macro = [r for r in declarations if r.get('kind') == 'macro' and r.get('dfii10')]
            key = 'identity:' + identity
            if len(macro) == 1:
                context = {'kind': macro[0]['kind'], 'direction': macro[0]['direction'], 'dfii10': macro[0]['dfii10']}
                key = 'macro-context:' + hashlib.sha256(json.dumps(context, sort_keys=True).encode()).hexdigest()
            proposed[identity] = key
        counts = Counter(proposed.values())
        return {(key if counts[key] == 1 else 'identity:' + identity): (identity, groups[identity])
                for identity, key in proposed.items()}
    left_context, right_context = contextual(left), contextual(right)
    daily_left = sorted(original['daily'], key=lambda r: r['stamp_ms'])
    daily_right = sorted(shifted['daily'], key=lambda r: r['stamp_ms'])
    lt, rt = [r['stamp_ms'] for r in daily_left], [r['stamp_ms'] for r in daily_right]
    opportunities = []
    def context_time(key):
        rows = left_context.get(key, ('', []))[1] + right_context.get(key, ('', []))[1]
        return min(r['raw'].get('at_ms', 0) for r in rows)
    for alignment in sorted(left_context.keys() | right_context.keys(), key=context_time):
        left_id, lg = left_context.get(alignment, (None, []))
        right_id, rg = right_context.get(alignment, (None, []))
        first_exact, stage_differences = None, []
        # Occurrence alignment is explicit and conservative: different poll
        # counts can make later rows ambiguous, so these are traces, not equality proofs.
        for event in sorted({x['raw']['event'] for x in lg + rg}):
            a = [x for x in lg if x['raw']['event'] == event]
            b = [x for x in rg if x['raw']['event'] == event]
            for occurrence in range(max(len(a), len(b))):
                av = a[occurrence] if occurrence < len(a) else None
                bv = b[occurrence] if occurrence < len(b) else None
                diff = differences(av['raw'] if av else None, bv['raw'] if bv else None)
                if not diff:
                    continue
                provenance = EVENT_OUTCOMES.get(event, {})
                outcomes = {f for f in diff if f.split('.')[0] in provenance}
                operational = set(diff) - TIMING_IDENTITIES - outcomes
                stamp = min(x['raw'].get('at_ms', context_time(alignment)) for x in (av, bv) if x)
                detail = {'event': event, 'occurrence': occurrence, 'comparison_at_ms': stamp,
                          'left': av, 'right': bv, 'exact_differences': diff,
                          'timing_or_identifier_fields': sorted(set(diff) & TIMING_IDENTITIES),
                          'post_execution_or_future_diagnostic_fields': sorted(outcomes),
                          'field_provenance': {f: {'populated_after': provenance[f.split('.')[0]],
                              'available_at_ms': None,
                              'limitation': 'Summary completion time is not recorded; the row timestamp predates this field.'}
                              for f in sorted(outcomes)},
                          'operational_fields': sorted(operational)}
                if first_exact is None or stamp < first_exact['comparison_at_ms']:
                    first_exact = detail
                if operational:
                    detail['category'] = divergence_category(event, operational)
                    detail['facets'] = sorted(set([detail['category']] +
                        (['sizing'] if event == 'entry_sizing' else []) +
                        (['requested_size'] if event == 'write_attempt' and 'payload.quantity' in operational else []) +
                        (['different_observations'] if operational & {'decision_mark', 'entry_estimate', 'bar_ms', 'trade.price', 'payload.price'} else []) +
                        (['prior_account_state'] if operational & {'wallet_usdt', 'idle_cash_usdt', 'sizing_capital_usdt', 'quantity_before'} else [])))
                    if 'requested_size' in detail['facets']:
                        detail['upstream_cause'] = 'unknown'
                    stage_differences.append(detail)
                    break  # first operational difference per event stage, not every subsequent poll
        stage_differences.sort(key=lambda r: r['comparison_at_ms'])
        first = stage_differences[0] if stage_differences else None
        when = first['comparison_at_ms'] if first else context_time(alignment)
        li, ri = bisect_right(lt, when - 1) - 1, bisect_right(rt, when - 1) - 1
        prior_l = daily_left[li] if li >= 0 else None
        prior_r = daily_right[ri] if ri >= 0 else None
        prior_diff = differences(prior_l, prior_r)
        propagation = bool(prior_l and prior_r and prior_l['stamp_ms'] == prior_r['stamp_ms'] and
                           prior_l['equity_usdt'] != prior_r['equity_usdt'])
        # Do not relabel observation differences as propagated equity effects.
        if first and first['category'] == 'prior_account_state' and propagation:
            first['category'] = 'prior_equity_propagation'
        opportunities.append({'alignment': alignment,
                              'opportunity': int(left_id or right_id),
                              'actual_identity_left': int(left_id) if left_id is not None else None,
                              'actual_identity_right': int(right_id) if right_id is not None else None,
                              'actual_identity_equal': left_id is not None and left_id == right_id,
                              'left_events': len(lg), 'right_events': len(rg),
                              'first_exact_difference': first_exact, 'first_operational_divergence': first,
                              'first_stage_divergences': stage_differences,
                              'prior_daily_left': prior_l, 'prior_daily_right': prior_r,
                              'prior_daily_exact_differences': prior_diff,
                              'prior_equity_already_different': propagation,
                              'causal_isolation': 'unknown' if propagation and first and
                                  first['category'] != 'prior_equity_propagation' else 'descriptive_trace'})
    def timeout_rows(account):
        return [s for s in account['sessions'] if any('deadline' in reason or 'timeout' in reason
                for reason in s.get('observations', {}).get('reasons', {}))]
    roots = sorted((r for r in opportunities if r['first_operational_divergence']),
                   key=lambda r: r['first_operational_divergence']['comparison_at_ms'])
    first_root = roots[0] if roots else None
    return {'opportunities': opportunities,
            'first_account_operational_divergence': first_root['first_operational_divergence'] if first_root else None,
            'first_divergence_counts': dict(Counter(r['first_operational_divergence']['category'] for r in roots)),
            'stage_divergence_counts': dict(Counter(x['category'] for r in opportunities for x in r['first_stage_divergences'])),
            'unowned_event_counts': {'left': dict(Counter(x['raw']['event'] for x in unknown_left)),
                                    'right': dict(Counter(x['raw']['event'] for x in unknown_right))},
            'unowned_fill_rows': {'left': [x for x in unknown_left if x['raw']['event'] == 'fill'],
                                 'right': [x for x in unknown_right if x['raw']['event'] == 'fill']},
            'blocked_rows': {'left': [x for x in unknown_left if x['raw']['event'] == 'cycle_blocked'],
                             'right': [x for x in unknown_right if x['raw']['event'] == 'cycle_blocked']},
            'timeout_sessions': {'left': timeout_rows(original), 'right': timeout_rows(shifted)},
            'unnecessary_dependency_established': False,
            'limitations': ['Exact comparisons retain all raw timestamps, identifiers and numeric values.',
                'Event occurrences align within actual opportunities; differing poll counts limit later pairing.',
                'Macro contexts pair only uniquely identical full recorded DFII10 context/direction; distinct creation IDs remain distinct.',
                'Decision action/reason/quantity_after/constraint/error are appended after original_decide returns or fails; their completion times are unavailable.',
                'These decision summaries and post-run horizon closes stay in exact differences with provenance but cannot identify a prior cause.',
                'Constraint differences are attributed at actual entry/top-up sizing timestamps, not the earlier decision-row timestamp.',
                'Explicit write payload.quantity establishes a requested-size difference; its upstream cause remains unknown.',
                'First account divergence means first among explicitly opportunity-owned rows; unowned observations remain separate.',
                'A timing or price observation change is not by itself a bug.',
                'Earlier equity differences can propagate; mixed observation/state changes are not causally isolated.',
                'Unlinked fills and blocked observations have unknown opportunity ownership.',
                'No counterfactual same-observation execution was produced; no dependency fix is justified here.']}


def generate(evidence):
    evidence = Path(evidence).resolve()
    bindings = []
    def load(path, expected=None):
        body, digest = read_json(path, expected)
        bindings.append({'path': str(path), 'sha256': digest})
        return body
    def resolve(old):
        if '/alpha-beta-next/' in old:
            relative = Path('scratch') / old.split('/alpha-beta-next/', 1)[1]
        elif '/btc-alpha-beta-next/review/' in old:
            relative = Path('review') / old.split('/btc-alpha-beta-next/review/', 1)[1]
        else:
            raise ValueError('unrecognized accepted evidence path: ' + old)
        require('..' not in relative.parts, 'unsafe evidence path')
        candidates = [evidence / relative, RETAINED / relative]
        return next((p for p in candidates if p.is_file()), candidates[0])
    proof = load(evidence / 'review/final64-financial-review-proof.json')
    require(proof['financial_evidence_approved'] and proof['exact64_reconciled'], 'accepted final review required')
    final = load(evidence / 'scratch/registered-final-repaired.json', proof['final_sha256'])
    canonical_proof_path = evidence / 'review/spot-canonical-five-financial-proof.json'
    canonical_proof = load(canonical_proof_path,
        proof['identities']['/workspace/btc-alpha-beta-next/review/spot-canonical-five-financial-proof.json'])
    require(canonical_proof['all_five_complete_and_six_groups_equal'], 'canonical bridge not accepted')
    inventory = load(resolve('/workspace/scratch/alpha-beta-next/spot-canonical/canonical-inventory.json'),
        canonical_proof['identities']['/workspace/scratch/alpha-beta-next/spot-canonical/canonical-inventory.json'])
    base_files = [x for x in inventory['files'] if x['label'] == 'base' and not x['calibrated']]
    require(len(base_files) == 1, 'ambiguous canonical base')
    canonical = load(resolve('/workspace/scratch/alpha-beta-next/spot-canonical/' + base_files[0]['path']), base_files[0]['sha256'])
    spot = canonical['results']['atr-stop-base']
    atr_inputs = [x for x in final['inputs']['spot']['account_source_manifests']
                  if x['raw_sha256'] == canonical_proof['identities']['/workspace/scratch/alpha-beta-next/spot-singletons/atr-stop.json.gz']]
    require(len(atr_inputs) == 1, 'ambiguous accepted rich ATR input')
    rich_bundle = load(resolve(atr_inputs[0]['path']), atr_inputs[0]['raw_sha256'])
    rich = rich_bundle['results']['atr-stop-base']
    for group in ('fills', 'daily', 'allocations', 'positions', 'cash_usdt', 'btc'):
        require(spot[group] == rich[group], 'canonical/rich mismatch: ' + group)
    perp_input = final['inputs']['perp']
    require(proof['identities'][perp_input['path']] == perp_input['raw_sha256'], 'Coin original outside accepted review')
    original_bundle = load(resolve(perp_input['path']), perp_input['raw_sha256'])
    original = original_bundle['results']['incumbent']['base']
    comparisons, sources = {}, {'spot_canonical': canonical['source'], 'spot_rich': rich_bundle['source'],
                                'coin_original': original_bundle['inputs']['source']}
    for offset in (-60000, 60000):
        sensitivity = [r for r in final['sensitivity'] if r['candidate'] == 'incumbent' and
                       r['initial_cny'] == '10000' and r['start_offset_ms'] == offset]
        require(len(sensitivity) == 1, 'ambiguous accepted Coin sensitivity')
        identity = [p for p, h in proof['identities'].items() if h == sensitivity[0]['raw_sha256']]
        require(len(identity) == 1, 'sensitivity outside accepted inventory')
        shifted_bundle = load(resolve(identity[0]), sensitivity[0]['raw_sha256'])
        require(shifted_bundle['inputs']['start_offset_ms'] == offset and
                shifted_bundle['inputs']['source'] == sources['coin_original'], 'Coin source/offset mismatch')
        comparisons[str(offset)] = coin_comparison(original, shifted_bundle['results']['incumbent']['base'])
        sources['coin_' + str(offset)] = shifted_bundle['inputs']['source']
    prior_root = evidence.parent / 'complete-delivery-20261001'
    manifest = load(prior_root / 'manifest.json')
    prior = load(prior_root / 'assessment.json',
                 manifest['files']['evidence/complete-delivery-20261001/assessment.json']['sha256'])
    prior_rows = {k: v for k, v in prior['candidate_attribution'].items()
                  if k.startswith(('spot/funding-', 'spot/basis-', 'spot/default-', 'perp/funding-filter/',
                                   'perp/basis-filter/', 'perp/incumbent/'))}
    selections = {'spot': {k: prior['spot_selection']['decisions'][k] for k in ('funding', 'basis')},
                  'perp': {k: prior['perp_selection']['decisions'][k] for k in ('funding-filter', 'basis-filter')}}
    for binding in bindings:
        require(sha(binding['path']) == binding['sha256'], 'input changed during attribution')
    return {'format': 'edge-attribution-v1', 'diagnostic_source': {
                'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                'module_sha256': sha(__file__), 'follow_sha256': sha(ROOT / 'spotquant/follow.py'),
                'preview_sha256': sha(ROOT / 'spotquant/preview.py')},
            'inputs': bindings, 'measured_sources': sources,
            'spot': spot_attribution(spot, rich), 'coin': comparisons,
            'prior_funding_basis': {'analysis_source': prior['analysis_source'], 'rows': prior_rows,
                'selection': selections,
                'conclusion': 'All four prior simple filters were ineligible; negative evidence is retained.',
                'remaining_questions': ['Trend-conditioned funding/basis interactions require a separately registered causal test.',
                    'Coin holding-horizon funding awareness is distinct from a simple entry filter.',
                    'Risk budgets and Spot ordinary-exit confirmation are distinct mechanisms; old filters do not answer them.',
                    'Reusing a previously rejected simple filter or tuning thresholds to this history is not justified.']},
            'financial_producer_executed': False, 'native_cases': 0, 'actual_account_days': 0,
            'limitations': ['Accepted financial reviews are consumed, not re-executed or independently reconstructed here.',
                            'Historical proxy evidence is contaminated by prior research; no prospective alpha or native qualification.']}


def markdown(body):
    lines = ['# Existing-evidence attribution', '',
             'Read-only accepted evidence. Price opportunity is not earned profit. Native cases/account days: 0/0.', '',
             '## Spot', '', 'Exit sleeve counts: ' + json.dumps(body['spot']['exit_sleeve_counts']),
             'Flat sleeve-day counts: ' + json.dumps(body['spot']['flat_sleeve_day_counts']), '',
             'Flat denotes closed campaigns with proven retained dust; daily endpoints do not prove intraday flatness.', '',
             '## Coin', '']
    for offset, result in body['coin'].items():
        lines += [offset + 'ms first divergence counts: ' + json.dumps(result['first_divergence_counts']),
                  'First account operational divergence: ' + json.dumps(result['first_account_operational_divergence']), '']
    lines += ['No unnecessary dependency is established. Raw timestamps/values and per-opportunity stage traces are in JSON.', '',
              '## Prior funding/basis', '', body['prior_funding_basis']['conclusion'], '']
    lines += ['- ' + x for x in body['prior_funding_basis']['remaining_questions']]
    lines += ['', '## Input byte bindings', '']
    lines += ['- `' + x['sha256'] + '` ' + x['path'] for x in body['inputs']]
    lines += ['', '## Limits', '']
    lines += ['- ' + x for x in body['limitations'] + body['spot']['limitations'] + body['coin']['-60000']['limitations']]
    return '\n'.join(lines) + '\n'


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(argv)
    require(not args.out.exists(), 'output already exists')
    body = generate(args.evidence)
    # mkdir without exist_ok plus exclusive file opens rejects race/overwrite.
    args.out.mkdir()
    with (args.out / 'attribution.json').open('x', encoding='utf-8') as stream:
        json.dump(body, stream, indent=2, allow_nan=False)
        stream.write('\n')
    with (args.out / 'attribution.md').open('x', encoding='utf-8') as stream:
        stream.write(markdown(body))


if __name__ == '__main__':
    main()
