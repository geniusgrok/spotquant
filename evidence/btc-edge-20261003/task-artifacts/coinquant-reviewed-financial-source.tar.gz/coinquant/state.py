"""Local single-writer lock and synchronous durable exchange intents.

The database is a recovery aid, never an authority for balances or positions.
Use one persistent state directory per account on one machine. A second host is
refused for 10 minutes when it opens that same directory. Two copies of the
directory cannot see each other; that is not supported.
"""
from __future__ import annotations

import hashlib
import json
import os
import socket
from pathlib import Path
import sqlite3
from time import time, time_ns

from .types import Blocked, Unknown, serial, number
from .campaign import ORIGIN
from .config import ENVIRONMENTS, scope


SCHEMA_VERSION = 1
# Derived reports stay in SQLite up to this many rows; older ones move to an
# append-only archive file first, so a long-running account keeps its diagnosis trail.
OBSERVATION_KEEP = 2000
OBSERVATION_BATCH = 500


def _account_lock_path(identity: str) -> Path:
    """One lock file per account identity, shared by every state directory."""
    root = Path.home() / '.local' / 'state' / 'coinquant' / 'account-locks'
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    return root / hashlib.sha256(identity.encode()).hexdigest()


def client_id(account: str, candle: int, operation: str) -> str:
    # Independent of local state and parameters: lost state cannot change an ID.
    identity = f'BTCUSD|{account}|{candle}|{operation}'.encode()
    return 'cq-' + hashlib.sha256(identity).hexdigest()[:30]


def retryable(kind, payload):
    return (kind in ('binance_algo', 'binance_algo_cancel', 'binance_cancel', 'binance_margin')
            or kind == 'binance_order' and payload.get('reduceOnly') == 'true')


class State:
    def __init__(self, directory: str | Path, identity: str):
        self.directory = Path(directory).expanduser().resolve()
        self.identity = identity
        self.lock = None
        self.account_lock = None
        self.db = None

    def __enter__(self):
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.lock = open(self.directory / 'execution.lock', 'a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                self.lock.seek(0)
                if self.lock.read(1) == b'':
                    self.lock.write(b'0'); self.lock.flush()
                self.lock.seek(0)
                msvcrt.locking(self.lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.account_lock = open(_account_lock_path(self.identity), 'a+b')
            if os.name == 'nt':
                import msvcrt
                self.account_lock.seek(0)
                if self.account_lock.read(1) == b'':
                    self.account_lock.write(b'0'); self.account_lock.flush()
                self.account_lock.seek(0)
                msvcrt.locking(self.account_lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.account_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.db = sqlite3.connect(self.directory / 'intents.sqlite', timeout=0)
            self.db.execute('PRAGMA synchronous=FULL')
            self.db.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS intents (id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL, result TEXT NOT NULL, updated REAL NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS native_fills (trade_id INTEGER PRIMARY KEY, entry_id TEXT NOT NULL, payload TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS observations (sequence INTEGER PRIMARY KEY, recorded_at REAL NOT NULL, payload TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS native_income (kind TEXT NOT NULL, transaction_id INTEGER NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(kind,transaction_id))')
            saved = self.get('identity')
            if saved is not None and saved != self.identity:
                raise Blocked('state directory belongs to another account or environment')
            version = self.get('schema_version')
            if type(version) is int and version > SCHEMA_VERSION:
                raise Blocked('state was written by newer code; manage the position manually or use that code')
            host = socket.gethostname()
            prior = self.get('writer_host')
            now = time()
            if (isinstance(prior, dict) and prior.get('host') not in (None, host)
                    and type(prior.get('at')) is float and now-prior['at'] < 600):
                raise Blocked('this account state was written by another machine in the last 10 minutes')
            if saved is not None and version != SCHEMA_VERSION:
                self.backup('schema')
            self.set_many({'identity': self.identity, 'schema_version': SCHEMA_VERSION})
            self.set('writer_host', {'host': host, 'pid': os.getpid(), 'at': now})
            return self
        except (OSError, sqlite3.Error) as exc:
            self.__exit__(None, None, None)
            raise Blocked('state unavailable or another run holds the execution lock') from exc
        except Exception:
            self.__exit__(None, None, None)
            raise

    def backup(self, reason: str) -> Path:
        """Consistent SQLite copy; keep three completed session copies."""
        folder = self.directory / 'backups'
        folder.mkdir(exist_ok=True, mode=0o700)
        target = folder / f'intents-{reason}-{time_ns()}.sqlite'
        temporary = target.with_suffix('.tmp')
        try:
            copy = sqlite3.connect(temporary)
            try:
                self.db.backup(copy)
            finally:
                copy.close()
            os.replace(temporary, target)
            if reason == 'session':
                for old in sorted(folder.glob('intents-session-*.sqlite'))[:-3]:
                    old.unlink()
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return target

    def __exit__(self, *args):
        if self.db is not None:
            self.db.close(); self.db = None
        if self.lock is not None:
            # Closing releases the OS lock. Never cancel exchange orders here.
            self.lock.close(); self.lock = None
        if self.account_lock is not None:
            self.account_lock.close(); self.account_lock = None

    def get(self, key: str):
        row = self.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def set(self, key: str, value) -> None:
        self.set_many({key: value})

    def set_many(self, values: dict) -> None:
        """Commit several keys in one transaction."""
        with self.db:
            for key, value in values.items():
                self.db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',
                                (key, json.dumps(serial(value), sort_keys=True)))

    def prepare(self, identity: str, kind: str, payload: dict, *, campaign=None, flat_snapshot=None,
                position_snapshot=None, result=None) -> None:
        encoded = json.dumps(serial(payload), sort_keys=True, separators=(',', ':'))
        row = self.db.execute('SELECT kind,status,result FROM intents WHERE id=?', (identity,)).fetchone()
        if row:
            # A rejected intent left nothing at the exchange under this identity,
            # so a safety operation may try it again. Entries always take a new epoch.
            if row[1] != 'rejected' or row[0] != kind or not retryable(kind, payload):
                raise Unknown('intent already exists; reconcile it instead of resending')
            result = {**(result or {}), 'prior_rejection': json.loads(row[2])}
        links=None
        if campaign is not None and position_snapshot is not None:
            # An add inherits the fill-history boundary of the campaign's first entry.
            links=self.get('entry_campaigns') or {}
            group=[link for link in links.values() if link.get('campaign')==campaign]
            q=number(position_snapshot.get('quantity_btc'))
            if (type(campaign) is not int or campaign==0 or kind!='binance_order' or not group
                    or flat_snapshot is not None
                    or any(link.get('campaign')!=campaign for link in links.values())
                    or payload.get('symbol')!='BTCUSDT' or payload.get('positionSide')!='BOTH'
                    or payload.get('side')!=('BUY' if q>0 else 'SELL') or payload.get('reduceOnly')=='true'
                    or not q or position_snapshot.get('possible_entry_remainders')!=0
                    or self.pending()
                    or self.identity not in {scope(environment, position_snapshot.get('account_uid'))
                                             for environment in ENVIRONMENTS}):
                raise Blocked('campaign add requires the reconciled position of that campaign')
            first=min(group,key=lambda link:link['prepared_at'])
            links[identity]=dict(campaign=campaign,prepared_at=first['prepared_at'],
                                 after_trade_id=first.get('after_trade_id'),add=True)
        elif campaign is not None:
            if (type(campaign) is not int or campaign==0 or kind!='binance_order'
                    or payload.get('symbol')!='BTCUSDT' or payload.get('positionSide')!='BOTH'
                    or payload.get('side') not in ('BUY','SELL') or payload.get('reduceOnly')=='true'
                    or not flat_snapshot or number(flat_snapshot.get('quantity_btc'))!=0
                    or flat_snapshot.get('possible_entry_remainders')!=0
                    or self.pending()
                    or self.identity not in {scope(environment, flat_snapshot.get('account_uid'))
                                             for environment in ENVIRONMENTS}):
                raise Blocked('entry campaign requires a reconciled flat owned account')
            links=self.get('entry_campaigns') or {}
            observed_at=flat_snapshot.get('observed_at_ms',int(time()*1000))
            if type(observed_at) is not int or observed_at<=0:
                raise Blocked('invalid entry observation clock')
            if campaign<0 and not ORIGIN<=-campaign<=observed_at+15000:
                raise Blocked('invalid macro campaign identity')
            cursor=flat_snapshot.get('last_fill_id')
            if cursor is not None and (type(cursor) is not int or cursor < -1):
                raise Blocked('invalid native flat fill cursor')
            # Market timestamps are not fill boundaries. A recent-time overlap
            # tolerates clock skew; the observed trade id excludes prior fills.
            links[identity]=dict(campaign=campaign,prepared_at=observed_at-(15000 if cursor is not None else 0),after_trade_id=cursor)
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO intents VALUES (?,?,?,?,?,?)' if row else
                            'INSERT INTO intents VALUES (?,?,?,?,?,?)',
                            (identity, kind, encoded, 'unknown', json.dumps(serial(result or {}), sort_keys=True), time()))
            if links is not None:
                self.db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',('entry_campaigns',json.dumps(links,sort_keys=True)))
        # A crash immediately after this commit must be treated as possibly sent.

    def finish(self, identity: str, status: str, result: dict) -> None:
        # void: a risk-reducing request retired on a verified flat account after
        # its signed timestamp expired (Lifecycle.retire_stale). It can no longer
        # change exposure; whether it was ever accepted is not asserted.
        if status not in ('unknown', 'partial', 'confirmed', 'rejected', 'void'):
            raise ValueError('invalid intent status')
        prior=self.db.execute('SELECT result FROM intents WHERE id=?',(identity,)).fetchone()
        if prior:
            old=json.loads(prior[0]).get('executed_quantity')
            if old is not None and (result.get('executed_quantity') is None
                    or number(result['executed_quantity'])<number(old)):
                raise Unknown('native cumulative fill cannot regress or disappear')
        with self.db:
            cursor = self.db.execute('UPDATE intents SET status=?,result=?,updated=? WHERE id=?',
                                    (status, json.dumps(serial(result), sort_keys=True), time(), identity))
            if cursor.rowcount != 1:
                raise Blocked('cannot finish an unrecorded intent')

    def pending(self) -> list[dict]:
        return [dict(id=a, kind=b, payload=json.loads(c), status=d)
                for a, b, c, d in self.db.execute(
                    "SELECT id,kind,payload,status FROM intents WHERE status IN ('unknown','partial') ORDER BY updated")]

    def report(self, value: dict) -> None:
        # Reports deliberately exclude raw API-key metadata and signed requests.
        # Keep each actual observation/unknown gap; never fabricate valuations
        # while the process was stopped or an exchange read was unavailable.
        with self.db:
            self.db.execute('INSERT INTO observations(recorded_at,payload) VALUES (?,?)',
                            (time(),json.dumps(serial(value),sort_keys=True,allow_nan=False)))
        # A session longer than the 10-minute window keeps its writer claim current.
        self.set('writer_host', {'host': socket.gethostname(), 'pid': os.getpid(), 'at': time()})
        self._archive_observations()
        output = self.directory / 'latest.json'
        temporary = output.with_suffix('.tmp')
        with open(temporary, 'w', encoding='utf-8') as stream:
            json.dump(serial(value), stream, indent=2, allow_nan=False)
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, output)
        if os.name != 'nt':
            fd = os.open(self.directory, os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)

    def _archive_observations(self) -> None:
        count = self.db.execute('SELECT COUNT(*) FROM observations').fetchone()[0]
        if count < OBSERVATION_KEEP + OBSERVATION_BATCH:
            return
        rows = self.db.execute('SELECT sequence,recorded_at,payload FROM observations ORDER BY sequence LIMIT ?',
                               (count - OBSERVATION_KEEP,)).fetchall()
        # Written and synced before deletion; a crash between the two only duplicates lines.
        with open(self.directory / 'observations-archive.jsonl', 'a', encoding='utf-8') as stream:
            for sequence, recorded, payload in rows:
                stream.write(json.dumps({'sequence': sequence, 'recorded_at': recorded, 'report': json.loads(payload)},
                                        sort_keys=True) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        with self.db:
            self.db.execute('DELETE FROM observations WHERE sequence<=?', (rows[-1][0],))
